package com.qualitesoft.AmazonScrapperProject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.qualitesoft.core.InitializeTest;
import com.qualitesoft.core.SeleniumFunction;
import com.qualitesoft.core.WaitTool;
import com.qualitesoft.core.Xls_Reader;

public class GetContentDetails extends InitializeTest {

	@Test
	public void testGetContentDetails() {
		
		List<WebElement> allRows;
		List<WebElement> allColumns;
		Xls_Reader xr=new Xls_Reader("binaries/ContentDetails.xlsx");
		
		//Click on A+ Content Manager link
		SeleniumFunction.click(WaitTool.waitForElementPresentAndDisplay(driver, By.linkText("A+ Content Manager"), 10));
		
		//Get total no. of pages
		//int pageTotal=Integer.parseInt(SeleniumFunction.getText(WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//*[@id='app-main']/div[3]/div/awsui-table/div/div[2]/div/div[2]/span/span/awsui-table-pagination/ul/li[10]/button"), 10)));
		
		//Read data and store into excel
		WaitTool.sleep(10);
		int rowCounter=2;
		
		for(int pageCounter=1; pageCounter<3; pageCounter++) 
		{
			WaitTool.sleep(5);
			allRows=driver.findElements(By.xpath("//*[@id='app-main']/div[3]/div/awsui-table/div/div[3]/table/descendant::tr"));
			System.out.println("Page Number "+pageCounter+" Total Rows: "+allRows.size());
			
			for(WebElement row : allRows) {
				
				allColumns = row.findElements(By.xpath("td/span"));
				
				xr.setCellData("Sheet1", "content name", rowCounter, allColumns.get(0).getText());
				xr.setCellData("Sheet1", "content type", rowCounter, allColumns.get(1).getText());
				xr.setCellData("Sheet1", "language", rowCounter, allColumns.get(2).getText());
				xr.setCellData("Sheet1", "ASINs", rowCounter, allColumns.get(3).getText());
				xr.setCellData("Sheet1", "last modified", rowCounter, allColumns.get(4).getText());
				xr.setCellData("Sheet1", "content status", rowCounter, allColumns.get(5).getText());
				
				rowCounter++;
			}
			
			//Click on next page icon
			SeleniumFunction.click(WaitTool.waitForElementPresentAndDisplay(driver, By.className("awsui-table-pagination-next-page"), 5));
		}	
	}
}

