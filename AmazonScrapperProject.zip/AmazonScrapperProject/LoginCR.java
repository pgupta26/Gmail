package com.qualitesoft.AmazonScrapperProject;

import org.testng.annotations.Test;

import com.qualitesoft.core.InitializeTest;

import com.qualitesoft.core.ScreenShot;
import com.qualitesoft.core.SeleniumFunction;
import com.qualitesoft.core.WaitTool;
import com.qualitesoft.core.Xls_Reader;
import com.qualitesoft.AmazonScrapperProject.pageobjects.LoginPage;



public class LoginCR extends InitializeTest  {

	@Test
	public void testLoginCR()  {

		LoginPage loginPage = new LoginPage(driver);
		 WaitTool.sleep(5);
         driver = getDriver();
 		 //Read data from excel		
  		Xls_Reader xr=new Xls_Reader("binaries/AmazonScrapper.xlsx");		
  		String username=xr.getCellData("Sheet2","Username", 2).trim();
  		System.out.println("username:" + username);
  		
  		String password=xr.getCellData("Sheet2","Password", 2).trim();
  		System.out.println("password:" + password);
		
  		SeleniumFunction.click(loginPage.SignInHomePage());
		SeleniumFunction.sendKeys(loginPage.emailField(),username);
		SeleniumFunction.sendKeys(loginPage.passwordfield(),password);
		ScreenShot.takeScreenShot(driver, "Login Page ");
	    SeleniumFunction.click(loginPage.signinbutton());
	    WaitTool.sleep(3);
	    
	    boolean isOtpCodePresent=true;
	    
	    while(isOtpCodePresent) {
	    	String otpCode=loginPage.OTPCode().getAttribute("value");
		    if(!otpCode.isEmpty()) {
		    	SeleniumFunction.click(loginPage.outhSignIn());
		    	isOtpCodePresent=false;
		    } else {
		    	System.out.println("Waiting for otp to appear------------");
		    	WaitTool.sleep(30);
		    	System.out.println("Wait Over................");
		    }
	    }
	    
	    ScreenShot.takeScreenShot(driver, "Home Page ");
	}
}

