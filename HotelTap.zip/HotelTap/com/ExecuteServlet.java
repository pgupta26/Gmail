package com;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.DatatypeConverter;


public class ExecuteServlet extends HttpServlet {
	
	RequestDispatcher rd;
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) {
		try{
			
			// set content type
			res.setContentType("text/html");

			//execute job
			executeJob(req);
			
			//send success message
			rd=req.getRequestDispatcher("confirmation.jsp");
			req.setAttribute("conf_mesg","Job started in jenkins successfully.");
			rd.include(req, res);


		}catch(Exception ex){
			ex.printStackTrace();
			rd=req.getRequestDispatcher("confirmation.jsp");
			req.setAttribute("conf_mesg","Something went wrong. Please contact Administrator.");
		}

	}

	private String getProperty(String key) throws IOException {
		Properties prop = new Properties();
		InputStream input = null;

		ServletContext context = getServletContext();
		String configPath = context.getRealPath("/WEB-INF/config/config.properties");
		input = new FileInputStream(configPath);

		// load a properties file
		prop.load(input);

		// get the property value
		return prop.getProperty(key);
	}

	private void executeJob(HttpServletRequest req) throws IOException{

		// read config parameters
		String jenkins_url=getProperty("Jenkins_Url").trim();
		String Jenkins_UsersParamName=getProperty("Jenkins_UsersParamName").trim();
		String Jenkins_RampUpParamName=getProperty("Jenkins_RampUpParamName").trim();
		String Jenkins_LoopCountParamName=getProperty("Jenkins_LoopCountParamName").trim();
		String Jenkins_JobNameParamsName=getProperty("Jenkins_JobNameParamsName").trim(); 
		

		//get request parameters
		String jobName=req.getParameter("jobName").trim();
		String Users=req.getParameter("users").trim();
		String RampUpTime=req.getParameter("rampup").trim();
		String Iterations=req.getParameter("iteration").trim();
		

		URL url = new URL (jenkins_url+"/job/"+jobName+"/buildWithParameters"); // Jenkins URL localhost:8080, job named 'test'
		String jenkins_UserName=getProperty("Jenkins_UserName").trim(); // username
		String jenkins_Password=getProperty("Jenkins_Password").trim(); // password or API token
		String authStr = jenkins_UserName +":"+  jenkins_Password;
		String encoding = DatatypeConverter.printBase64Binary(authStr.getBytes("utf-8"));

		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		connection.setRequestMethod("POST");
		connection.setDoOutput(true);
		connection.setRequestProperty("Authorization", "Basic " + encoding);

		String urlParams=Jenkins_JobNameParamsName+"="+jobName+"&"+Jenkins_UsersParamName+"="+Users+"&"+Jenkins_RampUpParamName+"="+RampUpTime+"&"+Jenkins_LoopCountParamName+"="+Iterations;
		byte[] postData = urlParams.getBytes("utf-8");
		DataOutputStream wr = new DataOutputStream(connection.getOutputStream());
		wr.write(postData);
		
		InputStream content = connection.getInputStream();
		BufferedReader in   =
				new BufferedReader (new InputStreamReader (content));
		String line;
		while ((line = in.readLine()) != null) {
			System.out.println(line);
		}
	}
}
