package com;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServlet;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class HelperFunctions {

	public List<String> listJobs(String url,String userName,String password) {
		Client client = Client.create();
		client.addFilter(new com.sun.jersey.api.client.filter.HTTPBasicAuthFilter(userName, password));
		WebResource webResource = client.resource(url+"/api/xml");
		ClientResponse response = webResource.get(ClientResponse.class);
		String jsonResponse = response.getEntity(String.class);
		client.destroy();
		System.out.println("Response listJobs:::::"+jsonResponse);

		// Assume jobs returned are in xml format, TODO using an XML Parser would be better here
		// Get name from <job><name>...
		List<String> jobList = new ArrayList<String>();
		String[] jobs = jsonResponse.split("job>"); // 1, 3, 5, 7, etc will contain jobs
		for(String job: jobs){
			String[] names = job.split("name>");
			if(names.length == 3) {
				String name = names[1];
				name = name.substring(0,name.length()-2); // Take off </ for the closing name tag: </name>
				jobList.add(name);
				//				System.out.println("name:"+name);
			}
			//			System.out.println("job:"+job);
			//			for(String name: names){
			//				System.out.println("name:"+name);
			//			}
		}
		return jobList;
	}

	public ClientResponse deleteJob(String url, String jobName,String userName,String password) {
		Client client = Client.create();
		client.addFilter(new com.sun.jersey.api.client.filter.HTTPBasicAuthFilter(userName, password));
		WebResource webResource = client.resource(url+"/job/"+jobName+"/doDelete");
		ClientResponse response = webResource.post(ClientResponse.class);
		//String jsonResponse = response.getEntity(String.class);
		//client.destroy();
		//System.out.println("Response deleteJobs:::::"+jsonResponse);
		return response;
	}

	public static String copyJob(String url, String newJobName, String oldJobName){
		Client client = Client.create();
//		client.addFilter(new com.sun.jersey.api.client.filter.HTTPBasicAuthFilter(USERNAME, PASSWORD));
		WebResource webResource = client.resource(url+"/createItem?name="+newJobName+"&mode=copy&from="+oldJobName);
		ClientResponse response = webResource.type("application/xml").get(ClientResponse.class);
		String jsonResponse = response.getEntity(String.class);
		client.destroy();
//		System.out.println("Response copyJob:::::"+jsonResponse);
		return jsonResponse;
	}
	
	public ClientResponse createJob(String url, String newJobName, String configXML,String userName,String password){
		Client client = Client.create();
		client.addFilter(new com.sun.jersey.api.client.filter.HTTPBasicAuthFilter(userName, password));
		WebResource webResource = client.resource(url+"/createItem?name="+newJobName);
		ClientResponse response = webResource.type("application/xml").post(ClientResponse.class, configXML);
		String jsonResponse = response.getEntity(String.class);
		client.destroy();
		//System.out.println("Response createJob:::::"+jsonResponse);
		return response;
	}

	public String readJob(String url, String jobName,String userName,String password){
		Client client = Client.create();
		client.addFilter(new com.sun.jersey.api.client.filter.HTTPBasicAuthFilter(userName, password));
		WebResource webResource = client.resource(url+"/job/"+jobName+"/config.xml");
		ClientResponse response = webResource.get(ClientResponse.class);
		String jsonResponse = response.getEntity(String.class);
		client.destroy();
		if(response.getStatus()==200){
			return jsonResponse;
		}else{
			return "";
		}
	}
	
	public ClientResponse buildJob(String url, String jobName,String userName,String password,String urlParams){
		Client client = Client.create();
		client.addFilter(new com.sun.jersey.api.client.filter.HTTPBasicAuthFilter(userName, password));
		WebResource webResource = client.resource(url+"/job/"+jobName+"/buildWithParameters?"+urlParams);
		ClientResponse response = webResource.post(ClientResponse.class);
		String jsonResponse = response.getEntity(String.class);
		client.destroy();
		return response;
	}
	
	public ClientResponse StopJob(String url, String jobName,String userName,String password,String urlParams){
		Client client = Client.create();
		client.addFilter(new com.sun.jersey.api.client.filter.HTTPBasicAuthFilter(userName, password));
		WebResource webResource = client.resource(url+"/job/"+jobName+"/buildWithParameters?"+urlParams);
		ClientResponse response = webResource.post(ClientResponse.class);
		String jsonResponse = response.getEntity(String.class);
		client.destroy();
		return response;
	} 
}
