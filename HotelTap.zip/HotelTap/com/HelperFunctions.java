package com;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServlet;

public class HelperFunctions extends HttpServlet {

	public static void main(String[] args){
		//System.out.println("FileName: "+fileName);
		File file=new File("C:\\Users\\e5399484\\workspace\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\MyFirstJavaProject\\WEB-INF\\Uploads\\Test1.jmx");
		if(file.exists()){
			file.delete();
		}
		System.out.println("File deleted");
	}
}
