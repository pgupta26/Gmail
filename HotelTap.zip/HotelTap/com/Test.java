package com;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

import javax.xml.bind.DatatypeConverter;

public class Test {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		URL url = new URL ("http://localhost:8080/jenkins/job/GoogleTest.jmx/buildWithParameters"); // Jenkins URL localhost:8080, job named 'test'
		String jenkins_UserName="admin";//getProperty("Jenkins_UserName"); // username
		String jenkins_Password="admin123";//getProperty("Jenkins_Password"); // password or API token
		String authStr = jenkins_UserName +":"+  jenkins_Password;
		String encoding = DatatypeConverter.printBase64Binary(authStr.getBytes("utf-8"));

		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		connection.setRequestMethod("POST");
		connection.setDoOutput(true);
		connection.setRequestProperty("Authorization", "Basic " + encoding);

		//String urlParams=Users+"="+Users+"&"+Jenkins_RampUpParamName+"="+RampUpTime+"&"+Jenkins_LoopCountParamName+"="+Iterations;
		
		String urlParams="JobName=GoogleTest&Users=5&RampUp=1&LoopCount=5";
		
		byte[] postData = urlParams.getBytes("utf-8");
		DataOutputStream wr = new DataOutputStream(connection.getOutputStream());
		wr.write(postData);

		InputStream content = connection.getInputStream();
		BufferedReader in   =
				new BufferedReader (new InputStreamReader (content));
		String line;
		while ((line = in.readLine()) != null) {
			System.out.println(line);
		}

	}

}
