package com;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class Test {

	public static void main(String[] args) {
		Client client = Client.create();
		client.addFilter(new com.sun.jersey.api.client.filter.HTTPBasicAuthFilter("admin", "admin123"));
		WebResource webResource = client.resource("http://10.74.230.180:8080/job/Test/lastBuild/stop");
		ClientResponse response = webResource.post(ClientResponse.class);
		System.out.println(response.getStatus());
		String jsonResponse = response.getEntity(String.class);
		client.destroy();


	}

}
