package com;

import java.net.URI;
import java.util.Map;

import javax.ws.rs.core.MediaType;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.filter.ClientFilter;

import java.io.IOException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpException;
import org.apache.http.HttpHost;
import org.apache.http.HttpRequest;
import org.apache.http.HttpRequestInterceptor;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScheme;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.AuthState;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.protocol.ClientContext;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.auth.HttpAuthenticator;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.ExecutionContext;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;

public class Test {

	public static void main(String[] args) {
		
		/*Client client = Client.create();
		client.addFilter(new com.sun.jersey.api.client.filter.HTTPBasicAuthFilter("admin", "a7a04b36a625fc7fa98b03f17f163ae6"));
		WebResource webResource = client.resource("http://10.74.230.170:8080/job/GoogleTest/api/json");
		ClientResponse response = webResource.post(ClientResponse.class);
		
		System.out.println(response.getStatus());
		String jsonResponse = response.getEntity(String.class);
		System.out.println(jsonResponse);
		client.destroy();*/
		String TOKEN="a7a04b36a625fc7fa98b03f17f163ae6";
		/*Client client = Client.create();
		client.addFilter(new com.sun.jersey.api.client.filter.HTTPBasicAuthFilter("admin", "admin123"));
		WebResource webResource = client.resource("http://10.74.230.170:8080/job/GoogleTest/lastBuild/stop?token="+TOKEN);
		ClientResponse response = webResource.post(ClientResponse.class);
				
		System.out.println(response.getStatus());

		String jsonResponse = response.getEntity(String.class);
		System.out.println(jsonResponse);
		client.destroy();*/
		/*String urlParams="JobName=GoogleTest&Users=1&RampUp=1&LoopCount=1";

		Client client = Client.create();
		client.addFilter(new com.sun.jersey.api.client.filter.HTTPBasicAuthFilter("admin","admin123"));
		WebResource webResource = client.resource("http://10.74.230.170:9090/job/GoogleTest/buildWithParameters?token="+TOKEN+"&"+urlParams);
		ClientResponse response = webResource.post(ClientResponse.class);
		
		System.out.println(response.getStatus());

		String jsonResponse = response.getEntity(String.class);
		System.out.println(jsonResponse);
		client.destroy();*/
		
		
		
		Client client = Client.create();
		client.addFilter(new com.sun.jersey.api.client.filter.HTTPBasicAuthFilter("admin","admin123"));
		WebResource webResource = client.resource("http://10.74.230.170:9090/job/Test/doDelete?token="+TOKEN);
		ClientResponse response = webResource.post(ClientResponse.class);
		System.out.println(response.getStatus());

		String jsonResponse = response.getEntity(String.class);
		System.out.println(jsonResponse);
		client.destroy();
		
	}
	
}

