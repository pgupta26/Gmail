package com;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;


@MultipartConfig(fileSizeThreshold=1024*1024*10, 	// 10 MB 
maxFileSize=1024*1024*50,      						// 50 MB
maxRequestSize=1024*1024*100)   					// 100 MB
public class UploadServlet extends HttpServlet {

	private String Upload_Dir;
	private String fileName;
	private ServletContext context;
	private PrintWriter out;
	private Document doc;
	private NodeList loopCountNode;
	private Transformer xformer;
	private RequestDispatcher rd;
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {

		try{

			res.setContentType("text/html");

			context = getServletContext();
			//Upload_Dir = context.getRealPath("/WEB-INF/Uploads");
			Upload_Dir=getProperty("Upload_Dir");
			
			out=res.getWriter();

			// creates the save directory if it does not exists
			File fileSaveDir = new File(Upload_Dir);
			if (!fileSaveDir.exists()) {
				fileSaveDir.mkdirs();
			}

			//Get all the parts from request and write it to the file on server
			Part part=req.getPart("fname");

			//get file name from the request
			fileName = getFileName(part);

			int i=fileName.lastIndexOf("\\");
			fileName=fileName.substring(i+1);
			
			//check if file name already exist
			List<String> allFiles= getAllAvailableFiles(Upload_Dir);
			if(allFiles.contains(fileName)){
				//send failure message
			    rd=req.getRequestDispatcher("confirmation.jsp");
				req.setAttribute("conf_mesg","File with this name already exist in the system.");
				rd.forward(req, res);
			}else{
				
				//write file into file system
				part.write(Upload_Dir + File.separator + fileName);
				
				//update jenkins parameter names in script
				updateScriptFile(Upload_Dir + File.separator + fileName);
				
				//send success message
				rd=req.getRequestDispatcher("confirmation.jsp");
				req.setAttribute("conf_mesg","File "+fileName+" uploaded successfully!!");
				rd.include(req, res);

			}

		}catch(TransformerFactoryConfigurationError| Exception ex){
			deleteFile(Upload_Dir + File.separator + fileName);
			ex.printStackTrace();
			rd=req.getRequestDispatcher("confirmation.jsp");
			req.setAttribute("conf_mesg","Something went wrong. Please contact Administrator.");
			try {
				rd.include(req, res);
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	private String getFileName(Part part) {
		String contentDisp = part.getHeader("content-disposition");
		String[] tokens = contentDisp.split(";");
		for (String token : tokens) {
			if (token.trim().startsWith("filename")) {
				return token.substring(token.indexOf("=") + 2, token.length()-1);
			}
		}
		return "";
	}

	private void updateScriptFile(String fileName) throws SAXException, IOException, ParserConfigurationException, XPathExpressionException, TransformerFactoryConfigurationError, TransformerException{

		String Jenkins_UsersParamName=getProperty("Jenkins_UsersParamName");
		String Jenkins_RampUpParamName=getProperty("Jenkins_RampUpParamName");
		String Jenkins_LoopCountParamName=getProperty("Jenkins_LoopCountParamName");
		
		doc = DocumentBuilderFactory.newInstance()
				.newDocumentBuilder().parse(new InputSource(fileName));
		// locate the node(s)
		XPath xpath = XPathFactory.newInstance().newXPath();

		loopCountNode = (NodeList)xpath.evaluate
				("//stringProp[@name='LoopController.loops']", doc, XPathConstants.NODESET);

		// make the change
		for (int idx = 0; idx < loopCountNode.getLength(); idx++) {
			loopCountNode.item(idx).setTextContent("${__P("+Jenkins_LoopCountParamName+",1)}");
		}

		NodeList usersNode = (NodeList)xpath.evaluate
				("//stringProp[@name='ThreadGroup.num_threads']", doc, XPathConstants.NODESET);

		// make the change
		for (int idx = 0; idx < usersNode.getLength(); idx++) {
			usersNode.item(idx).setTextContent("${__P("+Jenkins_UsersParamName+",1)}");
		}

		NodeList rampUpNode = (NodeList)xpath.evaluate
				("//stringProp[@name='ThreadGroup.ramp_time']", doc, XPathConstants.NODESET);

		// make the change
		for (int idx = 0; idx < rampUpNode.getLength(); idx++) {
			rampUpNode.item(idx).setTextContent("${__P("+Jenkins_RampUpParamName+",1)}");
		}

		// save the result
		xformer = TransformerFactory.newInstance().newTransformer();


		xformer.transform
		(new DOMSource(doc), new StreamResult(new File(fileName)));

	}
	
	private void deleteFile(String fileName){
		File file=new File(fileName);
		if(file.exists()){
			file.delete();
		}
	}
	
	private String getProperty(String key) throws IOException {
		Properties prop = new Properties();
		InputStream input = null;

		ServletContext context = getServletContext();
		String configPath = context.getRealPath("/WEB-INF/config/config.properties");
		input = new FileInputStream(configPath);

		// load a properties file
		prop.load(input);

		// get the property value
		return prop.getProperty(key);

	}
	
	private List<String> getAllAvailableFiles(String Upload_Dir ){
		File listAllFiles=new File(Upload_Dir);
		if (!listAllFiles.exists()) {
			listAllFiles.mkdirs();
		}
		List<String> jmxFile = new ArrayList<String>();
		for (File file : listAllFiles.listFiles()) {
		    if (file.getName().endsWith((".jmx"))) {
		    	
		    	jmxFile.add(file.getName());
		    }
		  }
		return jmxFile;
	}
}
