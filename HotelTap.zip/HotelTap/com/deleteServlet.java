package com;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.jersey.api.client.ClientResponse;

public class deleteServlet extends HttpServlet {
	
	RequestDispatcher rd;
	private String Upload_Dir;
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) {
		try{
			
			// read config parameters
			Upload_Dir=getProperty("Upload_Dir").trim();
			String jenkins_url=getProperty("Jenkins_Url").trim();
			String jenkins_UserName=getProperty("Jenkins_UserName").trim(); // username
			String jenkins_Password=getProperty("Jenkins_Password").trim(); // password or API token
			
			//get request parameter
			String jobName=req.getParameter("jobName").trim();
			
			//Initialize objects
			HelperFunctions helpObj=new HelperFunctions();
			
			// set content type
			res.setContentType("text/html");

			//delete job
			ClientResponse response=helpObj.deleteJob(jenkins_url,jobName,jenkins_UserName,jenkins_Password);
			int statusCode=response.getStatus();
			
			if(statusCode==200){
				//send success message
				rd=req.getRequestDispatcher("confirmation.jsp");
				req.setAttribute("conf_mesg","Job deleted in jenkins and script moved to archive folder successfully.");
				rd.include(req, res);
			}else{
				//send success message
				File deleteScript=new File(Upload_Dir+"\\"+jobName+".jmx");
				File archiveFolder=new File(Upload_Dir+"\\Archive");
				if(!archiveFolder.exists()){
					archiveFolder.mkdirs();
				}
				
				if(deleteScript.exists()){
					deleteScript.renameTo(new File(Upload_Dir+"\\Archive\\"+jobName+".jmx"));
					deleteScript.delete();
				}
				
				//send failure message
				rd=req.getRequestDispatcher("confirmation.jsp");
				req.setAttribute("conf_mesg","Not able to connect to server. Please check config parameters.");
				rd.include(req, res);
			}
		}catch(Exception ex){
			ex.printStackTrace();
			rd=req.getRequestDispatcher("confirmation.jsp");
			req.setAttribute("conf_mesg","Something went wrong. Please contact Administrator.");
		}

	}
	
	private String getProperty(String key) throws IOException {
		Properties prop = new Properties();
		InputStream input = null;

		ServletContext context = getServletContext();
		String configPath = context.getRealPath("/WEB-INF/config/config.properties");
		input = new FileInputStream(configPath);

		// load a properties file
		prop.load(input);

		// get the property value
		return prop.getProperty(key);
	}

}
