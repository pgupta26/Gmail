/*$(document).ready(function() {
	$("#createjob").submit(function(e) {
	    e.preventDefault();
	 });*/
	var scriptName="";
	$("#create-Job").click(function(event) {
		scriptName=$('.jmx-uploadButton__fileName').text();
		$.ajax({
			url: "jenkins_createJob",
			type:"POST",
			data:{	
				scriptName1:scriptName,
				  },
	        dataType: "json",
			success: function(json) {
				if(json=="Success"){
					alert("Job successfully created in jenkins.");
				}else if (json == "ConnectionFail") {
					alert("Unable to connect to jenkins. Please check config parameters.");
				}else if(json=="Fail"){
					alert("Unable to create job. Please contact your administrator.")
				}else{
					alert("Something went wrong.")
				}	 
				
			},
			error: function(e) {
				alert(e + " SERVER ERROR , TRY AGAIN LATER");
			}
		})
	})
//});
   
