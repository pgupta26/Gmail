$(document).ready(function() {
	$("#deletecsv").submit(function(e) {
	    e.preventDefault();
	 });
	var fileName="";
	$("#delete-csv").click(function(event) {
		scriptName=$('#fname').val().toString();
		fileName=$('#fileName :selected').text();
		$.ajax({
			url: "delete_csv",
			type:"POST",
			data:{	
				scriptName1:scriptName,
				fileName1:fileName
				  },
	        dataType: "json",
			success: function(json) {
				if(json=="1"){
					alert("Something went wrong while uploading file. Please contact your administrator.")
				}else{
					if(json==="Success"){
						 $('#fileName option:selected').remove();
						 $('#cname').val('');
					 }
				}	 
			},
			error: function(e) {
				alert(e + " SERVER ERROR , TRY AGAIN LATER");
			}
		})
	})
});
   
