$(document).ready(function() {
	$("#upload-form").submit(function(e) {
	    e.preventDefault();
	    alert("Form submitted.")
	 });
	
	$("#upload-button").click(function(event) {
		alert("hel");
		$("#test tr").remove();
		$('#test1 tbody > tr').remove();
		$.ajax({
			url: "upload",
			type:"POST",
			mimeType:"multipart/form-data",
	        data: new FormData($('#upload-form')[0]),
	        contentType: false,
	        processData: false,
			dataType: "json",
			success: function(json) {
				alert(json);
				if(json=="1"){
					alert("Something went wrong while uploading file. Please contact your administrator.")
				}else{
					if(json[0]=="0"){
						 alert("File Uploaded Successfully. Click on Create job button to create jenkins job.")
					 }else{
						 alert("File Uploaded Successfully. Please upload supported data sets files.")
						 $("#grid").css("display", "block"); 
						 for(i=1;i<json.length;i=i+2){
							var row = '<tr>';
				               row += '<td>'+json[i]+'</td>';
				               row += '<td>'+json[i+1]+'</td>';
				               row += '</tr>';
				               $('#test').append(row);
						} 
						 
						//$("#uploadcsv").css("display", "block");
						//$("#deletecsv").css("display", "block"); 
					 }
				}	 
			},
			error: function(e) {
				alert(e + " SERVER ERROR , TRY AGAIN LATER");
			}
		})
	});
});
   
