$(document).ready(function() {
	$("#upload-form").submit(function(e) {
	    e.preventDefault();
	 });
	
	var isOverWrite1;
	$("#upload-button").click(function(event) {
		var formData=new FormData($('#upload-form')[0]);
		isOverWrite1='No';
		formData.append('isOverWrite',isOverWrite1)
		
		var val = $('#jmx-uploadButton__hiddenControl').val();
		var file_type = val.substr(val.lastIndexOf('.')).toLowerCase();
		/*if (!(file_type  === '.jmx')) {
			alert("Plesase upload jmeter file only.")
		}*/
			
		if($('#jmx-uploadButton__hiddenControl').val()==''){
			alert("Please upload jmeter file.")
		}else if(!(file_type  === '.jmx')){  
			alert("Invalid file type. Only Jmeter scripts are allowed.")
		}else{
			$("#test tr").remove();
			$('#test1 tbody > tr').remove();
			$.ajax({
				url: "upload",
				type:"POST",
				mimeType:"multipart/form-data",
		        data: formData,
		        contentType: false,
		        processData: false,
				dataType: "json",
				success: function(json) {
					if(json=="1"){
						alert("Something went wrong while uploading file. Please contact your administrator.")
					}else if(json=="exist"){
						if (confirm('File with this name already exist in the system. Do you want to overwrite?')) {
							var formData=new FormData($('#upload-form')[0]);
							isOverWrite1='Yes';
							formData.append('isOverWrite',isOverWrite1)
							$("#test tr").remove();
							$('#test1 tbody > tr').remove();
							$.ajax({
								url: "upload",
								type:"POST",
								mimeType:"multipart/form-data",
						        data: formData,
						        contentType: false,
						        processData: false,
								dataType: "json",
								success:function(json){
									if(json[0]=="0"){
										 alert("File Uploaded Successfully. Please click on build job.")
										 //$('#create-Job').prop('disabled', false);
										 location.reload();
									 }else{
										 alert("File Uploaded Successfully. Please upload supported data sets files then click on build job.")
										 //$('#create-Job').prop('disabled', false);
										 $("#grid").css("display", "block");
										 for(i=1;i<json.length;i=i+2){
											var row = '<tr>';
								               row += '<td>'+json[i]+'</td>';
								               row += '<td>'+json[i+1]+'</td>';
								               row += '</tr>';
								               $('#test').append(row);
										} 
										$("#grid1").css("display","block");
									 }
								},
								error: function(e) {
									alert(e + " SERVER ERROR , TRY AGAIN LATER");
								}
							})
						} else {
							return false;	
						}
					}else{
						if(json[0]=="0"){
							 alert("File Uploaded Successfully. Click on Create job button to create jenkins job.")
							 //$('#create-Job').prop('disabled', false);
							 $("#create-Job").css("display", "block");
						 }else{
							 alert("File Uploaded Successfully. Please upload supported data sets files then click on create jenkins job.")
							 //$('#create-Job').prop('disabled', false);
							 $("#create-Job").css("display", "block");
							 $("#grid").css("display", "block");
							 for(i=1;i<json.length;i=i+2){
								var row = '<tr>';
					               row += '<td>'+json[i]+'</td>';
					               row += '<td>'+json[i+1]+'</td>';
					               row += '</tr>';
					               $('#test').append(row);
							} 
							$("#grid1").css("display","block");
						 }
					}	 
				},
				error: function(e) {
					alert(e + " SERVER ERROR , TRY AGAIN LATER");
				}
			})
		}
	});
	
	var scriptName="";
	$("#create-Job").click(function(event) {
		scriptName=$('.jmx-uploadButton__fileName').text();
		$.ajax({
			url: "jenkins_createJob",
			type:"POST",
			data:{	
				scriptName1:scriptName,
				  },
	        dataType: "json",
			success: function(json) {
				if(json=="Success"){
					alert("Job successfully created in jenkins.");
					location.reload();
				}else if(json=="exist"){
					alert("Job with this name already exist. Please proceed to build.")
					location.reload();
				}else if (json == "ConnectionFail") {
					alert("Unable to connect to jenkins. Please check config parameters.");
				}else if(json=="Fail"){
					alert("Unable to create job. Please contact your administrator.")
				}else{
					alert("Something went wrong.")
				}	 
				
			},
			error: function(e) {
				alert(e + " SERVER ERROR , TRY AGAIN LATER");
			}
		})
	});
	
	$("#search").click(function(event) {
		$("#test01 tr").remove();
		$('#test02 tbody > tr').remove();
		$.ajax({
			url: "GetAllJobsDetails",
			type:"POST",
			success: function(json) {
				if(json == "ConnectionFail") {
					alert("Unable to connect to jenkins. Please check config parameters.");
				}else if(json=="Fail"){
					alert("Unable to get last build status. Please contact your administrator.")
				}else{
					for(i=0;i<json.length;i++){
						var row = '<tr>';
			               row += '<td>'+json[i][0]+'</td>';
			               row += '<td>'+json[i][1]+'</td>';
			               row += '<td>'+json[i][2]+'</td>';
			               row += '<td>'+json[i][3]+'</td>';
			               if(json[i][4]=="true"){
			            	   row += '<td>Running</td>';
			               }else if(json[i][4]=="false"){
			            	   row += '<td>Stopped</td>';
			               }else{
			            	   row += '<td>'+json[i][4]+'</td>';
			               }
			               
			               if(json[i][4]=="true"){
				               row += '<td><button type="button" class="btn btn-danger text-center"  id="' + json[i][0] + '" name="stop"><i class="mdi mdi-close-circle"></i>Stop</button></td>'
			               }else{
				               row += '<td><button type="button" class="btn btn-danger text-center"  id="' + json[i][0] + '" name="stop" disabled><i class="mdi mdi-close-circle"></i>Stop</button></td>'
			               }
			              // row += '<td><button type="button" class="btn btn-danger text-center"  id="' + json[i][0] + '" name="stop"><i class="mdi mdi-close-circle"></i>Stop</button></td>'
			               row += '<td><button type="button" class="btn btn-danger text-center"  id="' + json[i][0] + '" name="delete"><i class="mdi mdi-close-circle"></i>Delete</button></td>'
			               row += '</tr>';
			               $('#test01').append(row);
					}
				}
			},
			error: function(e) {
				alert(e + " SERVER ERROR , TRY AGAIN LATER");
			}
		})
	});
	
	$(document).on("click", "button[name = 'delete']", function() {
	    var jobName = $(this).attr('id');
	    $.ajax({
	      url: "deleteJob",
	      type: "POST",
	      data: {		
	    	  jobName: jobName,
	      },
	      success: function(json) {
	    	  if(json=="Success"){
					alert("Job successfully deleted in jenkins.");
			         $('table tbody #'+jobName).closest('tr').remove();
			         location.reload();

				}else if (json == "ConnectionFail") {
					alert("Unable to connect to jenkins. Please check config parameters.");
				}else if(json=="Fail"){
					alert("Unable to delete job. Please contact your administrator.")
				}else{
					alert("Something went wrong.")
				}	 
	      },
	      error: function(e) {
				alert(e + " SERVER ERROR , TRY AGAIN LATER");

	      }
	    });
	  });
	
	
	$(document).on("click", "button[name = 'stop']", function() {
	    var jobName = $(this).attr('id');
	    $.ajax({
	      url: "stopJob",
	      type: "POST",
	      data: {		
	    	  jobName: jobName,
	      },
	      success: function(json) {
	    	  if(json=="Success"){
					alert("Job successfully stopped in jenkins.");
					location.reload();
				}else if (json == "ConnectionFail") {
					alert("Unable to connect to jenkins. Please check config parameters.");
				}else if(json=="Fail"){
					alert("Unable to stop job. Please contact your administrator.")
				}else{
					alert("Something went wrong.")
				}	 
	      },
	      error: function(e) {
				alert(e + " SERVER ERROR , TRY AGAIN LATER");

	      }
	    });
	  });
	
	$(document).on("click", "a[name = 'delete1']", function() {
		var scriptName=$('.jmx-uploadButton__fileName').text();
	    var filename = $(this).attr('id');
	    $.ajax({
			url: "delete_csv",
			type:"POST",
			data:{	
				scriptName1:scriptName,
				fileName1:filename
			},
	        dataType: "json",
			success: function(json) {
				if(json=="1"){
					alert("Something went wrong while uploading file. Please contact your administrator.")
				}else{
					if(json==="Success"){
						 alert("File has been deleted from file system. UI Remove Pending.");
						 $(this).parent().remove();
						 $('#cname').val('');
					 }
				}	 
			},
	    })
	  });
});
   
