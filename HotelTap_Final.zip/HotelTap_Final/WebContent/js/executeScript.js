/*$(document).ready(function() {
	$("#execute-form").submit(function(e) {
	    e.preventDefault();
	 });*/
	var scriptName="";
	var users="";
	var rampup="";
	var duration="";
	$("#execute-button").click(function(event) {
		scriptName=$('#jobName').val().toString();
		users=$('#input1').val().toString();
		rampup=$('#input2').val().toString();
		duration=$('#input3').val().toString();
		$.ajax({
			url: "execute",
			type:"POST",
			data:{	
				scriptName:scriptName,
				users:users,
				rampup:rampup,
				duration:duration
				  },
			dataType: "json",
			success: function(json) {
				if(json=="Success"){
					alert("Job successfully started in jenkins.");
				}else if (json == "ConnectionFail") {
					alert("Unable to connect to jenkins. Please check config parameters.");
				}else if(json=="Fail"){
					alert("Unable to build job. Please contact your administrator.")
				}else{
					alert("Something went wrong.")
				}	 
				
			},
			error: function(e) {
				alert(e + " SERVER ERROR , TRY AGAIN LATER");
			}
		})
	});
//});
   
