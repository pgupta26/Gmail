$(document).ready(function() {
	$("form").submit(function(e) {
		e.preventDefault();
	});

	var jobName="";
	$("#getReport1").click(function(event) {
		jobName=$('#jobName').val().toString();
		$.ajax({
			url: "graphReport",
			type:"POST",
			data:{	
				jobName1:jobName,
			},
			success: function(json) {
				json			
			},
			error: function(e) {
				alert(e + " SERVER ERROR , TRY AGAIN LATER");
			}
		})
	});
})