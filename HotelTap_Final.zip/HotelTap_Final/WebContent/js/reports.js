$(document).ready(function() {
	$("#1").submit(function(e) {
	    e.preventDefault();
	  });

	var jobName="";
	$("#search").click(function(event) {
		jobName=$('#jobName').val().toString();
		$("#test tr").remove();
		$('#test1 tbody > tr').remove();
		$.ajax({
			url: "getBuildHistory.jsp",
			type:"get",
			data:{	
				jobName1:jobName,
				  },
			dataType: "json",
			success: function(json) {
				for(i=0;i<json.length;i++){
					var row = '<tr>';
		               row += '<td>'+json[i][0]+'</td>';
		               row += '<td>'+json[i][1]+'</td>';
		               if(json[i][2]=='SUCCESS'){
		            	   row += '<td><span class="label label-success">'+json[i][2]+'</span></td>';   
		               }else{
		            	   row += '<td><span class="label label-danger">'+json[i][2]+'</span></td>';
		               }
		               //row += '<td><input type="submit" value="'+jobName+'-'+json[i][0]+'" class="btn btn-danger text-center" name="viewResults"></td>'
		               row += '<td><a href="Results/'+jobName+'/html/'+json[i][0]+'/index.html" target="_blank" class="btn btn-danger text-center">View Results</a></td>'
		               row += '</tr>';
		               $('#test').append(row);
				}
			},
			error: function(e) {
				alert(e + " SERVER ERROR , TRY AGAIN LATER");
			}
		})
	});
})