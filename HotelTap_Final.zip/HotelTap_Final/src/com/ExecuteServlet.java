package com;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.transform.TransformerFactoryConfigurationError;

import com.google.gson.Gson;
import com.sun.jersey.api.client.ClientResponse;


public class ExecuteServlet extends HttpServlet {
	
	RequestDispatcher rd;
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		try{
			// read config parameters
			String jenkins_url=getProperty("Jenkins_Url").trim();
			String Jenkins_UsersParamName=getProperty("Jenkins_UsersParamName").trim();
			String Jenkins_RampUpParamName=getProperty("Jenkins_RampUpParamName").trim();
			String Jenkins_DurationParamName=getProperty("Jenkins_DurationParamName").trim();
			String Jenkins_JobNameParamsName=getProperty("Jenkins_JobNameParamsName").trim(); 
			String Jenkins_UserName=getProperty("Jenkins_UserName").trim();
			String Jenkins_Password=getProperty("Jenkins_Password").trim();
			String Jenkins_APIToken=getProperty("Jenkins_APIToken").trim();
			
			//get request parameters
			String jobName=req.getParameter("scriptName").trim();
			String Users=req.getParameter("users").trim();
			String RampUpTime=req.getParameter("rampup").trim();
			String duration=req.getParameter("duration").trim();

			//Initialize objects
			HelperFunctions helpObj=new HelperFunctions();

			String urlParams=Jenkins_JobNameParamsName+"="+jobName+"&"+Jenkins_UsersParamName+"="+Users+"&"+Jenkins_RampUpParamName+"="+RampUpTime+"&"+Jenkins_DurationParamName+"="+duration;

			//execute job
			//executeJob(req);
			ClientResponse statusCode=helpObj.buildJob(jenkins_url, jobName, Jenkins_UserName, Jenkins_Password, urlParams,Jenkins_APIToken);
			if(statusCode.getStatus()==201){
				//send success message
				String msg="Success";
				String json = new Gson().toJson(msg);
				res.setContentType("application/json");
				res.getWriter().write(json);
			}else{
				//Send Failure message
				String msg="Fail";
				String json = new Gson().toJson(msg);
				res.setContentType("application/json");
				res.getWriter().write(json);
			}
	}catch(com.sun.jersey.api.client.ClientHandlerException  ex){
		
		String msg="ConnectionFail";
		String json = new Gson().toJson(msg);
		res.setContentType("application/json");
		res.getWriter().write(json);	
	}catch(TransformerFactoryConfigurationError| Exception ex){
		
		String msg="Fail";
		String json = new Gson().toJson(msg);
		res.setContentType("application/json");
		res.getWriter().write(json);
	}
}

private String getProperty(String key) throws IOException {
	Properties prop = new Properties();
	InputStream input = null;

	ServletContext context = getServletContext();
	String configPath = context.getRealPath("/WEB-INF/config/config.properties");
	input = new FileInputStream(configPath);

	// load a properties file
	prop.load(input);

	// get the property value
	return prop.getProperty(key);
}
}
