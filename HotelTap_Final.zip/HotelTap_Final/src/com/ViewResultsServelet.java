package com;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ViewResultsServelet
 */
@SuppressWarnings("serial")
@WebServlet("/ViewResultsServelet")
public class ViewResultsServelet extends HttpServlet {

	String Upload_Dir;	

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String jobBuildNumber = request.getParameter("viewResults");
		String[] values=jobBuildNumber.split("-");
		
		String jobName =values[0];
		String buildNumber=values[1];
		
		System.out.println("values "+jobName+"-"+buildNumber);
		
		//Read properties
		Upload_Dir=getProperty("Upload_Dir").trim()+File.separator+jobName+File.separator;
		
		response.setContentType("text/html");
		
		OutputStream out = response.getOutputStream(); 
		try (FileInputStream in = new FileInputStream(Upload_Dir+"Results\\html\\"+buildNumber+"\\index.html")) {
			int content;
			while ((content = in.read()) != -1) {
				out.write(content);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		out.close();
	}
	private String getProperty(String key) throws IOException {
		Properties prop = new Properties();
		InputStream input = null;

		ServletContext context = getServletContext();
		String configPath = context.getRealPath("/WEB-INF/config/config.properties");
		input = new FileInputStream(configPath);

		// load a properties file
		prop.load(input);

		// get the property value
		return prop.getProperty(key);
	}
}
