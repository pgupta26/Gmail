package com;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.transform.TransformerFactoryConfigurationError;

import com.google.gson.Gson;
import com.sun.jersey.api.client.ClientResponse;

public class deleteServlet extends HttpServlet {
	
	RequestDispatcher rd;
	private String Upload_Dir;
	File deleteScript;
	String jobName;
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		try{
			
			// read config parameters
			String jenkins_url=getProperty("Jenkins_Url").trim();
			String jenkins_UserName=getProperty("Jenkins_UserName").trim(); // username
			String jenkins_Password=getProperty("Jenkins_Password").trim(); // password or API token
			String Jenkins_APIToken=getProperty("Jenkins_APIToken").trim();
			//get request parameter
			jobName=req.getParameter("jobName").trim();
			
			//Initialize objects
			HelperFunctions helpObj=new HelperFunctions();
			
			//delete job
			ClientResponse response=helpObj.deleteJob(jenkins_url,jobName,jenkins_UserName,jenkins_Password,Jenkins_APIToken);
			int statusCode=response.getStatus();
			
			//Read properties
			Upload_Dir=getProperty("Upload_Dir").trim()+File.separator+jobName;
			
			deleteScript=new File(Upload_Dir+"\\"+jobName+".jmx");
			File archiveFolder=new File(Upload_Dir+"\\Archive");
			if(!archiveFolder.exists()){
				archiveFolder.mkdirs();
			}
			
			if(statusCode==200){
				if(deleteScript.exists()){
					deleteScript.renameTo(new File(Upload_Dir+"\\Archive\\"+jobName+".jmx"));
					deleteScript.delete();
				}
				
				String msg="Success";
				String json = new Gson().toJson(msg);
				res.setContentType("application/json");
				res.getWriter().write(json);
				
			}else{
				//Send Failure message
				if(deleteScript.exists()){
					deleteScript.renameTo(new File(Upload_Dir+"\\Archive\\"+jobName+".jmx"));
					deleteScript.delete();
				}
				String msg="Fail";
				String json = new Gson().toJson(msg);
				res.setContentType("application/json");
				res.getWriter().write(json);
			}
		}catch(com.sun.jersey.api.client.ClientHandlerException  ex){
			
			if(deleteScript.exists()){
				deleteScript.renameTo(new File(Upload_Dir+"\\Archive\\"+jobName+".jmx"));
				deleteScript.delete();
			}
			String msg="ConnectionFail";
			String json = new Gson().toJson(msg);
			res.setContentType("application/json");
			res.getWriter().write(json);	
		}catch(TransformerFactoryConfigurationError| Exception ex){
			
			if(deleteScript.exists()){
				deleteScript.renameTo(new File(Upload_Dir+"\\Archive\\"+jobName+".jmx"));
				deleteScript.delete();
			}			
			
			String msg="Fail";
			String json = new Gson().toJson(msg);
			res.setContentType("application/json");
			res.getWriter().write(json);
		}

	}
	
	private String getProperty(String key) throws IOException {
		Properties prop = new Properties();
		InputStream input = null;

		ServletContext context = getServletContext();
		String configPath = context.getRealPath("/WEB-INF/config/config.properties");
		input = new FileInputStream(configPath);

		// load a properties file
		prop.load(input);

		// get the property value
		return prop.getProperty(key);
	}

}
