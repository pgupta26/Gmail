/*$(document).ready(function() {
	alert("dfjdfs")
	$("form").submit(function(e) {
	    e.preventDefault();
	  });*/

	$("#search").click(function(event) {
		alert("hsdflsdfl");
		$("#test tr").remove();
		$('#test1 tbody > tr').remove();
		$.ajax({
			url: "GetAllJobsDetails",
			type:"POST",
			success: function(json) {
				if(json == "ConnectionFail") {
					alert("Unable to connect to jenkins. Please check config parameters.");
				}else if(json=="Fail"){
					alert("Unable to create job. Please contact your administrator.")
				}else{
					for(i=0;i<json.length;i++){
						var row = '<tr>';
			               row += '<td>'+json[i][0]+'</td>';
			               row += '<td>'+json[i][1]+'</td>';
			               row += '<td>'+json[i][2]+'</td>';
			               row += '<td>'+json[i][3]+'</td>';
			               if(json[i][4]=="true"){
			            	   row += '<td>Running</td>';
			               }else{
			            	   row += '<td>Stopped</td>';
			               }
			               row += '<td><button type="button" class="btn btn-danger text-center"  id="' + json[i][0] + '" name="stop"><i class="mdi mdi-close-circle"></i>Stop</button></td>'
			               row += '<td><button type="button" class="btn btn-danger text-center"  id="' + json[i][0] + '" name="delete"><i class="mdi mdi-close-circle"></i>Delete</button></td>'
			               row += '</tr>';
			               $('#test').append(row);
					}
				}
			},
			error: function(e) {
				alert(e + " SERVER ERROR , TRY AGAIN LATER");
			}
		})
	});
	
	$(document).on("click", "button[name = 'delete']", function() {
	    var jobName = $(this).attr('id');
	    $.ajax({
	      url: "deleteJob",
	      type: "POST",
	      data: {		
	    	  jobName: jobName,
	      },
	      success: function(json) {
	    	  if(json=="Success"){
					alert("Job successfully deleted in jenkins.");
			         $('table tbody #'+jobName).closest('tr').remove();

				}else if (json == "ConnectionFail") {
					alert("Unable to connect to jenkins. Please check config parameters.");
				}else if(json=="Fail"){
					alert("Unable to delete job. Please contact your administrator.")
				}else{
					alert("Something went wrong.")
				}	 
	      },
	      error: function(e) {
				alert(e + " SERVER ERROR , TRY AGAIN LATER");

	      }
	    });
	  });
	
	
	$(document).on("click", "button[name = 'stop']", function() {
	    var jobName = $(this).attr('id');
	    $.ajax({
	      url: "stopJob",
	      type: "POST",
	      data: {		
	    	  jobName: jobName,
	      },
	      success: function(json) {
	    	  if(json=="Success"){
					alert("Job successfully stopped in jenkins.");
				}else if (json == "ConnectionFail") {
					alert("Unable to connect to jenkins. Please check config parameters.");
				}else if(json=="Fail"){
					alert("Unable to stop job. Please contact your administrator.")
				}else{
					alert("Something went wrong.")
				}	 
	      },
	      error: function(e) {
				alert(e + " SERVER ERROR , TRY AGAIN LATER");

	      }
	    });
	  });
//})