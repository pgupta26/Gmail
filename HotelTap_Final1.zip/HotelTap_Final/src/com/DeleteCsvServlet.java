package com;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.google.gson.Gson;
import com.sun.jersey.api.client.ClientResponse;

public class DeleteCsvServlet extends HttpServlet {

	private String Upload_Dir;
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException{
		
		try{
			System.out.println("Inside Delete Csv Servlet.");
			
			//get request parameter
			String scriptName=req.getParameter("scriptName1").substring(req.getParameter("scriptName1").lastIndexOf("\\")+1);
			String fileName=req.getParameter("fileName1").trim();
			
			
			String scriptNameWithoutJmx=scriptName.substring(0,scriptName.lastIndexOf("."));
			
			//Read properties
			Upload_Dir=getProperty("Upload_Dir").trim()+File.separator+scriptNameWithoutJmx;
			

			File deleteScript=new File(Upload_Dir+"\\"+fileName);
			File archiveFolder=new File(Upload_Dir+"\\Archive");
			if(!archiveFolder.exists()){
				archiveFolder.mkdirs();
			}

			if(deleteScript.exists()){
				deleteScript.renameTo(new File(Upload_Dir+"\\Archive\\"+fileName));
				deleteScript.delete();
			}
			
			String msg="Success";
			String json = new Gson().toJson(msg);

			res.setContentType("application/json");
			res.getWriter().write(json);
		}catch(Exception ex){
			String fail="1";

			String json = new Gson().toJson(fail);

			res.setContentType("application/json");
			res.getWriter().write(json);
		}
	}

	private String getProperty(String key) throws IOException {
		Properties prop = new Properties();
		InputStream input = null;

		ServletContext context = getServletContext();
		String configPath = context.getRealPath("/WEB-INF/config/config.properties");
		input = new FileInputStream(configPath);

		// load a properties file
		prop.load(input);

		// get the property value
		return prop.getProperty(key);
	}
}
