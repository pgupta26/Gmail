package com;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.json.JSONObject;

import com.sun.jersey.api.client.WebResource;
import com.google.gson.Gson;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;

public class GraphReportServlet extends HttpServlet {

	String jobName;
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {

		try{

			ServletContext context = getServletContext();
			String resultsPath = context.getRealPath("/Results");

			//Read from properties file
			String Jenkins_url=getProperty("Jenkins_Url").trim();
			String Jenkins_UserName=getProperty("Jenkins_UserName").trim();
			String Jenkins_Password=getProperty("Jenkins_Password").trim();

			//Read request parameter
			jobName=req.getParameter("jobName1").trim();

			Client client = Client.create();
			client.addFilter(new com.sun.jersey.api.client.filter.HTTPBasicAuthFilter(Jenkins_UserName, Jenkins_Password));
			WebResource webResource = client.resource(Jenkins_url+"/job/"+jobName+"/lastBuild/api/json?tree=number");
			ClientResponse response = webResource.post(ClientResponse.class);

			String jsonResponse = response.getEntity(String.class);
			client.destroy();

			JSONObject json =new JSONObject(jsonResponse);
			int latestBuildNumber=json.getInt("number");
			int previousBuildNumber=latestBuildNumber;

			System.out.println(latestBuildNumber);

			String lastestBuildCSV=resultsPath+File.separator+jobName+File.separator+"csv"+File.separator+latestBuildNumber+File.separator+jobName+".csv";
			String previousBuildCSV=resultsPath+File.separator+jobName+File.separator+"csv"+File.separator+previousBuildNumber+File.separator+jobName+".csv";

			/*ArrayList<ArrayList<String>> records=new ArrayList<ArrayList<String>>();
			ArrayList<String> record;*/

			Reader firstFile = Files.newBufferedReader(Paths.get(lastestBuildCSV));
			CSVParser firstFileParser = new CSVParser(firstFile, CSVFormat.DEFAULT);
			List<CSVRecord> firstFileRecords = firstFileParser.getRecords();

			Reader secondFile = Files.newBufferedReader(Paths.get(previousBuildCSV));
			CSVParser secondFileParser = new CSVParser(secondFile, CSVFormat.DEFAULT);
			List<CSVRecord> secondFileRecords = secondFileParser.getRecords();

			String records="if($('#morris_extra_bar_chart').length > 0) Morris.Bar({element: 'morris_extra_bar_chart',data: [";
			
			for(int i=1;i<firstFileRecords.size();i++){

				//record=new ArrayList<String>();

				CSVRecord firstFileRow = firstFileRecords.get(i);
				CSVRecord secondFieRow = secondFileRecords.get(i);

				String transactionName=firstFileRow.get(2);
				String firstElapsed = firstFileRow.get(1);
				String secondElapsed=secondFieRow.get(1);

				records+="{y: '"+transactionName+"',a: "+firstElapsed+",b: "+secondElapsed+"},";

				/*record.add(transactionName);
				record.add(firstElapsed);
				record.add(secondElapsed);
				records.add(record);*/
			}

			firstFileParser.close();
			secondFileParser.close();
			
			records+="],xkey: 'y',ykeys: ['a', 'b'],labels: ['A', 'B'],barColors:['#177ec1', '#dc4666', '#e69a2a'],hideHover: 'auto',gridLineColor: '#878787',resize: true,gridTextColor:'#878787',gridTextFamily:\"Roboto\"});";			
	
			System.out.println("value: "+records);
			res.setContentType("text/javascript");
			res.getWriter().write(records);
			
			
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}

	public String getProperty(String key) throws IOException {
		Properties prop = new Properties();
		InputStream input = null;

		ServletContext context = getServletContext();
		String configPath = context.getRealPath("/WEB-INF/config/config.properties");
		input = new FileInputStream(configPath);

		// load a properties file
		prop.load(input);

		// get the property value
		return prop.getProperty(key);

	}
}
