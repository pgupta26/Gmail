package com;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.google.gson.Gson;
import com.sun.jersey.api.client.ClientResponse;


@MultipartConfig(fileSizeThreshold=1024*1024*10, 	// 10 MB 
maxFileSize=1024*1024*50,      						// 50 MB
maxRequestSize=1024*1024*100)   					// 100 MB
public class UploadServlet2 extends HttpServlet {

	private String Upload_Dir;
	private String fileName;
	Document doc;
	NodeList fileNameNode;
	NodeList VariableNode;
	Transformer xformer;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {

		try{

			//Get all the parts from request and write it to the file on server
			Part part=req.getPart("fname");

			//get file name from the request
			fileName = getFileName(part);

			int i=fileName.lastIndexOf("\\");
			fileName=fileName.substring(i+1);
			
			String fileNameWithJmx=fileName.substring(0,fileName.lastIndexOf("."));
			
			//Read properties
			Upload_Dir=getProperty("Upload_Dir").trim()+File.separator+fileNameWithJmx;	
			
			//String fileNameWithJmxPath=getProperty("Deployment_path").trim()+File.separator+fileNameWithJmx;
			
			/*File resultsDir=new File(fileNameWithJmxPath);
			if(!resultsDir.exists()){
				resultsDir.mkdirs();
				File csvDir=new File(fileNameWithJmxPath+File.separator+"csv");
				File htmlDir=new File(fileNameWithJmxPath+File.separator+"html");
				if(!csvDir.exists()){
					csvDir.mkdirs();
				}
				if(!htmlDir.exists()){
					htmlDir.mkdirs();
				}
			}*/
			
			// creates the save directory if it does not exists
			File fileSaveDir = new File(Upload_Dir);
			if (!fileSaveDir.exists()) {
				
				fileSaveDir.mkdirs();
				
				//write file into file system
				part.write(Upload_Dir + File.separator + fileName);


				//retrieve csv file names and parameters
				ArrayList<String> fileNames=new ArrayList<String>();

				fileNames=getFileNamesAndParameters(Upload_Dir + File.separator + fileName);
				String json = new Gson().toJson(fileNames);

				res.setContentType("application/json");
				res.getWriter().write(json);
			}else{
				String response="exist";
				
				String json = new Gson().toJson(response);

				res.setContentType("application/json");
				res.getWriter().write(json);
			}

			

		}catch(Exception ex){
			String fail="1";
			
			String json = new Gson().toJson(fail);

			res.setContentType("application/json");
			res.getWriter().write(json);
		}
	}

	private String getFileName(Part part) {
		String contentDisp = part.getHeader("content-disposition");
		String[] tokens = contentDisp.split(";");
		for (String token : tokens) {
			if (token.trim().startsWith("filename")) {
				return token.substring(token.indexOf("=") + 2, token.length()-1);
			}
		}
		return "";
	}

	private ArrayList<String> getFileNamesAndParameters(String fileName) throws SAXException, IOException, ParserConfigurationException, XPathExpressionException, TransformerFactoryConfigurationError, TransformerException{

		Document doc;
		NodeList fileNameNode;
		NodeList VariableNode;
		Transformer xformer;

		doc = DocumentBuilderFactory.newInstance()
				.newDocumentBuilder().parse(new InputSource(fileName));
		// locate the node(s)
		XPath xpath = XPathFactory.newInstance().newXPath();

		fileNameNode = (NodeList)xpath.evaluate
				("//CSVDataSet/stringProp[@name='filename']", doc, XPathConstants.NODESET);

		VariableNode=(NodeList)xpath.evaluate
				("//CSVDataSet/stringProp[@name='variableNames']", doc, XPathConstants.NODESET);

		ArrayList<String> dataSets=new ArrayList<String>();
		
		String length=String.valueOf(fileNameNode.getLength());
		
		dataSets.add(length);

		if(fileNameNode.getLength()==VariableNode.getLength()){
			for (int idx = 0; idx < fileNameNode.getLength(); idx++) {

				dataSets.add(fileNameNode.item(idx).getTextContent());
				dataSets.add(VariableNode.item(idx).getTextContent());

			}
		}

		return dataSets;
	}

	private void deleteFile(String fileName){
		File file=new File(fileName);
		if(file.exists()){
			file.delete();
		}
	}

	public String getProperty(String key) throws IOException {
		Properties prop = new Properties();
		InputStream input = null;

		ServletContext context = getServletContext();
		String configPath = context.getRealPath("/WEB-INF/config/config.properties");
		input = new FileInputStream(configPath);

		// load a properties file
		prop.load(input);

		// get the property value
		return prop.getProperty(key);

	}

	private List<String> getAllAvailableFiles(String Upload_Dir ){
		File listAllFiles=new File(Upload_Dir);
		if (!listAllFiles.exists()) {
			listAllFiles.mkdirs();
		}
		List<String> jmxFile = new ArrayList<String>();
		for (File file : listAllFiles.listFiles()) {
			if (file.getName().endsWith((".jmx"))) {

				jmxFile.add(file.getName());
			}
		}
		return jmxFile;
	}
}
