/*var scriptName1;
$("#jobName").on('change',function(){
		scriptName1=$('#jobName').val().toString();
		$.ajax({
			url: "getDataSetInfo",
			type:"POST",
			data:{	
				scriptName1:scriptName1,
			},
			dataType: "json",
			success: function(json) {
				if(json=="0"){
				}else{
					if(confirm('Do you want to upload Data Files?')){
						 $("#grid2").css("display", "block");
						 for(i=1;i<json.length;i=i+2){
							var row = '<tr>';
				               row += '<td>'+json[i]+'</td>';
				               row += '<td>'+json[i+1]+'</td>';
				               row += '</tr>';
				               $('#test5').append(row);
						} 
						$("#grid3").css("display","block");
					}else{
						
					}	
				}				
			},
			error: function(e) {
				alert(e + " SERVER ERROR , TRY AGAIN LATER");
			}
		})
})	;

	var scriptName ="";
	var users="";
	var rampup="";
	var duration="";
	$("#execute-button").click(function(event) {
		scriptName=$('#jobName').val().toString();
		users=$('#input1').val().toString();
		rampup=$('#input2').val().toString();
		duration=$('#input3').val().toString();
		$.ajax({
			url: "execute",
			type:"POST",
			data:{	
				scriptName:scriptName,
				users:users,
				rampup:rampup,
				duration:duration
				  },
			dataType: "json",
			success: function(json) {
				if(json=="Success"){
					alert("Job successfully started in jenkins.");
					location.reload();
				}else if (json == "ConnectionFail") {
					alert("Unable to connect to jenkins. Please check config parameters.");
				}else if(json=="Fail"){
					alert("Unable to build job. Please contact your administrator.")
				}else{
					alert("Something went wrong.")
				}	 
				
			},
			error: function(e) {
				alert(e + " SERVER ERROR , TRY AGAIN LATER");
			}
		})
	});
*/