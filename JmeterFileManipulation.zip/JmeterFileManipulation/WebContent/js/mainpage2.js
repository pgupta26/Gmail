$(document).ready(function() {
$('#select,#selectscenario,#selectmodule,#selectscreen').select2({
//  theme: 'bootstrap'
});
$("form").submit(function(e) {
    e.preventDefault();
  });
$(function() {
	  $.ajax({
		url: "fetchscenariopage2.jsp",
	    dataType: "json",
	    success: function(json) {
	    	var data="";
	    	var select=$("#selectscenario");    
          for(i=0;i<json.length;i++){
             var element=JSON.parse(json[i]);
             var option = $('<option></option>').
 	        text(element.scenario).
 	        val(element.scenario).
 	        attr("id", element.id).
 	       attr("project_id", element.project_id).
 	      attr("module_id", element.module_id);
 	        option.appendTo(select);  	      
 	      }
	    },
	    error: function(e) {
//	      alert(e + " SERVER ERROR , TRY AGAIN LATER");
	    }
	  });
	});
$("#selectscenario").on("change", function() {
	 sessionStorage.setItem("scenario_req", "1");
	  sessionStorage.removeItem("project_id");
	  sessionStorage.removeItem("module_id");
	  sessionStorage.removeItem("scenario");
	  sessionStorage.setItem("scenario",$(this).val());
	  sessionStorage.setItem("project_id", $('#selectscenario').find("option:selected").attr("project_id"));
	  sessionStorage.setItem("module_id",$(this).find("option:selected").attr("module_id"));
	  $("#select").val(sessionStorage.getItem("project_id")).trigger('change');
});
});

$(document).on('click', '#clr', function () {
//	alert('');
	$('table > tbody > tr').remove();
	$("#selectscenario").val("");
	sessionStorage.removeItem("project_id");
	  sessionStorage.removeItem("module_id");
	  sessionStorage.removeItem("scenario");
	  sessionStorage.removeItem("scenario_req");
	  location.reload(true);
});
$(function() {
	  $.ajax({
		url: "fetch.jsp",
	    dataType: "json",
	    success: function(json) {
	    	var data="";
	    	var select=$("#select");    
            for(i=0;i<json.length;i++){
               var element=JSON.parse(json[i]);
               var option = $('<option></option>').
   	        text(element.project_name).
   	        val(element.project_id).
   	        attr("id", element.project_id);
   	        option.appendTo(select);  	      
//   	        select.trigger('change');
   	      }
//            $("select").select2({
//     	          theme: 'bootstrap',
//     	        });
            if (sessionStorage.getItem("project_id")!=null) {
   			 $("#select").val(sessionStorage.getItem("project_id")).trigger('change');
   			
   		}
	    },
	    error: function(e) {
//	      alert(e + " SERVER ERROR , TRY AGAIN LATER");
	    }
	  });
//	  $('#select').on('select2:open', function (e) {
//		    // select2 is opened, handle event
//		  sessionStorage.removeItem("scenario_req");
//		  sessionStorage.removeItem("project_id");
//		  sessionStorage.removeItem("module_id");
//		  sessionStorage.removeItem("scenario");
//		  
//		});
$("#select").on("change", function() {
	if(sessionStorage.getItem("scenario_req")=="1"){
		if (sessionStorage.getItem("project_id")!=null) {
	
		$('#selectmodule')
	    .find('option')
	    .remove()
	    .end()
	    .append('<option></option>')
	    .val('')
	;
		
		$("#selectmodule").val("");
		$.ajax({
			  type:"POST",
			  data:{project_id:sessionStorage.getItem("project_id")},
				url: "fetchmodule.jsp",
			    dataType: "json",
			    success: function(json) {
//			    	alert(json);
			    	var data="";
			    	var select=$("#selectmodule");    
		            for(i=0;i<json.length;i++){
		               var element=JSON.parse(json[i]);
		               var option = $('<option></option>').
		   	        text(element.module_name).
		   	        val(element.module_id).
		   	        attr("id", element.module_id);
		   	        option.appendTo(select);  	      
//		   	        select.trigger('change');
		   	      }
//		            $("select").select2({
//		     	          theme: 'bootstrap',
//		     	        });
		            if (sessionStorage.getItem("module_id")!=null) {
		            $("#selectmodule").val(sessionStorage.getItem("module_id")).trigger('change');
		            }
		            },
			    error: function(e) {
//			      alert(e + " SERVER ERROR , TRY AGAIN LATER");
			    }
			  });
		this.project_id = $(this).find("option:selected").attr("id");
		
	
	
}}
		else{
		
	sessionStorage.setItem("project_id",$(this).find("option:selected").attr("id"));
	  $('#selectmodule')
	    .find('option')
	    .remove()
	    .end()
	    .append('<option></option>')
	    .val('')
	;
	  $.ajax({
		  type:"POST",
		  data:{project_id:sessionStorage.getItem("project_id")},
			url: "fetchmodule.jsp",
		    dataType: "json",
		    success: function(json) {
//		    	alert(json);
		    	var data="";
		    	var select=$("#selectmodule");    
	            for(i=0;i<json.length;i++){
	               var element=JSON.parse(json[i]);
	               var option = $('<option></option>').
	   	        text(element.module_name).
	   	        val(element.module_id).
	   	        attr("id", element.module_id);
	   	        option.appendTo(select);  	      
//	   	        select.trigger('change');
	   	      }
//	            $("select").select2({
//	     	          theme: 'bootstrap',
//	     	        });
		    },
		    error: function(e) {
//		      alert(e + " SERVER ERROR , TRY AGAIN LATER");
		    }
		  });
	}
});

$("#selectmodule").on("change", function() {
	if(sessionStorage.getItem("scenario_req")=="1"){
	if(sessionStorage.getItem("scenario")!=null){
		
		$('#selectscreen')
	    .find('option')
	    .remove()
	    .end()
	    .append('<option></option>')
	    .val('')
	;
		$("#selectscreen").val("");
		  $.ajax({
			  type:"POST",
			  data:{
				
				  module_id:sessionStorage.getItem("module_id"),
				  project_id:sessionStorage.getItem("project_id"),
			  },
				url: "fetchscenario.jsp",
			    dataType: "json",
			    success: function(json) {
//			    	alert(json);
			    	var data="";
			    	var select=$("#selectscreen");    
		            for(i=0;i<json.length;i++){
		               var element=JSON.parse(json[i]);
		               var option = $('<option></option>').
		   	        text(element.scenario).
		   	        val(element.scenario).
		   	        attr("id", element.scenario);
		   	        option.appendTo(select);  	      
//		   	        select.trigger('change');
		   	      }
//		            $("select").select2({
//		     	          theme: 'bootstrap',
//		     	        });
		            $("#selectscreen").val(sessionStorage.getItem("scenario")).trigger('change');
		            
			    },
			    error: function(e) {
//			      alert(e + " SERVER ERROR , TRY AGAIN LATER");
			    }
			  });
		  this.module_id = $(this).find("option:selected").attr("id");
		 
		
	}}
	else if(sessionStorage.getItem("scenario")!=null){
		
		$('#selectscreen')
	    .find('option')
	    .remove()
	    .end()
	    .append('<option></option>')
	    .val('')
	;
		$("#selectscreen").val("");
		  $.ajax({
			  type:"POST",
			  data:{
				
				  module_id:sessionStorage.getItem("module_id"),
				  project_id:sessionStorage.getItem("project_id"),
			  },
				url: "fetchscenario.jsp",
			    dataType: "json",
			    success: function(json) {
//			    	alert(json);
			    	var data="";
			    	var select=$("#selectscreen");    
		            for(i=0;i<json.length;i++){
		               var element=JSON.parse(json[i]);
		               var option = $('<option></option>').
		   	        text(element.scenario).
		   	        val(element.scenario).
		   	        attr("id", element.scenario);
		   	        option.appendTo(select);  	      
//		   	        select.trigger('change');
		   	      }
//		            $("select").select2({
//		     	          theme: 'bootstrap',
//		     	        });
		            $("#selectscreen").val(sessionStorage.getItem("scenario")).trigger('change');
		            
			    },
			    error: function(e) {
//			      alert(e + " SERVER ERROR , TRY AGAIN LATER");
			    }
			  });
		  this.module_id = $(this).find("option:selected").attr("id");
		 
		
	}
	else{
	
		sessionStorage.setItem("module_id",$(this).find("option:selected").attr("id"));
		
//	  alert(project_id);
//	  alert("Selected value is: "+$(this).select2("val"));
	  $('#selectscreen')
	    .find('option')
	    .remove()
	    .end()
	    
	    .val('')
	;
	  $("#selectscreen").val("");
	  $.ajax({
		  type:"POST",
		  data:{
			
			  module_id:sessionStorage.getItem("module_id"),
			  project_id:sessionStorage.getItem("project_id"),
		  },
			url: "fetchscenario.jsp",
		    dataType: "json",
		    success: function(json) {
//		    	alert(json);
		    	var data="";
		    	var select=$("#selectscreen");    
	            for(i=0;i<json.length;i++){
	               var element=JSON.parse(json[i]);
	               var option = $('<option></option>').
	   	        text(element.scenario).
	   	        val(element.scenario).
	   	        attr("id", element.scenario);
	   	        option.appendTo(select);  	      
	   	        select.trigger('change');
	   	      }
//	            $("select").select2({
//	     	          theme: 'bootstrap',
//	     	        });
		    },
		    error: function(e) {
//		      alert(e + " SERVER ERROR , TRY AGAIN LATER");
		    }
		  });
	}
	  
});
function unique(list) {
	  var result = [];
	  $.each(list, function(i, e) {
	    if ($.inArray(e, result) == -1) result.push(e);
	  });
	  return result;
	}
$("tbody").sortable({
    items: "> tr",
    appendTo: "parent",
    helper: "clone"
}).disableSelection();
var testcase_id="";
var scenario_name="";
$("#selectscreen").on("change", function() {
//    alert($("#selectscreen").val());
//    var s = "'" + $("#selectscreen").val() + "'";
	if(sessionStorage.getItem("scenario_req")=="1"){
		 $("#search").trigger("click");
		
		 $('#select').prop('disabled', 'disabled');
		 $('#selectmodule').prop('disabled', 'disabled');
		 $('#selectscreen').prop('disabled', 'disabled');
		 $('#search').prop('disabled', 'disabled');
	}
	else{
		sessionStorage.setItem("scenario",$("#selectscreen").val());
		
	}
	
	});
$("#search").click(function(event) {
	if(sessionStorage.getItem("project_id")===null||sessionStorage.getItem("module_id")===null||sessionStorage.getItem("scenario")===null){
//		alert("please enter all fields");
	}else{
		sessionStorage.setItem("scenario_req", "1");
//	$("#test1 tr").remove();
	$('table > tbody > tr').remove();
//	alert(scenario_name);
	 $.ajax({
		  type:"POST",
		  data:{
			  		project_id:sessionStorage.getItem("project_id"),
			  		module_id:sessionStorage.getItem("module_id"),
			  		scenario_name:sessionStorage.getItem("scenario"),
			  },
			url: "fetchscenario1.jsp",
		    dataType: "json",
		    success: function(json) {
//		    	alert("sucess");
//		    	alert(json);
		    	if(json!=0){
//			    	var row = '<tr>';
		            for(i=0;i<json.length;i++){
		               var element=JSON.parse(json[i]);
		               var row = '<tr>';
		               row += '<td>' + (i + 1) + '<input id="screen_id" name="screen_id" type="hidden" value="'+element.screen_id+'"></td>';
		               row += '<td><input type="text" class="name form-control"  name="name" value="' + element.name + '" id="name' + element.screen_id + '" id="name' + element.screen_id + '"></td>';
		               row += '<td ><input type="text" name="desc"  class="form-control" value="' + element.description + '" id="desc' + element.screen_id + '" /></td>';
		               row += '<td ><input type="text" name="sla" class="form-control" readonly value="'+element.sla+'" id="sla' + element.screen_id + '" /></td>';
		               row += '<td ><input type="text" name="tph" class="form-control" readonly value="'+element.tph+'" id="tph' + element.screen_id + '" /></td>';
		               row += '<td ><input type="text" name="user" class="form-control" readonly value="'+element.user+'" id="user' + element.screen_id + '" /></td>';
		               row += '<td ><input type="text" name="trans" class="form-control" value="'+element.transaction+'" id="trans' + element.screen_id + '" /></td>';
		        	   
//		               row += '<td><button type="button" class="btn btn-primary text-center"  id="' + element.id + '" name="edit"><i class="mdi mdi-account-edit"></i>Edit</button><button type="button" class="btn btn-success btn-xs okcancel" name="ok" id="ok' + element.id + '" name=""><i class="mdi mdi-check">ok</i></button><button type="button" class="btn btn-danger text-center btn-xs okcancel" name="cancel"  id="cancel' + element.id + '" name=""><i class="mdi mdi-close">cancel</i></button></td>';
		               row += '<td><button type="button" class="btn btn-danger text-center"  id="' + element.id + '" name="delete"><i class="mdi mdi-close-circle"></i>Delete</button></td>';
		               row += '</tr>';
		               
		               $('table tbody').append(row);
		              
		   	      }
		            $('#sla').val(element.sla);
		            $('#tph').val(element.tph);
		            $('#user').val(element.user);
	//alert(row);
			    	}else{
			    		$('table > tbody > tr').remove();
			    		$("#selectscenario").val("");
			    		sessionStorage.removeItem("project_id");
			    		  sessionStorage.removeItem("module_id");
			    		  sessionStorage.removeItem("scenario");
			    		  sessionStorage.removeItem("scenario_req");
			    		  location.reload(true);
			    		
			    	}	
		    	
		    },
		    error: function(e) {
//		      alert(e + " SERVER ERROR , TRY AGAIN LATER");
		    }
		  });
	}
});
function loadtable(){
	
	$('table > tbody > tr').remove();
//	alert(scenario_name);
	 $.ajax({
		  type:"POST",
		  data:{
			  		project_id:sessionStorage.getItem("project_id"),
			  		module_id:sessionStorage.getItem("module_id"),
			  		scenario_name:sessionStorage.getItem("scenario"),
			  },
			url: "fetchscenario1.jsp",
		    dataType: "json",
		    success: function(json) {
//		    	alert("sucess");
//		    	alert(json);
		    	if(json!=0){
//		    	var row = '<tr>';
	            for(i=0;i<json.length;i++){
	               var element=JSON.parse(json[i]);
	               var row = '<tr>';
	               row += '<td>' + (i + 1) + '<input id="screen_id" name="screen_id" type="hidden" value="'+element.screen_id+'"></td>';
	               row += '<td><input type="text" class="name form-control"  name="name" value="' + element.name + '" id="name' + element.screen_id + '" id="name' + element.screen_id + '"></td>';
	               row += '<td ><input type="text" name="desc"  class="form-control" value="' + element.description + '" id="desc' + element.screen_id + '" /></td>';
	               row += '<td ><input type="text" name="sla" class="form-control" readonly value="'+element.sla+'" id="sla' + element.screen_id + '" /></td>';
	               row += '<td ><input type="text" name="tph" class="form-control" readonly value="'+element.tph+'" id="tph' + element.screen_id + '" /></td>';
	               row += '<td ><input type="text" name="user" class="form-control" readonly value="'+element.user+'" id="user' + element.screen_id + '" /></td>';
	               row += '<td ><input type="text" name="trans" class="form-control" value="'+element.transaction+'" id="trans' + element.screen_id + '" /></td>';
	        	   
//	               row += '<td><button type="button" class="btn btn-primary text-center"  id="' + element.id + '" name="edit"><i class="mdi mdi-account-edit"></i>Edit</button><button type="button" class="btn btn-success btn-xs okcancel" name="ok" id="ok' + element.id + '" name=""><i class="mdi mdi-check">ok</i></button><button type="button" class="btn btn-danger text-center btn-xs okcancel" name="cancel"  id="cancel' + element.id + '" name=""><i class="mdi mdi-close">cancel</i></button></td>';
	               row += '<td><button type="button" class="btn btn-danger text-center"  id="' + element.id + '" name="delete"><i class="mdi mdi-close-circle"></i>Delete</button></td>';
	               row += '</tr>';
	               
	               $('table tbody').append(row);
	              
	   	      }
	            $('#sla').val(element.sla);
	            $('#tph').val(element.tph);
	            $('#user').val(element.user);
//alert(row);
		    	}else{
		    		$('table > tbody > tr').remove();
		    		$("#selectscenario").val("");
		    		sessionStorage.removeItem("project_id");
		    		  sessionStorage.removeItem("module_id");
		    		  sessionStorage.removeItem("scenario");
		    		  sessionStorage.removeItem("scenario_req");
		    		  location.reload(true);
		    		
		    	}	
		    },
		    error: function(e) {
//		      alert(e + " SERVER ERROR , TRY AGAIN LATER");
		    }
		  });
	
}
$(document).on("click", "button[name = 'delete']", function() {
    var id = $(this).attr('id');
    $.ajax({
      url: "delete.jsp",
      type: "POST",
      data: {
				
        id: id,
      },
      success: function(e) {
    	  
       // alert(JSON.stringify(json));
       // $('table tbody #'+id).closest('tr').remove();
      loadtable();
      },
      error: function(e) {
//        alert(e);
      }
    });
  });
	 var scenario="";
	 var sla="";
	 var tph="";
	 var username="";
	 var d_name=[];
	 var d_desc=[];
	 var d_order=[];
	 var d_trans=[];
	 var d_scenario_order=[];
	 var screen_id=[];
	 var i1=0;
	 $(document).on('keyup', "#scenario", function(e) {
		    scenario = $(this).val();
		  });
	 $(document).on('keyup', "#sla", function(e) {
		    sla = $(this).val();
		  });
	 $(document).on('keyup', "#tpa", function(e) {
		    tph = $(this).val();
		  });
	 $(document).on('keyup', "#username", function(e) {
		    username = $(this).val();
		  });
	 
	 
	 
	 
	 
	 
	 $(document).on("click", "#save", function(event) {
		 var isValid;
		 $("input:not([type=search])").each(function() {
		    var element = $(this);
		    if (element.val() == "") {
//		    	alert($(this).attr('type'));
		        isValid = true;
		    }
		 });
		if(isValid){
			alert("Please Input all fields..!!");
		 }else{
//	alert(scenario+sla+tpa+username);
//			 sessionStorage.setItem("project_id", project_id);
//			  sessionStorage.setItem("module_id", module_id);
//			  sessionStorage.setItem("scenario", scenario);
//	
	
	var table = $("#test1 tbody");

    table.find('tr').each(function (i) {
        var $tds = $(this).find('td');
        i1++;    
        //d_screen.push($tds.eq(0).find("input").val());
        d_order.push(i1);
        
            screen_id.push($tds.eq(0).find("input").val());
//            alert(screen_id);
            d_name.push($tds.eq(1).find("input").val());
            d_desc.push($tds.eq(2).find("input").val());
            d_trans.push($tds.eq(6).find("input").val());
            
        // do something with productId, product, Quantity 
//        alert(d_name);
    });
    var sla = $('#sla').val();
    var tph = $('#tph').val();
    var user = $('#user').val(); 
    
//	alert(sessionStorage.getItem("project_id")+
//			  sessionStorage.getItem("module_id")+
//			  sessionStorage.getItem("scenario"));
	 $.ajax({
		  type:"POST",
		  data:{	project_id:sessionStorage.getItem("project_id"),
			  module_id:sessionStorage.getItem("module_id"),
			  scenario:sessionStorage.getItem("scenario"),
			  screen_id:screen_id,
			  		 d_name:d_name,
			  		d_desc:d_desc,
			  		d_order:d_order,
			  		sla:sla,
			  		tph:tph,
			  		user:user,
			  		d_trans:d_trans,
			  },
			url: "storescreen2.jsp",
		    dataType: "json",
		    success: function(json) {
		    	alert("Saved Successfully");
		    	location.reload(true);
		    	
		    },
		    error: function(e) {
//		      alert(e + " SERVER ERROR , TRY AGAIN LATER");
		    }
		  });
		 
		 }
	 });
});