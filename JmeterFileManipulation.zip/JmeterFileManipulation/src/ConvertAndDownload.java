import java.io.*;
import java.util.Properties;

import javax.servlet.ServletException;  
import javax.servlet.http.*;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;


@SuppressWarnings("serial")
@javax.servlet.annotation.MultipartConfig(fileSizeThreshold=1024*1024*10, 	// 10 MB 
maxFileSize=1024*1024*50,      						// 50 MB
maxRequestSize=1024*1024*100)  
public class ConvertAndDownload extends HttpServlet {  

	String filepath;
	String fileName;
	Document doc;
	NodeList loopCountNode;
	Transformer xformer;

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response)  
			throws ServletException, IOException {  

		//Upload file
		Part part=request.getPart("fname");

		//Get upload directory path
		filepath=getProperty("Upload_Dir").trim();

		//get file name from the request
		fileName = getFileName(part);
		int i=fileName.lastIndexOf("\\");
		fileName=fileName.substring(i+1);

		//write file into file system
		part.write(filepath+fileName);

		//Update file
		String download_Dir=getProperty("Download_Dir").trim();
		updatxJmx.updateFile(filepath, fileName, download_Dir);

		//Download Uploaded File
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		response.setContentType("APPLICATION/OCTET-STREAM"); 
		response.setHeader("Content-Disposition","attachment; filename=\"" + fileName + "\""); 

		java.io.FileInputStream fileInputStream = new java.io.FileInputStream(download_Dir + fileName);

		while ((fileInputStream.read()) != -1) {
			out.write(i); 
		} 
		fileInputStream.close(); 
		out.close(); 
	}

	public String getFileName(Part part) {
		String contentDisp = part.getHeader("content-disposition");
		String[] tokens = contentDisp.split(";");
		for (String token : tokens) {
			if (token.trim().startsWith("filename")) {
				return token.substring(token.indexOf("=") + 2, token.length()-1);
			}
		}
		return "";
	}

	public String getProperty(String key) throws IOException {
		Properties prop = new Properties();
		InputStream input = null;

		javax.servlet.ServletContext context = getServletContext();
		String configPath = context.getRealPath("/WEB-INF/config/config.properties");
		input = new FileInputStream(configPath);

		// load a properties file
		prop.load(input);

		// get the property value
		return prop.getProperty(key);
	}
}  