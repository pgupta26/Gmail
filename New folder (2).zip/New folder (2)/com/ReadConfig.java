package com;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ReadConfig {
	
	public static void main(String[] args){ 
		String jenkins_url=getProperty("Jenkins_Url");
		System.out.println(jenkins_url);
	}
	
	private static String getProperty(String key) {
		Properties prop = new Properties();
		InputStream input = null;
		
		try {

			input = new FileInputStream("./config/config.properties");

			// load a properties file
			prop.load(input);

			// get the property value and print it out
			return prop.getProperty(key);

		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		 return "";
	}
}
