package com;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.servlet.ServletContext;
import javax.xml.bind.DatatypeConverter;

public class Test {

	public static void main(String[] args) {
		
		/*try {
		      URL url = new URL ("http://10.74.230.180:8080/job/Test//buildWithParameters"); // Jenkins URL localhost:8080, job named 'test'
		      String user = "admin"; // username
		      String pass = "admin123"; // password or API token
		      String authStr = user +":"+  pass;
		      String encoding = DatatypeConverter.printBase64Binary(authStr.getBytes("utf-8"));

		      HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		      connection.setRequestMethod("POST");
		      connection.setDoOutput(true);
		      connection.setRequestProperty("Authorization", "Basic " + encoding);
		      
		      String urlParams="Users=123&RampUpTime=342&Iterations=678";
		      byte[] postData = urlParams.getBytes("utf-8");
		      try(DataOutputStream wr = new DataOutputStream(connection.getOutputStream())) {
		        wr.write(postData);
		      }

		      InputStream content = connection.getInputStream();
		      BufferedReader in   =
		          new BufferedReader (new InputStreamReader (content));
		      String line;
		      while ((line = in.readLine()) != null) {
		        System.out.println(line);
		      }
		    } catch(Exception e) {
		      e.printStackTrace();
		    }*/
	}
}
