package com;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;


@MultipartConfig(fileSizeThreshold=1024*1024*10, 	// 10 MB 
maxFileSize=1024*1024*50,      						// 50 MB
maxRequestSize=1024*1024*100)   					// 100 MB
public class UploadServlet extends HttpServlet {

	/* private String UPLOAD_DIR=null;
	
	@Override
	public void init() throws ServletException {
		super.init();
		UPLOAD_DIR =getServletContext().getRealPath(getServletContext().getContextPath());
		UPLOAD_DIR=  UPLOAD_DIR.substring(0, UPLOAD_DIR.lastIndexOf("\\"))+"/Uploads/";
	}*/

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		
		ServletContext context = getServletContext();
		String UPLOAD_DIR = context.getRealPath("/WEB-INF/Uploads");
		
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		String fileName = null;
		
		// creates the save directory if it does not exists
		File fileSaveDir = new File(UPLOAD_DIR);
		if (!fileSaveDir.exists()) {
			fileSaveDir.mkdirs();
		}

		//Get all the parts from request and write it to the file on server
		Part part=req.getPart("fname");

		fileName = getFileName(part);
		
		int i=fileName.lastIndexOf("\\");
		fileName=fileName.substring(i+1);

		part.write(UPLOAD_DIR + File.separator + fileName);

		RequestDispatcher rd=req.getRequestDispatcher("uploadScript.jsp");
		out.println("Script "+fileName+" uploaded successfully!!");
		rd.include(req, res);

	}

	private String getFileName(Part part) {
		String contentDisp = part.getHeader("content-disposition");
		String[] tokens = contentDisp.split(";");
		for (String token : tokens) {
			if (token.trim().startsWith("filename")) {
				return token.substring(token.indexOf("=") + 2, token.length()-1);
			}
		}
		return "";
	}

}
