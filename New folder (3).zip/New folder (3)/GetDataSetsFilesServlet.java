package com;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.google.gson.Gson;

@SuppressWarnings("serial")
public class GetDataSetsFilesServlet extends HttpServlet {
	
	private String Upload_Dir;
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {

		try{
			
			UploadServlet2 obj=new UploadServlet2();
			
			//get request parameter
			String jobName=req.getParameter("scriptName1").trim();
				
			//Read properties
			Upload_Dir=getProperty("Upload_Dir").trim()+File.separator+jobName;;	
			
			//retrieve csv file names and parameters
			ArrayList<String> fileNames=new ArrayList<String>();

			fileNames=obj.getFileNamesAndParameters(Upload_Dir + File.separator + jobName+".jmx");

			String json = new Gson().toJson(fileNames);

			res.setContentType("application/json");
			res.getWriter().write(json);
			
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	public String getProperty(String key) throws IOException {
		Properties prop = new Properties();
		InputStream input = null;

		ServletContext context = getServletContext();
		String configPath = context.getRealPath("/WEB-INF/config/config.properties");
		input = new FileInputStream(configPath);

		// load a properties file
		prop.load(input);

		// get the property value
		return prop.getProperty(key);

	}


}
