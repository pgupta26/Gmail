package com;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.google.gson.Gson;

@SuppressWarnings("serial")
public class UploadCsvBuildServlet extends HttpServlet {
	
	private String Upload_Dir;
	private String fileName;
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {

		try{
			//get request parameter
			String scriptNameWithoutJmx=req.getParameter("scriptName2");
			
			//Get all the parts from request and write it to the file on server
			Part part=req.getPart("cname1");

			//get file name from the request
			fileName = getFileName(part);

			int i=fileName.lastIndexOf("\\");
			fileName=fileName.substring(i+1);
						
			//Read properties
			Upload_Dir=getProperty("Upload_Dir").trim()+File.separator+scriptNameWithoutJmx;
			
			
			// creates the save directory if it does not exists
			File fileSaveDir = new File(Upload_Dir);
			if (!fileSaveDir.exists()) {
				fileSaveDir.mkdirs();
			}

			//write file into file system
			part.write(Upload_Dir + File.separator + fileName);

			String json = new Gson().toJson(fileName);

			res.setContentType("application/json");
			res.getWriter().write(json);

		}catch(Exception ex){
			String fail="1";

			String json = new Gson().toJson(fail);

			res.setContentType("application/json");
			res.getWriter().write(json);
		}
	}

	private String getFileName(Part part) {
		String contentDisp = part.getHeader("content-disposition");
		String[] tokens = contentDisp.split(";");
		for (String token : tokens) {
			if (token.trim().startsWith("filename")) {
				return token.substring(token.indexOf("=") + 2, token.length()-1);
			}
		}
		return "";
	}

	private void deleteFile(String fileName){
		File file=new File(fileName);
		if(file.exists()){
			file.delete();
		}
	}

	public String getProperty(String key) throws IOException {
		Properties prop = new Properties();
		InputStream input = null;

		ServletContext context = getServletContext();
		String configPath = context.getRealPath("/WEB-INF/config/config.properties");
		input = new FileInputStream(configPath);

		// load a properties file
		prop.load(input);

		// get the property value
		return prop.getProperty(key);

	}


}
