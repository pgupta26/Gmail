$(document).ready(function() {
	sessionStorage.removeItem("project_id");
	  sessionStorage.removeItem("module_id");
	  sessionStorage.removeItem("scenario");
	  sessionStorage.removeItem("scenario_req");
$('#select,#selectmodule,#selecttestcase,#selectpro').select2({
//  theme: 'bootstrap'
});
$("form").submit(function(e) {
    e.preventDefault();
  });

$("#selectpro").on("change", function() {
	  $('#select')
	    .find('option')
	    .remove()
	    .end()
	    .append('<option></option>')
	    .val('')
	;
	var app_name=$(this).find("option:selected").text();
//	alert(app_name);
	  $.ajax({
		  type:"POST",
		  data:{app_name:app_name},
			url: "fetch2.jsp",
		    dataType: "json",
	    success: function(json) {
	    	var data="";
	    	var select=$("#select");    
            for(i=0;i<json.length;i++){
               var element=JSON.parse(json[i]);
               var option = $('<option></option>').
   	        text(element.project_name).
   	        val(element.project_id).
   	        attr("id", element.project_id);
   	        option.appendTo(select);  	      
//   	        select.trigger('change');
   	      }
//            $("select").select2({
//     	          theme: 'bootstrap',
//     	        });
	    },
	    error: function(e) {
	      alert(e + " SERVER ERROR , TRY AGAIN LATER");
	    }
	  });
	});

var project_id="";
$("#select").on("change", function() {
	  project_id = $(this).find("option:selected").attr("id");
//	  alert(project_id);
	  $('#selectmodule')
	    .find('option')
	    .remove()
	    .end()
	    .append('<option></option>')
	    .val('')
	;
	  $.ajax({
		  type:"POST",
		  data:{project_id:project_id},
			url: "fetchmodule.jsp",
		    dataType: "json",
		    success: function(json) {
//		    	alert(json);
		    	var data="";
		    	var select=$("#selectmodule");    
	            for(i=0;i<json.length;i++){
	               var element=JSON.parse(json[i]);
	               var option = $('<option></option>').
	   	        text(element.module_name).
	   	        val(element.module_id).
	   	        attr("id", element.module_id);
	   	        option.appendTo(select);  	      
//	   	        select.trigger('change');
	   	      }
//	            $("select").select2({
//	     	          theme: 'bootstrap',
//	     	        });
		    },
		    error: function(e) {
		      alert(e + " SERVER ERROR , TRY AGAIN LATER");
		    }
		  });
	  
});
var module_id="";
$("#selectmodule").on("change", function() {
	
	  module_id = $(this).find("option:selected").attr("id");
	
//	  alert(module_id);
//	  alert("Selected value is: "+$(this).select2("val"));
	  $('#selecttestcase')
	    .find('option')
	    .remove()
	    .end()
	    
	    .val('')
	;
	  $("#selecttestcase").val("");
	  $.ajax({
		  type:"POST",
		  data:{module_id:module_id},
			url: "fetchtestcase.jsp",
		    dataType: "json",
		    success: function(json) {
//		    	alert(json);
		    	var data="";
		    	var select=$("#selecttestcase");    
	            for(i=0;i<json.length;i++){
	               var element=JSON.parse(json[i]);
	               var option = $('<option></option>').
	   	        text(element.testcase_name).
	   	        val(element.testcase_id).
	   	        attr("id", element.id);
	   	        option.appendTo(select);  	      
//	   	        select.trigger('change');
	   	      }
//	            $("select").select2({
//	     	          theme: 'bootstrap',
//	     	        });
		    },
		    error: function(e) {
		      alert(e + " SERVER ERROR , TRY AGAIN LATER");
		    }
		  });
	  
});
$("tbody").sortable({
    items: "> tr",
    appendTo: "parent",
    helper: "clone"
}).disableSelection();
var testcase_id="";
$("#selecttestcase").on("change", function() {
//    alert($("#selecttestcase").val());
    testcase_id = $("#selecttestcase").val().toString();
});
var scenario="";
var sla="";
var tph="";
var username="";
$("#search").click(function(event) {
	$("#test tr").remove();
	$('#test1 tbody > tr').remove();
	$.ajax({
		  type:"POST",
		  data:{	
			  scenario:scenario,
			  
			  },
			url: "checkscenario.jsp",
		    
		    success: function(json) {
//		    	alert(json);
		    	if(json=="1"){
		    		alert("scenario already exist!!");	
		    		$("#scenario").val("");
		    	}else{
		    		if(scenario==""||sla==""||tph==""||username==""||project_id==""||module_id==""||testcase_id==""){
//		    			alert();
		    		}else{
//		    		$("#test tr").remove();
//		    		$('#test1 tbody > tr').remove();
//		    		alert(testcase_id);
		    		 $.ajax({
		    			  type:"POST",
		    			  data:{
		    				  		testcase_id:testcase_id,
		    				  		module_id:module_id,
		    				  },
		    				url: "fetchtestcasetable.jsp",
		    			    dataType: "json",
		    			    success: function(json) {
		    			    	
//		    			    	alert(json);
		    			    	
//		    			    	var row = '<tr>';
		    		            for(i=0;i<json.length;i++){
		    		               var element=JSON.parse(json[i]);
		    		               var row = '<tr>';
		    		               row += '<td >' + (i + 1) + '<input id="screen_id" name="screen_id" type="hidden" value="'+element.id+'"></td>';
		    		               row += '<td><input type="text" class="name form-control"  name="name" required value="' + element.name + '" id="name' + element.id + '" id="name' + element.id + '"></td>';
		    		               row += '<td ><input type="text" name="desc"  class="form-control" required value="' + element.description + '" id="desc' + element.id + '" /></td>';
		    		               row += '<td ><input type="text" name="trans" class="form-control" value="" id="trans' + element.id + '" required /></td>';
		    		        	   
//		    		               row += '<td><button type="button" class="btn btn-primary text-center"  id="' + element.id + '" name="edit"><i class="mdi mdi-account-edit"></i>Edit</button><button type="button" class="btn btn-success btn-xs okcancel" name="ok" id="ok' + element.id + '" name=""><i class="mdi mdi-check">ok</i></button><button type="button" class="btn btn-danger text-center btn-xs okcancel" name="cancel"  id="cancel' + element.id + '" name=""><i class="mdi mdi-close">cancel</i></button></td>';
//		    		               row += '<td><button type="button" class="btn btn-danger text-center"  id="' + element.id + '" name="delete"><i class="mdi mdi-close-circle"></i>Delete</button></td>';
		    		               row += '</tr>';
		    		               $('#test').append(row);
		    		              
		    		   	      }
		    	//alert(row);
		    			    	
		    			    },
		    			    error: function(e) {
		    			      alert(e + " SERVER ERROR , TRY AGAIN LATER");
		    			    }
		    			  });
		    		}
		    	}
		    },
		    error: function(e) {
		      alert(e + " SERVER ERROR , TRY AGAIN LATER");
		    }
		  });
	
});
	 var scenario="";
	 var sla="";
	 var tph="";
	 var username="";
	 var d_name=[];
	 var d_desc=[];
	 var d_trans=[];
	 var screen_id=[];
	 var n=0;
	 $(document).on('keyup', "#scenario", function(e) {
		    scenario = $(this).val();
//		    alert(scenario);
		  });
	 $(document).on('keyup', "#sla", function(e) {
		    sla = $(this).val();
		  });
	 $(document).on('keyup', "#tph", function(e) {
		    tph = $(this).val();
		  });
	 $(document).on('keyup', "#username", function(e) {
		    username = $(this).val();
		  });
	$(document).on("click", "#save", function(event) {
		 var isValid;
		 $("input:not([type=search])").each(function() {
		    var element = $(this);
		    if (element.val() == "") {
//		    	alert($(this).attr('type'));
		        isValid = true;
		    }
		 });
		if(isValid){
//			alert("Please ");
		}else{
			
			var table = $("#test1 tbody");
		 	table.find('tr').each(function (i) {
		 		var $tds = $(this).find('td');
		 				 			screen_id.push($tds.eq(0).find("input").val()),
		 			d_name.push($tds.eq(1).find("input").val());
		 			d_desc.push($tds.eq(2).find("input").val());
		 			d_trans.push($tds.eq(3).find("input").val());
		 		
//		 			alert("s : "+screen_id+"\n n:"+d_name);
		 				 		
		 	});
		 	$.ajax({
				  type:"POST",
				  data:{	
					  scenario:scenario,
					  sla:sla,
					  tph:tph,
					  username:username,
					  project_id:project_id,
					  screen_id:screen_id,
					  d_name:d_name,
					  d_desc:d_desc,
					  d_trans:d_trans,
					  module_id:module_id,
					  },
					url: "storescreen.jsp",
				    dataType: "json",
				    success: function(json) {
				    	alert("Scenario stored Successfully..!!");
				    	location.reload(true);
				    	
				    },
				    error: function(e) {
				      alert(e + " SERVER ERROR , TRY AGAIN LATER");
				    }
				  });	
		}
	});
});