$(document).ready(function() {
	$("form").submit(function(e) {
		e.preventDefault();
	});

	var jobName="";
	$("#getReport1").click(function(event) {
		jobName=$('#jobName').val().toString();
		$("#test tr").remove();
		$("#header tr").remove();
		$('#test1 thead > tr').remove();
		$('#test1 tbody > tr').remove();
		$.ajax({
			url: "resultsCompaison",
			type:"POST",
			data:{	
				jobName1:jobName,
			},
			dataType: "json",
			success: function(json) {
					if(json=="Not Build"){
							alert("This build is not yet executed even a single time.")
							location.reload();
					}else if(json=="BuildNotAvailable"){
							alert("Results comparison not available. For comparison, there should be atleast 2 builds available.")
							location.reload();
					}else if(json=="MissingFile"){
						alert("Missing results file.")
						location.reload();
					}else{
						$("#grid").css("display", "block");
						var row = '<tr>';
					        row += '<th rowspan="2">Sr.no.</th>';
					        row += '<th rowspan="2">Transaction Names</th>';
					               row += '<th colspan="2">Build #'+json[0][4]+'<br/> Users: '+json[0][5]+' Ramp: '+json[0][6]+' Duration: '+json[0][7]+'</th>';
					               row += '<th colspan="2">Build #'+json[0][0]+'<br/> Users: '+json[0][1]+' Ramp: '+json[0][2]+' Duration: '+json[0][3]+'</th>';
					               row += '<th rowspan="2">Stand. Deviation</th>';
					               row += '</tr>';
					               row += '<tr>';
					               row += '<th>Sample #</th>';
					               row += '<th>Average Resp.Time </th>';
					               row += '<th>Sample #</th>';
					               row += '<th>Average Resp.Time </th>';
					               row += '</tr>';
					               $('#header').append(row);
					               
					             for(i=1;i<json.length;i++){
					            	if(json[i][5] < 0){
					            		var row = '<tr class="danger" style="background-color:green;">';
							               row += '<td>'+(i)+'</td>';
							               row += '<td>'+json[i][0]+'</td>';
							               row += '<td>'+json[i][1]+'</td>';
							               row += '<td>'+json[i][2]+'</td>';
							               row += '<td>'+json[i][3]+'</td>';
							               row += '<td>'+json[i][4]+'</td>';
							               row += '<td>'+json[i][5]+'%</td>';
							               row += '</tr>';
							               $('#test').append(row);
					            	}else{
									var row = '<tr class="success" style="background-color:red;">';
						               row += '<td>'+(i)+'</td>';
						               row += '<td>'+json[i][0]+'</td>';
						               row += '<td>'+json[i][1]+'</td>';
						               row += '<td>'+json[i][2]+'</td>';
						               row += '<td>'+json[i][3]+'</td>';
						               row += '<td>'+json[i][4]+'</td>';
						               row += '<td>'+json[i][5]+'%</td>';
						               row += '</tr>';
						               $('#test').append(row);
					             	}
								}
							}
						},
						error: function(e) {
							alert(e + " SERVER ERROR , TRY AGAIN LATER");
						}
					})
	});
	
	$("#jobName").on('change',function(){
		$('#getReport1').prop('disabled', false);
	})
})