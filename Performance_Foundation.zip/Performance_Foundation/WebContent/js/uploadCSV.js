/*$(document).ready(function() {
	$("#uploadcsv").submit(function(e) {
	    e.preventDefault();
	 });
	var scriptName=""
	$("#upload-csv").click(function(event) {
		var formData=new FormData($('#uploadcsv')[0]);
		scriptName=$('.jmx-uploadButton__fileName').text();
		//scriptName=$('#fname').val().toString();
		formData.append('scriptName1',scriptName)
		$.ajax({
			url: "upload_csv",
			type:"POST",
			mimeType:"multipart/form-data",
			data:formData,
	        contentType: false,
	        processData: false,
			dataType: "json",
			success: function(json) {
				if(json=="1"){
					alert("Something went wrong while uploading file. Please contact your administrator.")
				}else{
					alert("DataSet File Uploaded Successfully.")
					var row = '<li id="'+json+'">';
				        row += '<strong>'+json+' - </strong>';
				        row += '<a class="removeFile btn btn-danger btn-xs" href="#" data-fileid="files11" id="'+json+'" name="delete1">Remove</a>';
				        row += '</li>';	
					$('#viewFiles').append(row);
				}	
			},
			error: function(e) {
				alert(e + " SERVER ERROR , TRY AGAIN LATER");
			}
		})
	});
});
   
*/