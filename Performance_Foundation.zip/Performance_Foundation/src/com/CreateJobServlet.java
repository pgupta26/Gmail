package com;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.google.gson.Gson;
import com.sun.jersey.api.client.ClientResponse;

@SuppressWarnings("serial")
public class CreateJobServlet extends HttpServlet {

	private String Upload_Dir;
	private String scriptName;
	private Document doc;
	private NodeList loopCountNode;
	private Transformer xformer;
	private RequestDispatcher rd;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {

		try{
			//get request parameter
			scriptName=req.getParameter("scriptName1").substring(req.getParameter("scriptName1").lastIndexOf("\\")+1);
			
			//Initialize objects
			HelperFunctions helpObj=new HelperFunctions();

			//Read properties
			//Upload_Dir=getProperty("Upload_Dir").trim();
			String Jenkins_url=getProperty("Jenkins_Url").trim();
			String Jenkins_UserName=getProperty("Jenkins_UserName").trim();
			String Jenkins_Password=getProperty("Jenkins_Password").trim();
			String Jenkins_CopyJob=getProperty("Jenkins_CopyJob").trim();
			
			String scriptNameWithoutJmx=scriptName.substring(0,scriptName.lastIndexOf("."));
			
			//Read properties
			Upload_Dir=getProperty("Upload_Dir").trim()+File.separator+scriptNameWithoutJmx;
			
			//update jenkins parameter names in script
			updateScriptFile(Upload_Dir + File.separator + scriptName);

			ArrayList<String> jobsName=helpObj.getAllJobsNames(Jenkins_url, Jenkins_UserName, Jenkins_Password);
			
			if(jobsName.contains(scriptNameWithoutJmx)){
				String msg="exist";
				String json = new Gson().toJson(msg);
				res.setContentType("application/json");
				res.getWriter().write(json);
			}else{
				
				//create job
				String configXML =helpObj.readJob(Jenkins_url, Jenkins_CopyJob,Jenkins_UserName,Jenkins_Password);

				if(!configXML.equals("")){
					ClientResponse statusCode=helpObj.createJob(Jenkins_url, scriptName.substring(0,scriptName.lastIndexOf(".")), configXML,Jenkins_UserName,Jenkins_Password);
					if(statusCode.getStatus() ==200){
						
						String msg="Success";
						String json = new Gson().toJson(msg);
						res.setContentType("application/json");
						res.getWriter().write(json);

					}else{
						//Send Failure message
						deleteFile(Upload_Dir + File.separator + scriptName);
						String msg="Fail";
						String json = new Gson().toJson(msg);
						res.setContentType("application/json");
						res.getWriter().write(json);
					}
				}else{
					//Send Failure message
					deleteFile(Upload_Dir + File.separator + scriptName);
					String msg="Fail";
					String json = new Gson().toJson(msg);
					res.setContentType("application/json");
					res.getWriter().write(json);
				}
			}
			
	}catch(com.sun.jersey.api.client.ClientHandlerException  ex){
		
		deleteFile(Upload_Dir + File.separator + scriptName);
		String msg="ConnectionFail";
		String json = new Gson().toJson(msg);
		res.setContentType("application/json");
		res.getWriter().write(json);	
	}catch(TransformerFactoryConfigurationError| Exception ex){
		
		deleteFile(Upload_Dir + File.separator + scriptName);
		String msg="Fail";
		String json = new Gson().toJson(msg);
		res.setContentType("application/json");
		res.getWriter().write(json);
	}
}

private String getFileName(Part part) {
	String contentDisp = part.getHeader("content-disposition");
	String[] tokens = contentDisp.split(";");
	for (String token : tokens) {
		if (token.trim().startsWith("filename")) {
			return token.substring(token.indexOf("=") + 2, token.length()-1);
		}
	}
	return "";
}

private void updateScriptFile(String fileName) throws SAXException, IOException, ParserConfigurationException, XPathExpressionException, TransformerFactoryConfigurationError, TransformerException{

	String Jenkins_UsersParamName=getProperty("Jenkins_UsersParamName").trim();
	String Jenkins_RampUpParamName=getProperty("Jenkins_RampUpParamName").trim();
	String Jenkins_DurationParamName=getProperty("Jenkins_DurationParamName").trim();
	

	doc = DocumentBuilderFactory.newInstance()
			.newDocumentBuilder().parse(new InputSource(fileName));
	// locate the node(s)
	XPath xpath = XPathFactory.newInstance().newXPath();

	loopCountNode = (NodeList)xpath.evaluate
			("//stringProp[@name='LoopController.loops']", doc, XPathConstants.NODESET);

	// make the change
	for (int idx = 0; idx < loopCountNode.getLength(); idx++) {
		loopCountNode.item(idx).setTextContent("-1");
	}

	NodeList usersNode = (NodeList)xpath.evaluate
			("//stringProp[@name='ThreadGroup.num_threads']", doc, XPathConstants.NODESET);

	// make the change
	for (int idx = 0; idx < usersNode.getLength(); idx++) {
		usersNode.item(idx).setTextContent("${__P("+Jenkins_UsersParamName+",1)}");
	}

	NodeList rampUpNode = (NodeList)xpath.evaluate
			("//stringProp[@name='ThreadGroup.ramp_time']", doc, XPathConstants.NODESET);

	// make the change
	for (int idx = 0; idx < rampUpNode.getLength(); idx++) {
		rampUpNode.item(idx).setTextContent("${__P("+Jenkins_RampUpParamName+",1)}");
	}
	
	NodeList schedulerNode = (NodeList)xpath.evaluate
			("//boolProp[@name='ThreadGroup.scheduler']", doc, XPathConstants.NODESET);
	
	// make the change
	for (int idx = 0; idx < schedulerNode.getLength(); idx++) {
		schedulerNode.item(idx).setTextContent("true");
	}
	
	NodeList durationNode = (NodeList)xpath.evaluate
			("//stringProp[@name='ThreadGroup.duration']", doc, XPathConstants.NODESET);
	
	// make the change
	for (int idx = 0; idx < durationNode.getLength(); idx++) {
		durationNode.item(idx).setTextContent("${__P("+Jenkins_DurationParamName+",1)}");
	}

	// save the result
	xformer = TransformerFactory.newInstance().newTransformer();


	xformer.transform
	(new DOMSource(doc), new StreamResult(new File(fileName)));

}

private void deleteFile(String fileName){
	File file=new File(fileName);
	if(file.exists()){
		file.delete();
	}
}

public String getProperty(String key) throws IOException {
	Properties prop = new Properties();
	InputStream input = null;

	ServletContext context = getServletContext();
	String configPath = context.getRealPath("/WEB-INF/config/config.properties");
	input = new FileInputStream(configPath);

	// load a properties file
	prop.load(input);

	// get the property value
	return prop.getProperty(key);

}

private List<String> getAllAvailableFiles(String Upload_Dir ){
	File listAllFiles=new File(Upload_Dir);
	if (!listAllFiles.exists()) {
		listAllFiles.mkdirs();
	}
	List<String> jmxFile = new ArrayList<String>();
	for (File file : listAllFiles.listFiles()) {
		if (file.getName().endsWith((".jmx"))) {

			jmxFile.add(file.getName());
		}
	}
	return jmxFile;
}
}
