package com;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.google.gson.Gson;
import com.sun.jersey.api.client.ClientResponse;

public class GetAllJobsServlet extends HttpServlet {

	private String Upload_Dir;
	private String scriptName;
	private Document doc;
	private NodeList loopCountNode;
	private Transformer xformer;
	private RequestDispatcher rd;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {

		try{
			Thread.sleep(3000);
			//Initialize objects
			HelperFunctions helpObj=new HelperFunctions();

			//Read properties
			//Upload_Dir=getProperty("Upload_Dir").trim();
			String Jenkins_url=getProperty("Jenkins_Url").trim();
			String Jenkins_UserName=getProperty("Jenkins_UserName").trim();
			String Jenkins_Password=getProperty("Jenkins_Password").trim();

			//create job
			ArrayList<ArrayList<String>> jobHistory=helpObj.getJobDetails(Jenkins_url,Jenkins_UserName,Jenkins_Password);
			
			String json = new Gson().toJson(jobHistory);
			res.setContentType("application/json");
			res.getWriter().write(json);
			
		}catch(com.sun.jersey.api.client.ClientHandlerException  ex){

			String msg="ConnectionFail";
			String json = new Gson().toJson(msg);
			res.setContentType("application/json");
			res.getWriter().write(json);	
		}catch(TransformerFactoryConfigurationError| Exception ex){

			String msg="Fail";
			String json = new Gson().toJson(msg);
			res.setContentType("application/json");
			res.getWriter().write(json);
		}
	}
		public String getProperty(String key) throws IOException {
		Properties prop = new Properties();
		InputStream input = null;

		ServletContext context = getServletContext();
		String configPath = context.getRealPath("/WEB-INF/config/config.properties");
		input = new FileInputStream(configPath);

		// load a properties file
		prop.load(input);

		// get the property value
		return prop.getProperty(key);

	}
}
