package com;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.json.JSONObject;

import com.sun.jersey.api.client.WebResource;
import com.google.gson.Gson;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;

public class GraphReportServlet extends HttpServlet {

	String jobName;
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		
		try{

			ServletContext context = getServletContext();
			String resultsPath = context.getRealPath("/Results");
			//String resultsPath="C:\\apache-tomcat-8.5.30\\webapps2\\HotelTap_Final\\Results";
			
			//Read from properties file
			String Jenkins_url=getProperty("Jenkins_Url").trim();
			String Jenkins_UserName=getProperty("Jenkins_UserName").trim();
			String Jenkins_Password=getProperty("Jenkins_Password").trim();

			//Read request parameter
			jobName=req.getParameter("jobName1").trim();
			
			//Initialize objects
			HelperFunctions helpObj=new HelperFunctions();
			
			boolean value=helpObj.getLastBuildPresence(Jenkins_url, Jenkins_UserName, Jenkins_Password,jobName);
			
			if(value==false){
				
				Client client = Client.create();
				client.addFilter(new com.sun.jersey.api.client.filter.HTTPBasicAuthFilter(Jenkins_UserName, Jenkins_Password));
				WebResource webResource = client.resource(Jenkins_url+"/job/"+jobName+"/lastBuild/api/json?tree=number");
				ClientResponse response = webResource.post(ClientResponse.class);

				String jsonResponse = response.getEntity(String.class);
				client.destroy();

				JSONObject json =new JSONObject(jsonResponse);
				int latestBuildNumber=json.getInt("number");

				String lastBuildCSV=resultsPath+File.separator+jobName+File.separator+"csv"+File.separator+latestBuildNumber+File.separator+jobName+".csv";
				
				//String csvFileName="C:\\Users\\ACER\\Downloads\\Results_1.csv";
				LinkedHashSet <String> transactionNames=getAllTransactionNames(lastBuildCSV);
				
				Reader firstFile = Files.newBufferedReader(Paths.get(lastBuildCSV));
				CSVParser firstFileParser = new CSVParser(firstFile, CSVFormat.DEFAULT);
				List<CSVRecord> firstFileRecords = firstFileParser.getRecords();
				
				int firstFileSampleCount;
				int firstFileResponseTime;
				int averageResponseTime;
				List<String> record;
				
				String records1="if($('#morris_extra_bar_chart').length > 0) Morris.Bar({element: 'morris_extra_bar_chart',data: [";

				for(String transactionName:transactionNames){
					record=new ArrayList<String>();
					firstFileSampleCount=0;
					firstFileResponseTime=0;
					averageResponseTime=0;
					for(int i=1;i<firstFileRecords.size();i++){

						CSVRecord firstFileRow = firstFileRecords.get(i);
						
						if(firstFileRow.get(2).equals(transactionName)){
							firstFileSampleCount=firstFileSampleCount+1;
							firstFileResponseTime =firstFileResponseTime+ Integer.parseInt(firstFileRow.get(1));
						}
					}
					
					averageResponseTime=firstFileResponseTime/firstFileSampleCount;
					records1+="{y: '"+transactionName+"',a: "+Integer.toString(averageResponseTime)+"},";

				}
				
				firstFileParser.close();
				
				records1+="],xkey: 'y',ykeys: ['a'],labels: ['Response Time'],barColors:['#177ec1', '#dc4666', '#e69a2a'],hideHover: 'auto',gridLineColor: '#878787',resize: true,gridTextColor:'#878787',gridTextFamily:\"Roboto\"});";			
		
				res.setContentType("text/javascript");
				res.getWriter().write(records1);
				
			}else{
				
				String msg="Fail";
				String json = new Gson().toJson(msg);
				res.setContentType("application/json");
				res.getWriter().write(json);
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}

	public String getProperty(String key) throws IOException {
		Properties prop = new Properties();
		InputStream input = null;

		ServletContext context = getServletContext();
		String configPath = context.getRealPath("/WEB-INF/config/config.properties");
		input = new FileInputStream(configPath);

		// load a properties file
		prop.load(input);

		// get the property value
		return prop.getProperty(key);

	}
	
	public static LinkedHashSet <String> getAllTransactionNames(String csvFileName){

		LinkedHashSet <String> transactionNames = null;

		try{
			transactionNames=new LinkedHashSet <String>();

			Reader firstFile = Files.newBufferedReader(Paths.get(csvFileName));
			CSVParser firstFileParser = new CSVParser(firstFile, CSVFormat.DEFAULT);
			List<CSVRecord> firstFileRecords = firstFileParser.getRecords();

			for(int i=1;i<firstFileRecords.size();i++){

				CSVRecord firstFileRow = firstFileRecords.get(i);

				transactionNames.add(firstFileRow.get(2));

			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return transactionNames;
	}
	
}
