package com;

import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

public class TestCSV {
	public static void main(String[] args) throws IOException{
		String lastBuildCSV="C:\\apache-tomcat-8.5.30\\webapps2\\HotelTap_Final\\Results\\HotelTap_S02_GlobalSearch\\csv\\1\\HotelTap_S02_GlobalSearch.csv";
		LinkedHashSet <String> transactionNames=getAllTransactionNames(lastBuildCSV);
		
		Reader firstFile = Files.newBufferedReader(Paths.get(lastBuildCSV));
		CSVParser firstFileParser = new CSVParser(firstFile, CSVFormat.DEFAULT);
		List<CSVRecord> firstFileRecords = firstFileParser.getRecords();
		
		int firstFileSampleCount;
		int firstFileResponseTime;
		int averageResponseTime;
		List<String> record;
		
		String records1="if($('#morris_extra_bar_chart').length > 0) Morris.Bar({element: 'morris_extra_bar_chart',data: [";

		for(String transactionName:transactionNames){
			record=new ArrayList<String>();
			firstFileResponseTime=0;
			firstFileSampleCount=0;
			averageResponseTime=0;
			for(int i=1;i<firstFileRecords.size();i++){

				CSVRecord firstFileRow = firstFileRecords.get(i);
				
				if(firstFileRow.get(2).equals(transactionName)){
					firstFileSampleCount=firstFileSampleCount+1;
					firstFileResponseTime =firstFileResponseTime+ Integer.parseInt(firstFileRow.get(1));
				}
			}
			
			averageResponseTime=firstFileResponseTime/firstFileSampleCount;
			records1+="{y: '"+transactionName+"',a: "+Integer.toString(averageResponseTime)+"},";

		}
		
		firstFileParser.close();
	}
	public static LinkedHashSet <String> getAllTransactionNames(String csvFileName){

		LinkedHashSet <String> transactionNames = null;

		try{
			transactionNames=new LinkedHashSet <String>();

			Reader firstFile = Files.newBufferedReader(Paths.get(csvFileName));
			CSVParser firstFileParser = new CSVParser(firstFile, CSVFormat.DEFAULT);
			List<CSVRecord> firstFileRecords = firstFileParser.getRecords();

			for(int i=1;i<firstFileRecords.size();i++){

				CSVRecord firstFileRow = firstFileRecords.get(i);

				transactionNames.add(firstFileRow.get(2));

			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return transactionNames;
	}
}