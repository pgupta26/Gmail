package com;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.json.JSONArray;
import org.json.JSONObject;

import com.sun.jersey.api.client.WebResource;
import com.google.gson.Gson;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;

@SuppressWarnings("serial")
public class resultsComparisonServlet extends HttpServlet {

	String jobName;
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {

		try{

			ServletContext context = getServletContext();
			String resultsPath = context.getRealPath("/Results");
			//String resultsPath="C:\\apache-tomcat-8.5.30\\webapps2\\HotelTap_Final\\Results";

			//Read from properties file
			String Jenkins_url=getProperty("Jenkins_Url").trim();
			String Jenkins_UserName=getProperty("Jenkins_UserName").trim();
			String Jenkins_Password=getProperty("Jenkins_Password").trim();

			//Read request parameter
			jobName=req.getParameter("jobName1").trim();

			//Initialize objects
			HelperFunctions helpObj=new HelperFunctions();

			boolean value=helpObj.getLastBuildPresence(Jenkins_url, Jenkins_UserName, Jenkins_Password,jobName);

			ArrayList<String> record;
			ArrayList<ArrayList<String>> records=new ArrayList<ArrayList<String>>();

			if(value==false){

				Client client = Client.create();
				WebResource webResource = client.resource(Jenkins_url+"/job/"+jobName+"/api/json?tree=builds[number]");
				ClientResponse response = webResource.get(ClientResponse.class);
				String jsonResponse = response.getEntity(String.class);
				client.destroy();

				JSONObject json =new JSONObject(jsonResponse) ; 
				JSONArray value1=json.getJSONArray("builds");

				int latestBuildNumber;
				if(value1.length()>=2){
					record=new ArrayList<String>();
					latestBuildNumber=(int) value1.getJSONObject(0).get("number");
					for(int i=0;i<2;i++){
						record.add(value1.getJSONObject(i).get("number").toString());
						Client client1 = Client.create();
						WebResource webResource1 = client1.resource(Jenkins_url+"/job/"+jobName+"/"+value1.getJSONObject(i).get("number").toString()+"/api/json?tree=actions[parameters[name,value]]");
						ClientResponse response1 = webResource1.get(ClientResponse.class);
						String jsonResponse1 = response1.getEntity(String.class);
						client.destroy();

						JSONObject json1 =new JSONObject(jsonResponse1) ; 
						JSONArray value3=json1.getJSONArray("actions");
						JSONObject value4=value3.getJSONObject(0);
						JSONArray value5=value4.getJSONArray("parameters");
						for(int k=1;k<value5.length();k++){
							record.add(value5.getJSONObject(k).getString("value"));
						}	
					} 

					records.add(record);

					//int latestBuildNumber=json.getInt("number");
					int previousBuildNumber=latestBuildNumber-1;

					String lastBuildCSV=resultsPath+File.separator+jobName+File.separator+"csv"+File.separator+latestBuildNumber+File.separator+jobName+".csv";
					String previousBuildCSV=resultsPath+File.separator+jobName+File.separator+"csv"+File.separator+previousBuildNumber+File.separator+jobName+".csv";

					File file1=new File(lastBuildCSV);
					File file2=new File(previousBuildCSV);

					if((file1.exists() && file2.exists())){
						LinkedHashSet <String> transactionNames=getAllTransactionNames(lastBuildCSV);
						System.out.println(transactionNames);

						Reader firstFile = Files.newBufferedReader(Paths.get(previousBuildCSV));
						CSVParser firstFileParser = new CSVParser(firstFile, CSVFormat.DEFAULT);
						List<CSVRecord> firstFileRecords = firstFileParser.getRecords();

						Reader secondFile = Files.newBufferedReader(Paths.get(lastBuildCSV));
						CSVParser secondFileParser = new CSVParser(secondFile, CSVFormat.DEFAULT);
						List<CSVRecord> secondFileRecords = secondFileParser.getRecords();

						int firstFileSampleCount;
						int firstFileResponseTime;
						int averageResponseTime;

						int secondFileSampleCount;
						int secondFileResponseTime;
						int secondAverageResponseTime;

						float standardDeviation;

						for(String transactionName:transactionNames){
							record=new ArrayList<String>();
							System.out.println(transactionName);
							record.add(transactionName);
							standardDeviation=0;

							firstFileSampleCount=0;
							firstFileResponseTime=0;
							averageResponseTime=0;

							secondFileSampleCount=0;
							secondFileResponseTime=0;
							secondAverageResponseTime=0;

							for(int i=1;i<firstFileRecords.size();i++){

								CSVRecord firstFileRow = firstFileRecords.get(i);

								if(firstFileRow.get(2).equals(transactionName)){
									firstFileSampleCount=firstFileSampleCount+1;
									firstFileResponseTime =firstFileResponseTime+ Integer.parseInt(firstFileRow.get(1));
								}

							}

							averageResponseTime=firstFileResponseTime/firstFileSampleCount;
							record.add(Integer.toString(firstFileSampleCount));
							record.add(Integer.toString(averageResponseTime));

							for(int j=1;j<secondFileRecords.size();j++){

								CSVRecord secondFileRow =secondFileRecords.get(j);

								if(secondFileRow.get(2).equals(transactionName)){
									secondFileSampleCount=secondFileSampleCount+1;
									secondFileResponseTime =secondFileResponseTime+ Integer.parseInt(secondFileRow.get(1));
								}
							}
							secondAverageResponseTime=secondFileResponseTime/secondFileSampleCount;
							record.add(Integer.toString(secondFileSampleCount));
							record.add(Integer.toString(secondAverageResponseTime));
							standardDeviation=(((secondAverageResponseTime-averageResponseTime)*100)/averageResponseTime);
							record.add(Float.toString(standardDeviation));
							records.add(record);
						}

						firstFileParser.close();
						secondFileParser.close();

						String json1 = new Gson().toJson(records);
						res.setContentType("application/json");
						res.getWriter().write(json1);

					}else{
						String msg="MissingFile";
						String json3 = new Gson().toJson(msg);
						res.setContentType("application/json");
						res.getWriter().write(json3);
						
					}

				}else{
					String msg="BuildNotAvailable";
					String json3 = new Gson().toJson(msg);
					res.setContentType("application/json");
					res.getWriter().write(json3);
				}
			}else{
				String msg="Not Build";
				String json = new Gson().toJson(msg);
				res.setContentType("application/json");
				res.getWriter().write(json);
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}

	public String getProperty(String key) throws IOException {
		Properties prop = new Properties();
		InputStream input = null;

		ServletContext context = getServletContext();
		String configPath = context.getRealPath("/WEB-INF/config/config.properties");
		input = new FileInputStream(configPath);

		// load a properties file
		prop.load(input);

		// get the property value
		return prop.getProperty(key);

	}

	public static LinkedHashSet <String> getAllTransactionNames(String csvFileName){

		LinkedHashSet <String> transactionNames = null;

		try{
			transactionNames=new LinkedHashSet <String>();

			Reader firstFile = Files.newBufferedReader(Paths.get(csvFileName));
			CSVParser firstFileParser = new CSVParser(firstFile, CSVFormat.DEFAULT);
			List<CSVRecord> firstFileRecords = firstFileParser.getRecords();

			for(int i=1;i<firstFileRecords.size();i++){

				CSVRecord firstFileRow = firstFileRecords.get(i);

				transactionNames.add(firstFileRow.get(2));

			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return transactionNames;
	}

}
