package javaPracticals;

import java.util.Scanner;

public class ASCIITest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char c;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter any character: ");
		c=sc.next().charAt(0);
		
		int ascValue=c;
		System.out.println("ASCII value of "+c+" is "+ascValue);
		
		sc.close();
	}
}
