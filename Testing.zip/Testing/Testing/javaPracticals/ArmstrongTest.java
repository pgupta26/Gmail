/**
 * 
 */
package test.java.programmingTest;

import java.util.Scanner;

/**
 * @author e5399484
 *
 */
public class ArmstrongTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num,remainder;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Please Enter Any Number: ");
		num=sc.nextInt();
		
		String str=String.valueOf(num);
		int len=str.length();
		int temp=num;
		int powerOfNumber=1;
		int sum=0;
		while( num > 0) {
			remainder=num%10;
			num=num/10;
			powerOfNumber=1;
			for(int i=1;i<=len;i++) {
				powerOfNumber=powerOfNumber*remainder;
			}
			System.out.println(powerOfNumber);
			sum=sum+powerOfNumber;
		}
		
		System.out.println("Sum ="+sum);
		if(temp==sum) {
			System.out.println("Number is Armstrong.");
		}else{
			System.out.println("Number is not Armstrong.");
		}
		
		sc.close();

	}

}
