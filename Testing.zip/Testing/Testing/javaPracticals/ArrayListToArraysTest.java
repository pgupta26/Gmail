/**
 * 
 */
package test.java.programmingTest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * @author e5399484
 *
 */
public class ArrayListToArraysTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		System.out.println("----ArrayList to Array conversion----");
		List<Integer> ls1=new ArrayList<Integer>();
		Collections.addAll(ls1, 10, 20, 30);

		int[] arr=new int[ls1.size()];
		for(int counter=0;counter<ls1.size();counter++)
			arr[counter]=ls1.get(counter);
		System.out.println("Array Values: "+Arrays.toString(arr));
		//2nd way
		System.out.println("ArrayList to Array conversion using functin: "+ls1.toArray());

		
		System.out.println("----Array to ArrayList conversion----");
		//1st way
		System.out.println("Array to ArrayList conversion using function: "+Arrays.asList(ls1.toArray()));
		//2nd way
		for(int counter=0;counter<arr.length;counter++)
			ls1.add(arr[counter]);
		System.out.println("List Values: "+ls1);
	}
}
