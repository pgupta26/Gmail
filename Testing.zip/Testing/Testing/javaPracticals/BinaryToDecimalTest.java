/**
 * 
 */
package test.java.programmingTest;

import java.util.Scanner;

/**
 * @author e5399484
 *
 */
public class BinaryToDecimalTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Binary to Decimal Conversion
		int num,remainder, decNumber=0;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Please Enter Binary Number: ");
		num=sc.nextInt();
		
		int temp=num;
		int counter=0;
		while(num!=0) {
			remainder=num%10;
			num=num/10;
			decNumber+=remainder * Math.pow(2, counter);
			counter++;
		}
		
		System.out.println("Binary Number: "+temp+" Decimal Number: "+decNumber);
		
		System.out.println("-------Decimal to Binary Conversion--------");
		int num1;
		System.out.println("Please Enter Decimal Number: ");
		num1=sc.nextInt();
		
		int decTemp=num1;
		String str = "";
	
		while(num1!=0) {
			remainder=num1%2;
			num1=num1/2;
			str=str+remainder;
		}
		System.out.println("Decimal Number: "+decTemp+" Binary Number: "+str.trim());
		
	}

}
