/**
 * 
 */
package test.java.programmingTest;

/**
 * @author e5399484
 *
 */
public class CompareStringTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str1="Parsi";
		String str2="Parsi";
		
		if(str1.equals(str2)){
			System.out.println("Both strings are equal.");
		}else{
			System.out.println("Unequal");
		}
		
		if(str1==str2){
			System.out.println("Both strings are equal.");
		}else{
			System.out.println("Unequal");
		}
		
		
	}

}
