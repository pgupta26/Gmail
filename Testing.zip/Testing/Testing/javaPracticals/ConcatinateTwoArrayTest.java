/**
 * 
 */
package test.java.programmingTest;

import java.util.Arrays;

/**
 * @author e5399484
 *
 */
public class ConcatinateTwoArrayTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr={10,20};
		int[] arr1={23,45};
		int[] result=new int[arr.length+arr1.length];
		
		System.arraycopy(arr, 0, result, 0, arr.length);
        System.arraycopy(arr1, 0, result, arr.length, arr1.length);

        System.out.println(Arrays.toString(result));	
	}
}
