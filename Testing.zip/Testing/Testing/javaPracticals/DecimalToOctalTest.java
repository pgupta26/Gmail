/**
 * 
 */
package test.java.programmingTest;

import java.util.Scanner;

/**
 * @author e5399484
 *
 */
public class DecimalToOctalTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("-------Decimal to Octal Conversion--------");
		int num1,remainder;
		Scanner sc=new Scanner(System.in);
		System.out.println("Please Enter Decimal Number: ");
		num1=sc.nextInt();
		
		int decTemp=num1;
		String str = "";
	
		while(num1!=0) {
			remainder=num1%8;
			num1=num1/8;
			str=str+remainder;
		}
		
		StringBuilder sb=new StringBuilder();
		sb.append(str);
		System.out.println("Decimal Number: "+decTemp+" Octal Number: "+sb.reverse());
		
		System.out.println("-------Octal to Decimal conversion--------");
		int num2;
		System.out.println("Please Enter Octal Number: ");
		num2=sc.nextInt();
		
		int octTemp=num2;
		int sum=0;
		int counter=0;
		while(num2!=0) {
			remainder=num2%10;
			num2=num2/10;
			sum+=remainder * Math.pow(8, counter);
			counter++;
		}
		
		System.out.println("Octal Number: "+octTemp+" Decimal Number: "+sum);
	}
	
	
	

}
