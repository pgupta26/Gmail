package javaPracticals;

import java.util.Scanner;

public class FactorialTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num;
		int fact=1;
		System.out.println("Please Enter Number");
		Scanner sc=new Scanner(System.in);
		num=sc.nextInt();
		int counter=1;
		if(num<1) {
			System.out.println("Please enter positive number.");
		} else {
			while(counter<=num) {
				fact=fact*counter;
				counter++;
			}
			System.out.println("Factorial of "+num+" is "+fact);
		}
		sc.close();
	}

}
