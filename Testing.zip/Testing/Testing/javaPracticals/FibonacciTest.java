package javaPracticals;

import java.util.Scanner;

public class FibonacciTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1,num2,lastNum,temp=0;
		
		System.out.println("Enter First Number: ");
		Scanner sc=new Scanner(System.in);
		num1=sc.nextInt();
		
		System.out.println("Enter Second Number: ");
		num2=sc.nextInt();
		
		System.out.println("Enter Last Number: ");
		lastNum=sc.nextInt();
		
		while(temp<lastNum) {
			temp=num1+num2;
			System.out.println("Fibonacci Series: "+temp);
			num1=num2;
			num2=temp;
		}
		sc.close();
	}
}
