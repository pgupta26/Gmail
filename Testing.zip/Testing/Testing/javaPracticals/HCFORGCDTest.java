package javaPracticals;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class HCFORGCDTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1,num2;
		
		List<Integer> commonFactor1=new ArrayList<Integer>();
		System.out.println("Please Enter First Number");
		Scanner sc=new Scanner(System.in);
		num1=sc.nextInt();
		
		System.out.println("Please Enter Second Number");
		List<Integer> commonFactor2=new ArrayList<Integer>();
		num2=sc.nextInt();

		for(int i=1;i<num1;i++) {
			if(num1%i==0) {
				commonFactor1.add(i);
			}
		}

		for(int i=1;i<num2;i++) {
			if(num2%i==0) {
				commonFactor2.add(i);
			}
		}

		commonFactor1.retainAll(commonFactor2);
		System.out.println(Collections.max(commonFactor1));
		sc.close();
	}

}
