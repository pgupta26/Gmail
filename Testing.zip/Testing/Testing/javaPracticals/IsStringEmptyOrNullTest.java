/**
 * 
 */
package test.java.programmingTest;

import java.util.Date;
import java.util.Scanner;

/**
 * @author e5399484
 *
 */
public class IsStringEmptyOrNullTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str=null;
		if(str==null){
			System.out.println("String is null");
		}
		
		String str1="";
		if(str1.isEmpty()){
			System.out.println("String is empty.");
		}
		
		System.out.println("Current Date and time is: "+new Date());
		//sc.close();
	}

}
