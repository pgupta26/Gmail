/**
 * 
 */
package test.java.programmingTest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author e5399484
 *
 */
public class JoinListTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> ls1=new ArrayList<Integer>();
		Collections.addAll(ls1, 10);
		
		List<Integer> ls2=new ArrayList<Integer>();
		Collections.addAll(ls2, 10);
		
		ls1.addAll(ls2);
		
		System.out.println("List after joining: "+ls1);
	}

}
