/**
 * 
 */
package test.java.programmingTest;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author e5399484
 *
 */
public class MapToListTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<Integer,Integer> hm=new HashMap<Integer,Integer>();
		hm.put(1, 101);
		hm.put(2, 102);
		
		/*List<Integer> keyList = new ArrayList(map.keySet());
	    List<String> valueList = new ArrayList(map.values());*/
		
		Set<Integer> keyList=hm.keySet();
		Collection<Integer> valueList=hm.values();
		
		System.out.println("Key List: "+keyList);
		System.out.println("Value List: "+valueList);

	}
}
