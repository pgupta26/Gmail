package javaPracticals;

import java.util.Scanner;

public class NumberOfDigitsTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num, remainder, nod=0;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Please any number: ");
		num=sc.nextInt();
		
		while(num>0) {
			remainder=num%10;
			num=num/10;
			nod++;
		}
		
		System.out.println("Number of digits are: "+nod);
		sc.close();
	}

}
