package javaPracticals;

import java.util.Scanner;

public class ParildromeTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num;
		int rev=0;
		System.out.println("Enter any number:");
		Scanner sc=new Scanner(System.in);
		num=sc.nextInt();
		int temp=num;
		int remainder;
		while(num > 0) {
			remainder=num %10;
			num=num /10;
			rev=rev*10+remainder;
		}
		
		if(rev==temp) {
			System.out.println("Number is Palindrome");
		}else {
			System.out.println("Number is not Palindrome");
		}
		sc.close();
	}

}
