package javaPracticals;

import java.util.Scanner;

public class PowerOfANumberTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int base,exponent;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Please Enter Base:");
		base=sc.nextInt();
		
		System.out.println("Please Enter Exponent:");
		exponent=sc.nextInt();
		
		int result=1;
		
		int counter=1;
		while(counter<=exponent) {
			result=result*base;
			counter++;
		}
		
		System.out.println("Power of a number is : "+result);
		sc.close();

	}

}
