package javaPracticals;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PrimeBetweenTwoTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1,num2;
		Scanner sc=new Scanner(System.in);

		System.out.println("Please Enter First Number: ");
		num1=sc.nextInt();

		System.out.println("Please Enter Second Numebr:");
		num2=sc.nextInt();

		List<Integer> primeList=new ArrayList<Integer>();
		boolean isPrime=true;
		int counter;
		for(counter=num1+1;counter<num2;counter++) {
			isPrime=true;
			for(int i=2;i<counter;i++) {
				if(counter % i==0) {
					isPrime=false;
					break;
				}
			}
			if(isPrime){
				primeList.add(counter);
			}
		}
		
		System.out.println("Prime numbers are: "+primeList);
	}

}
