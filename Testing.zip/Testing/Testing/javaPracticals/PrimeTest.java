package javaPracticals;

import java.util.Scanner;

public class PrimeTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num;
		System.out.println("Enter number to test");
		Scanner sc=new Scanner(System.in);
		num=sc.nextInt();
		boolean isPrime=true;
		if(num<=1) {
			System.out.println("Please enter number greater than or equal to 2.");
		}else {
			for(int i=2;i<num;i++) {
				if(num%i==0) {
					isPrime=false;
					break;
				}
			}
			if(isPrime) {
				System.out.println("Number: "+num+" is prime.");
			}else {
				System.out.println("Number: "+num+" is not prime.");
			}
		}

		sc.close();
	}
}
