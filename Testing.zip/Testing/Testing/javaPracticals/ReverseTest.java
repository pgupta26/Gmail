package javaPracticals;

import java.util.Scanner;

public class ReverseTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num;
		int rev=0;
		System.out.println("Enter any number:\n");
		Scanner sc=new Scanner(System.in);
		num=sc.nextInt();
		
		int remainder;
		while(num > 0) {
			remainder=num %10;
			num=num /10;
			rev=rev*10+remainder;
		}
		System.out.println("Reverse of a number is : "+rev);
		sc.close();
		

	}

}
