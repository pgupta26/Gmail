/**
 * 
 */
package test.java.programmingTest;

/**
 * @author e5399484
 *
 */
public class RoundANumberTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double num=345.6;
		
		System.out.format("Round of a number upto 2 digits %.4f", num);
		
		int num1=45;
		
		System.out.format("Round of a number upto 2 digits %.4f", (double)num1);
	}

}
