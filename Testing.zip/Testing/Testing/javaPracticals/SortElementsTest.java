/**
 * 
 */
package test.java.programmingTest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/**
 * @author e5399484
 *
 */
public class SortElementsTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Please Enter Any String: ");
		str=sc.next();
		
		String[] subStr=str.split("-");
		System.out.println("Length of a String is: "+subStr.length);
		
		String temp;
		for(int counter=0;counter<subStr.length;counter++){
			for(int j=counter+1;j<subStr.length;j++){
				if(subStr[j].compareTo(subStr[counter])>0) {
					temp=subStr[j];
					subStr[j]=subStr[counter];
					subStr[counter]=temp;
				}
			}
		}
		
		System.out.println("In lexicographical order:");
        for(int i = 0; i < subStr.length; i++) {
            System.out.println(subStr[i]);
        }
		sc.close();
	}
}
