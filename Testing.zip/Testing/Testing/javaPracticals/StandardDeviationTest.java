/**
 * 
 */
package test.java.programmingTest;

/**
 * @author e5399484
 *
 */
public class StandardDeviationTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]={9, 2, 5, 4, 12, 7, 8, 11, 9, 3, 7, 4, 12, 5, 4, 10, 9, 6, 9, 4};
		int totalNumberOfElement=arr.length;
		int sum=0;
		for(int counter=0;counter<totalNumberOfElement;counter++){
			sum=sum+arr[counter];
		}
		
		double mean;
		mean=sum/totalNumberOfElement;
		System.out.println("First Mean: "+mean);
		
		sum=0;
		for(int counter=0;counter<totalNumberOfElement;counter++){
			sum=(int) (sum+((arr[counter]-mean)*(arr[counter]-mean)));
		}
		System.out.println("sum: " +sum);
		
		mean=0;
		mean=(sum/totalNumberOfElement);
		System.out.println("Second Mean: "+sum/totalNumberOfElement+ "Is "+mean);
		
		System.out.println("Standard Deviation: "+Math.sqrt(mean));
	}
}
