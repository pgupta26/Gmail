/**
 * 
 */
package test.java.programmingTest;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * @author e5399484
 *
 */
public class StringToDateConversionTest {

	/**
	 * @param args
	 * @throws ParseException 
	 */
	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		String str="11/30/5678";
		SimpleDateFormat sdf=new SimpleDateFormat("MM/dd/yyyy");
		Date date=sdf.parse(str);
		System.out.println(date);
		
	}

}
