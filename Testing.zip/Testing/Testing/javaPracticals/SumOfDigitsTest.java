package javaPracticals;

import java.util.Scanner;

public class SumOfDigitsTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num, remainder, sod=0;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Please any number: ");
		num=sc.nextInt();
		
		while(num>0) {
			remainder=num%10;
			num=num/10;
			sod=sod+remainder;
		}
		
		System.out.println("Number of digits are: "+sod);
		sc.close();
	}

}
