package javaPracticals;

import java.util.Scanner;

public class SwapTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1,num2;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter First Number: ");
		num1=sc.nextInt();
		
		System.out.println("Enter Second Number: ");
		num2=sc.nextInt();
		
		num1=num1+num2;
		num2=num1-num2;
		num1=num1-num2;
		System.out.println("First Number: "+num1+" Second Number: "+num2);
	}

}
