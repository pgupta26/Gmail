package javaPracticals;

import java.util.Scanner;

public class VowelsTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char ch;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter any character: ");
		ch=sc.next().charAt(0);
		
		if(ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u') {
			System.out.println("Character is vowel.");
		}else {
			System.out.println("Character is constant.");
		}
		
		sc.close();
	}
}
