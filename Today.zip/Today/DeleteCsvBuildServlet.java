/**
 * 
 */
package com;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

/**
 * @author e5399484
 *
 */
public class DeleteCsvBuildServlet extends HttpServlet {

	private String Upload_Dir;
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException{
		
		try{			
			//get request parameter
			//get request parameter
			String jobName=req.getParameter("jobName");
			String fileName=req.getParameter("fileName1").trim();
			
			//Read properties
			Upload_Dir=getProperty("Upload_Dir").trim()+File.separator+jobName;
			

			File archiveFolder=new File(Upload_Dir+"\\Archive");
			if(!archiveFolder.exists()){
				archiveFolder.mkdirs();
			}

			File deleteScript=new File(Upload_Dir+"\\"+fileName);
			if(deleteScript.exists()){
				deleteScript.renameTo(new File(Upload_Dir+"\\Archive\\"+fileName));
				deleteScript.delete();
			}
			
			String msg="Success";
			String json = new Gson().toJson(msg);

			res.setContentType("application/json");
			res.getWriter().write(json);
		}catch(Exception ex){
			String fail="1";

			String json = new Gson().toJson(fail);

			res.setContentType("application/json");
			res.getWriter().write(json);
		}
	}

	private String getProperty(String key) throws IOException {
		Properties prop = new Properties();
		InputStream input = null;

		ServletContext context = getServletContext();
		String configPath = context.getRealPath("/WEB-INF/config/config.properties");
		input = new FileInputStream(configPath);

		// load a properties file
		prop.load(input);

		// get the property value
		return prop.getProperty(key);
	}


}
