package automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class HomePage {

	WebDriver driver;

	public HomePage(WebDriver driver) {
		this.driver = driver;
	}

	
	
	public WebElement contactUsLink() throws Exception {

		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//a[contains(.,'CONTACT US')]"), 30);
	}

	public WebElement signInLink() throws Exception {

		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//a[contains(@href,'/Account/Login')]"), 30);
	}
	public WebElement signInLinkProd() throws Exception {

		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("(//a[@href='https://app.freightclub.com/QuickQuote/QuickQuote'])[1]"), 30);
	}	
	public WebElement trackShipmentButton() throws Exception {

		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//a[contains(@class,'track-btn track-one')]"), 30);
	}

}
