package automation;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.ISuite;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

public class InitializeTest {

	protected static WebDriver driver = null;
	
	private static String testname = null;
	public static String manageproductfile = null;

	
	@BeforeTest
	public void initialize(ITestContext context) {
		String testname = context.getCurrentXmlTest().getName();
		System.out.println("testname:"+testname);
		ScreenShot.createScreenshotFolder(testname);
	}
	

	@Parameters({ "browser", "URL" })
	@BeforeSuite
	public WebDriver setUp(String browser, String URL) throws Exception {

		driver = launchBrowser(browser);
		launchURL(URL);
		return driver;
	}

	@BeforeTest
	public void testName() {
		Log.info(testname + " started.");
	}

	@AfterSuite
	public void tearDown() {

		Log.info("Test Ended");
		driver.quit();
	}

	public WebDriver launchBrowser(String browser) throws Exception {

		try {
			if (browser.equalsIgnoreCase("firefox")) {
				System.setProperty("webdriver.gecko.driver", "binaries/geckodriver.exe");
				driver = new FirefoxDriver();
			}

			if (browser.equalsIgnoreCase("chrome")) {
				System.setProperty("webdriver.chrome.driver", "binaries/chromedriver.exe");
				driver = new ChromeDriver();
			}

			if (browser.equalsIgnoreCase("iexplorer")) {
				System.setProperty("webdriver.ie.driver", "binaries/IEDriverServer.exe");
				driver = new InternetExplorerDriver();
			}

			driver.manage().window().maximize();
			Log.info(browser + " browser launched successfully.");

		} catch (Exception e) {
			Log.error("Not able to launch browser: " + e.getMessage());
			throw e;
		}
		return driver;
	}

	public void launchURL(String URL) throws Exception {

		try {
			driver.get(URL);
			Log.info(URL + "URL launched successfully.");
		} catch (Exception e) {
			Log.error("Not able to launch URL: " + e.getMessage());
			throw e;
		}
	}

	public static WebDriver getDriver() {

		return driver;
	}
}
