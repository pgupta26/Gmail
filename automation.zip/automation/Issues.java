package automation;

public class Issues {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Xls_Reader res = new Xls_Reader("binaries/ResultsEnhancement.xlsx");
		System.out.println("test pass");
	}

}
