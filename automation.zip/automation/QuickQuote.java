package automation;


import java.text.DateFormatSymbols;
import java.util.Calendar;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;


public class QuickQuote {

	WebDriver driver;

	public QuickQuote(WebDriver driver) {
		this.driver = driver;
	}
	public WebElement MenuBarLink() throws Exception{

		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//button[@class='navbar-toggle hamburger hamburger-close navbar-toggle-left unfolded hided']"), 30);
	}
	public WebElement manageOrdersLink() throws Exception{

		return WaitTool.waitForElementPresentAndDisplay(driver, By.linkText("Quick Quote"), 30);
	}
	
	public WebElement ParcelShipment() throws Exception{

		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//input[@name='shipmentType' and @value='0']"), 30);
	}
	
	public WebElement LTLShipment() throws Exception{

		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//input[@name='shipmentType' and @value='1']"), 30);
	}
	
	public WebElement OrderDate() throws Exception{

		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//input[@id='OrderDate']"), 30);
	}
	public WebElement OrderDate1() throws Exception{

		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("(//td[contains(@class,'today')]/following-sibling::td)[1]"), 30);
	}
	public WebElement ClickDate(String date) throws Exception {
  
		try{
			List<WebElement> allDates= driver.findElements(By.xpath("//div[@class='datepicker-days']//td"));
			for(WebElement ele: allDates)
			{
				String dt= ele.getText();
				System.out.println("dt"+dt);
				if(dt.equalsIgnoreCase(date))
				{
					System.out.println("ele"+ele);
				return ele;	
				}
			}
		}
		catch (Exception e) {
				Log.error("Not able to select date " + e.getMessage());
				throw e;
			}
		return null;
		 
	}
	
	public WebElement OrderReferenceID() throws Exception {

		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//input[@id='OrderReferenceID']"), 30);
	}
	
	public WebElement ServiceLevel() throws Exception {
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//div[@class='selectize-control form-input single']"), 30);
		//return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//div[@class='selectize-input items full has-options has-items']"), 30);
	}
	public WebElement ServiceLevelWG() throws Exception{

		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//div[@class='selectize-dropdown-content']//div[@data-value='357']"), 30);
	}
	
	public WebElement ServiceLevelBOT() throws Exception{

		//return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//div[@class='selectize-dropdown single']//div[@data-value='351']"), 30);
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//div[@class='selectize-dropdown-content']//div[@data-value='351']"), 30);
	}
	
	public WebElement ServiceLevelCUR() throws Exception{

		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//div[@class='selectize-dropdown-content']//div[@data-value='352']"), 30);
	}
	
	public WebElement ServiceLevelTHR() throws Exception{

		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//div[@class='selectize-dropdown-content']//div[@data-value='353']"), 30);
	}
	
	public WebElement ServiceLevelROC() throws Exception{

		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//div[@class='selectize-dropdown-content']//div[@data-value='354']"), 30);
	}
	
	public WebElement ServiceLevelWGPR() throws Exception{

		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//div[@class='selectize-dropdown-content']//div[@data-value='355']"), 30);
	}
	public WebElement PickUpZip() throws Exception{

		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//input[@id='pickupzipEntry']"), 30);
	}
	
	public WebElement PickUpZipLocationTypeRes() throws Exception{

		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//*[@id=\"app-content\"]/div/div/div/section/section/div/div[3]/div[1]/div[3]/div/div[1]/div[2]/label"), 30);
		//return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//*[@id=\"page-content-wrapper\"]/div/div/div/div/section/div[2]/div/div/section/div[3]/div[1]/div[3]/div/div[1]/div[2]/label"), 30);
		//return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//input[@value='400'][1]"), 30);
	}
	
	public WebElement PickUpZipLocationTypeCom() throws Exception{
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//*[@id=\"app-content\"]/div/div/div/section/section/div/div[3]/div[1]/div[3]/div/div[1]/div[3]/label"), 30);
		//return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//*[@id=\"page-content-wrapper\"]/div/div/div/div/section/div[2]/div/div/section/div[3]/div[1]/div[3]/div/div[1]/div[3]/label"), 30);
		//return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//input[@value='401'][1]"), 30);
	}
	
	public WebElement DropOffZipLocationTypeRes() throws Exception{
	
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//*[@id=\"app-content\"]/div/div/div/section/section/div/div[3]/div[2]/div[3]/div/div[1]/div[2]/label"), 30);
		//return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//*[@id=\"page-content-wrapper\"]/div/div/div/div/section/div[2]/div/div/section/div[3]/div[2]/div[3]/div/div[1]/div[2]/label/input"), 30);
		//return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//input[@value='400'][2]"), 30);
	}
	
	public WebElement DropOffZipLocationTypeCom() throws Exception{
		//return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//*[@id=\"page-content-wrapper\"]/div/div/div/div/section/div[2]/div/div/section/div[3]/div[2]/div[3]/div/div[1]/div[3]/label/input"), 30);
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//*[@id=\"app-content\"]/div/div/div/section/section/div/div[3]/div[2]/div[3]/div/div[1]/div[3]/label"), 30);
		//return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//input[@value='401'][2]"), 30);
	}
	
	public WebElement DropOffZip() throws Exception{
		
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//input[@id='dropoffzipEntry']"), 90);
	}
	public WebElement PackageType() throws Exception{
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//div[@class='form-group col-sm-2']//div[@class='selectize-control form-input single']"), 30);
		//return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//input[@placeholder='Select or Search...']"), 90);
		//return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//div[@class='form-group col-xs-12 col-sm-5 col-md-5 col-lg-4']//div[@class='selectize-control form-input single']"), 90);
	}
	public WebElement PackageValue() throws Exception{
		
		//return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//div[@class='form-group col-xs-12 col-sm-5 col-md-5 col-lg-4']//div[@class='selectize-control form-input single']//div[1]"), 30);
		//return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//div[@class='form-group col-xs-12 col-sm-5 col-md-5 col-lg-4']//div[@class='selectize-control form-input single']//div[@class='selectize-input items has-options not-full']//input"), 30);
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//input[@placeholder='Select or Search...']"), 30);
		
	}	
    public WebElement PackageTypeOption() throws Exception{
		
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//div[@class='selectize-dropdown single packaging-type form-input']//div/div"), 30);
	}
	
    public void PackageTypeOptions(String packageType) {

		try {
		if(packageType.equalsIgnoreCase("Standard Pallet 1")){
			SeleniumFunction.click(driver.findElement
					(By.xpath("//div[@class='selectize-dropdown single packaging-type form-input']//div/div[@data-value='0']")));
		}
		else if(packageType.equalsIgnoreCase("Standard Pallet 2")){
			SeleniumFunction.click(driver.findElement
					(By.xpath("//div[@class='selectize-dropdown single packaging-type form-input']//div/div[@data-value='1']")));
		}
		else if(packageType.equalsIgnoreCase("Standard Pallet 3")){
			SeleniumFunction.click(driver.findElement
					(By.xpath("//div[@class='selectize-dropdown single packaging-type form-input']//div/div[@data-value='2']")));
		}
		else if(packageType.equalsIgnoreCase("Custom Pallet (enter dimensions)")){
			SeleniumFunction.click(driver.findElement
					(By.xpath("//div[@class='selectize-control form-input single']//div/div[@data-value='3']")));
		}
		else if(packageType.equalsIgnoreCase("Boxed")){
			SeleniumFunction.click(driver.findElement
					(By.xpath("//div[@class='selectize-dropdown single form-input']//div/div[@data-value='4']")));
		}
		else if(packageType.equalsIgnoreCase("My Own Package")){
			SeleniumFunction.click(driver.findElement
					(By.xpath("//div[@class='selectize-dropdown single form-input']//div/div[@data-value='4']")));
		}		
		}
		
		catch (Exception e) {
			Log.error("Not able to select package: " + e.getMessage());
			try {
				throw e;
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
    
    public WebElement Quantity() throws Exception {
    	return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//div[contains(@class,'quantity')]/input[@type='number']"), 30);
    }
    
    public WebElement Weight() throws Exception{
		
		//return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//*[@class='form-inline weight']/div/input"), 30);
    	//return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//input[@type='number' and @class='form-control form-input input-sm']"), 30);
    	return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//span[@class='input-group-btn']/input[@type='number' and @class='form-control form-input input-sm']"), 30);
	}
	
    public WebElement DimensionL()throws Exception {
		
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//input[@type='number' and @placeholder='L']"), 30);
	}
    
    public WebElement DimensionW() throws Exception{
		
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//input[@type='number' and @placeholder='W']"), 30);
	}
    
    public WebElement DimensionH()throws Exception {
		
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//input[@type='number' and @placeholder='H']"), 30);
	}

    public WebElement Category() throws Exception{
		
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//select[@class='form-input form-control input-sm']"), 30);
	}
  
      
   public void ServiceLevel(String Category) throws Exception {

		try {
			List<WebElement> Categories = driver.findElements(By.xpath("//div[@class='ms-drop bottom']"));
			for (int categorytypes = 0; categorytypes <= Categories.size(); categorytypes++) {
				if (Categories.get(categorytypes).getText().trim().equalsIgnoreCase(Category.trim())) {
					SeleniumFunction.click(driver.findElement(By.
							xpath("//div[@class='ms-drop bottom']/ul/li[13]")));
					break;
				}
			}
		} catch (Exception e) {
			Log.error("Not able to click package: " + e.getMessage());
			throw e;
		}
	}

   public WebElement DeclaredValue() throws Exception{
		
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//input[@type='number' and @min='0.01' and @step='0.01']"), 30);
	}
    
   public WebElement Cartons() throws Exception {
	   return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//div[@class='carton-count form-group col-xs-4 col-sm-2 col-md-2 col-lg-2']/input[@class='form-control form-input input-sm']"), 30);
		
 		//return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//td[@class='carton-count']/input[@class='form-control form-input input-sm']"), 30);
 	}
   
   
   public WebElement SaveButton() throws Exception {
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//*[@class='btn btn-primary btn-lg pull-right large-spacer']"), 30);
		//return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//*[@class='btn btn-success btn-lg pull-right large-spacer']"), 30);
	}
   

   
   public WebElement Carries() throws Exception{
		
 		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//div[@class='col-xs-12 ratequote']"), 30);
 	}
   public void ValidateCarriers(String i) {
		
		List <WebElement> carriers= driver.findElements(By.xpath("//div[@class='row ratequote']"));
		int carriercnt= carriers.size();
		String j=Integer.toString(carriercnt);
	UseAssert.assertEquals(j, i);
		
	}
   public String carriercount() throws Exception{
		
		List <WebElement> carriers= driver.findElements(By.xpath("//div[@class='row ratequote']"));
		int carriercnt= carriers.size();	
		String j=Integer.toString(carriercnt);
		return j;

		
	}
   
   public String Checkcarriername(String name) throws Exception{
		
    	List <WebElement> carriers= driver.findElements(By.xpath("//div[@class='bottom-spacer ratequote-group']"));
		int carriercnt= carriers.size();	
		System.out.println("carriercnt for "+name+":"+carriercnt);
		
		int counter = 0;
		
		for (int i=0; i<=carriercnt-1; i++)
		{
			String carriername=carriers.get(i).getText();
			if (carriername.contains(name))
			{
				counter=1;
				System.out.println("Checkcarriername "+carriers.get(i).getText()+ "FOUND");
				//break;
			}else
			{
				counter=0;
				System.out.println("Checkcarriername "+carriers.get(i).getText()+ "NOTFOUND");
				
			}
		}
		//String counter1=Integer.toString(counter);
		return Integer.toString(counter);
	
	} 
   public String CheckServicename(String name,String File) {
		//listof viewing carrier
   	  List <WebElement> carriers= driver.findElements(By.xpath("//table[@id='table-quotes']/tbody/tr/td[2]"));
   	  List <WebElement> carriersrate= driver.findElements(By.xpath("//table[@id='table-quotes']/tbody/tr/td[6]"));
	 //  List <WebElement> carriers= driver.findElements(By.xpath("//div[@class='row ratequote-item special']"));
		int carriercnt= carriers.size();	
		System.out.println("carriercnt for "+name+":"+carriercnt);
		System.out.println("carriercnt for "+name+":"+carriersrate.size());
		String[] price = null;
		String[] price1 = null;
		String ratevalue = null;
		int counter = 0;
		
		for (int i=0; i<=carriercnt-1; i++)
		{
			String carriername=carriers.get(i).getText();
			String carrierrate=carriersrate.get(i).getText();
			System.out.println("carriername excel: "+name);
			System.out.println("carriername application: "+carriername);
			if (carriername.contains(name))
			{
				counter=1;
				/*System.out.println("Checkcarriername "+carriers.get(i).getText()+ "FOUND");
				//price = carriername.split("\\r?\\n");
				String out = carriername.replaceAll("[\\t\\n\\r]+","");
				price = out.split("\\$");
				System.out.println("pricenew  "+price[1]); 
				 //ratevalue=price[1];
				 price1 = price[1].split("Next");
				 ratevalue=price1[0];*/
				String[] rate= carrierrate.split("\\$");
				ratevalue=rate[1];
				System.out.println("rate  "+ratevalue); 
				 
				break;
			}else
			{
				counter=0;
				System.out.println("Checkcarriername "+carriers.get(i).getText()+ "NOTFOUND");
				
			}
	}
		//listof hidden carrier
		/*			   List <WebElement> carriers1= driver.findElements(By.xpath("//div[@class='row ratequote-item']"));
		//List <WebElement> carriers1= driver.findElements(By.xpath("//div[@class='row ratequote']"));
		int carriercnt1= carriers1.size();	
		System.out.println("carriercntlist2 for "+name+":"+carriercnt1);
		
		int counter1 = 0;
		
		for (int i=0; i<=carriercnt1-1; i++)
		{
			String carriername1=carriers1.get(i).getText();
			//System.out.println("carriercnt for "+name+":"+carriercnt);
			if (carriername1.contains(name))
			{
				counter1=1;
				System.out.println("Checkcarriername "+carriers1.get(i).getText()+ "FOUND");
				// price = carriername1.split("\\r?\\n");
					String out = carriername1.replaceAll("[\\t\\n\\r]+","");
					price = out.split("\\$");
					System.out.println("pricenew  "+price[1]); 
					// ratevalue=price[1];
					 price1 = price[1].split("Next");
					 ratevalue=price1[0];
				
				break;
			}else
			{
				counter1=0;
				System.out.println("Checkcarriername "+carriers1.get(i).getText()+ "NOTFOUND");
				
			}
		}*/
		//if ((counter1==0) && (counter==0))
		if ((counter==0))
		{
			return Integer.toString(counter);	
		}else{
			return ratevalue;
		}
			
		//String counter1=Integer.toString(counter);
		
	
	}

   public WebElement resultCarrriesCat() throws Exception {
		
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//input[@placeholder='Filter by Service Level']"), 30);
	}
   public WebElement resultCarrriesLevel() throws Exception {
		
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//input[@placeholder='Filter by Carrier']"), 30);
	}
   public WebElement resultCarrries() throws Exception {
		
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//div[@class='selectize-input items not-full has-options focus input-active dropdown-active']/input"), 30);
	}
   

   public WebElement dropdownCatWHG() throws Exception {
		
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath(" //div[@data-value='355']"), 30);
	}
   public WebElement dropdownCatWHGLight() throws Exception {
		
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath(" //div[@data-value='357']"), 30);
	}
   public WebElement dropdownCatCurb() throws Exception {
		
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath(" //div[@data-value='352']"), 30);
	}
   
   public WebElement dropdownCatThr() throws Exception {
		
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath(" //div[@data-value='353']"), 30);
	}
   
   public WebElement dropdownCatROC() throws Exception {
		
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath(" //div[@data-value='354']"), 30);
	}
  
   public WebElement dropdownCatBOT() throws Exception {
		
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath(" //div[@data-value='351']"), 30);
	}
   public WebElement dropdownCarrierABF() throws Exception {
		
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath(" //div[@data-value='11']"), 30);
	}
  
   public WebElement dropdownCarrierAIT() throws Exception {
		
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath(" //div[@data-value='114']"), 30);
	}
   
   public WebElement dropdownCarrierCEVA() throws Exception {
		
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath(" //div[@data-value='44']"), 30);
	}
   
   public WebElement dropdownCarrierDEL() throws Exception {
		
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath(" //div[@data-value='122']"), 30);
	}
  
   public WebElement dropdownCarrierZen() throws Exception {
		
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath(" //div[@data-value='124']"), 30);
	}
   
   public WebElement dropdownCarrierEST() throws Exception {
		
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath(" //div[@data-value='22']"), 30);
	}
  
   public WebElement dropdownCarrierPIL() throws Exception {
		
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath(" //div[@data-value='33']"), 30);
	}
   
   public WebElement dropdownCarrierSEKO() throws Exception {
		
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath(" //div[@data-value='118']"), 30);
	}
   public WebElement dropdownCarrierWAT() throws Exception {
		
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath(" //div[@data-value='128']"), 30);
	}
   public WebElement dropdownCarrierYRC() throws Exception {
		
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath(" //div[@data-value='9']"), 30);
	}
   public WebElement PullDown() throws Exception {
		
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//div[@class='collapse-trigger']"), 30);
	} 
   public static int orderDate(){
	   Calendar cal=Calendar.getInstance();
	    int val = cal.get(Calendar.DAY_OF_WEEK);
	    System.out.println(new DateFormatSymbols().getWeekdays()[val]);
       String weekday=new DateFormatSymbols().getWeekdays()[val];
       
	   
       if(weekday.equalsIgnoreCase("Saturday")){
       	int orderdte=cal.get(Calendar.DAY_OF_MONTH)+2;
       	return orderdte;
       	 }
       else if(weekday.equalsIgnoreCase("Sunday")){
          	int orderdte=cal.get(Calendar.DAY_OF_MONTH)+1;
          	return orderdte;
       	}
       else {
       	int orderdte=cal.get(Calendar.DAY_OF_MONTH);
       	return orderdte;
       }
       
   }
	public WebElement manageProductLink() throws Exception {

		return WaitTool.waitForElementPresentAndDisplay(driver,
				By.xpath("//a[contains(@href,'/Product/UploadProducts')]"), 30);
	}          
	public void uploadFileProductChrome() throws Exception {

		try {
			SeleniumFunction.clickAction(driver, selectFilesFullOrder());
			String[] path = {
					//System.getProperty("user.dir") + "\\binaries\\Import_PIDs_Template_V4.xlsx" + InitializeTest.manageproductfile };
					System.getProperty("user.dir") + "\\binaries\\Import_PIDs_Template_V4.xlsx"};
			SeleniumFunction.runAutoItScript("manageproductuploadchrome.exe", path[0]);
		} catch (Exception e) {
			Log.error("Not able to upload file: " + e.getMessage());
			throw e;
		}
	}
	public WebElement selectFilesFullOrder() throws Exception {

		//return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath(".//*[@id='files']//ancestor::div[1]"), 30);
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//div[@class='k-button k-upload-button']"), 30);
	}
	public WebElement uploadButton() {

		//return WaitTool.waitForElementPresentAndDisplaySoft(driver, By.xpath("//button[contains(.,'Upload files')]"),30);
		return WaitTool.waitForElementPresentAndDisplaySoft(driver, By.xpath("//button[@class='k-button k-upload-selected']"), 30);
	}
	public WebElement OKButton() {

		return WaitTool.waitForElementPresentAndDisplaySoft(driver, By.xpath("//button[@class='btn btn-success']"), 30);
	}
	public void sucessMsgManageProducts() throws Exception {

		if (WaitTool.isElementPresentAndDisplay(driver, By.xpath("//div[contains(@class,'text-success')]"))) {
			String sucessMsg = SeleniumFunction.getText(successMsg());
			String imports = sucessMsg.substring(0, 1);
			Log.info("Imports: " + imports);
			if (Integer.parseInt(imports) > 0) {
				Log.info(SeleniumFunction.getText(successMsg()));
			} else {
				Log.error(SeleniumFunction.getText(successMsg()));
				Assert.fail();
			}
		}
	}
	public WebElement successMsg() throws Exception {

		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//div[contains(@class,'text-success')]"), 30);
	}	
	   public WebElement morecarrier() throws Exception {
			
			return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//a[@class='more-btn cursor-pointer collapsed']"), 30);
		}
	   public  WebElement selectcarrier(String carriername) throws Exception {
			
			return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//input[@label='filters-tab']/span[contains(text(),'"+carriername+"')]"), 30);
		}	   
}