package automation;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class ScreenShot extends InitializeTest {

	static String baseScreenShotsFolder;

	public static void takeScreenShot(WebDriver driver, String fileName) {

		try {
			WaitTool.sleep(2);
			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File(baseScreenShotsFolder + "/" + fileName + ".png"));
			System.out.print("baseScreenShotsFolder : "+baseScreenShotsFolder + "/" + fileName + ".png");
			Log.info("Screenshot " + fileName + " successfully taken.");
		} catch (Exception e) {
			Log.warn("Not able to take " + fileName + " screen shot: " + e.getMessage());
		}
	}

	public static void takeScreenShotOnFailure(String fileName) {

		try {
			WebDriver driver = getDriver();
			WaitTool.sleep(2);
			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File(baseScreenShotsFolder + "/Failed/" + fileName + ".png"));
			Log.info("Faliure screenshot " + fileName + " successfully taken.");
		} catch (Exception e) {
			Log.warn("Not able to take " + fileName + " screen shot: " + e.getMessage());
		}
	}

	public static String createScreenshotFolder(String testName) {
		try {
			System.out.print("testname : "+testName);
			baseScreenShotsFolder = System.getProperty("user.dir") + "/screen-shots/";
			SimpleDateFormat sdfmth = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
			Calendar cal = Calendar.getInstance();
			//baseScreenShotsFolder = baseScreenShotsFolder + "/" + InitializeTest.project + "/" + testName + "/"
			//		+ sdfmth.format(cal.getTime()).replaceAll("\\s", "_");
			baseScreenShotsFolder = baseScreenShotsFolder + "/" + testName + "/"
					+ sdfmth.format(cal.getTime()).replaceAll("\\s", "_");			
			new File(baseScreenShotsFolder).mkdirs();
			return baseScreenShotsFolder;
		} catch (Exception e) {
			Log.warn("Not able to create scree-shot folder: " + e.getMessage());
			return null;
		}
	}
}
