package automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class SignInPage {

	WebDriver driver;

	public SignInPage(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement usernameTextField() throws Exception {

		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//input[contains(@id,'Email')]"), 30);
	}

	public WebElement passowrdTextField() throws Exception {

		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//input[contains(@id,'Password')]"), 30);
	}
	
	public WebElement loginButton() throws Exception {

		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//input[contains(@type,'submit')]"), 30);
	}

}
