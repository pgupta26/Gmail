package automation;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.HasInputDevices;
import org.openqa.selenium.interactions.Keyboard;
import org.testng.Reporter;
import org.testng.TestNG;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestFileRate extends InitializeTest {

	@Test
	public void TestRateVerifyCarrierName() throws Exception {

		driver.manage().window().maximize();
		HomePage homePage = new HomePage(driver);
		SeleniumFunction.clickJS(driver, homePage.signInLinkProd());
		SeleniumFunction.clickJS(driver, homePage.signInLink());
		
		SignInPage signInPage = new SignInPage(driver);
		QuickQuote quickQuote = new QuickQuote(driver);
		ScreenShot.takeScreenShot(driver, "Login Page");
/*		SeleniumFunction.sendKeys(signInPage.usernameTextField(), "24aug@mailinator.com");
		SeleniumFunction.sendKeys(signInPage.passowrdTextField(), "@Test123");*/	
		SeleniumFunction.sendKeys(signInPage.usernameTextField(), "qatest@cymax.com");
		SeleniumFunction.sendKeys(signInPage.passowrdTextField(), "Welcome@2");
		SeleniumFunction.clickJS(driver, signInPage.loginButton());
		WaitTool.sleep(10);
		// RunTest
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		Xls_Reader res = new Xls_Reader("binaries/ResultsEnhancement.xlsx");
		Xls_Reader xr1 = new Xls_Reader("binaries/TestRun.xlsx");
		int rcnt1 = xr1.getRowCount("Input");
		System.out.println("rcntTESTRUN:" + rcnt1);
		for (int j = 2; j <= rcnt1; j++) {
			String File = xr1.getCellData("Input", "File", j).trim();
			String Status = xr1.getCellData("Input", "Status", j).trim();
			if (Status.equals("Y") && (File.equals("Testfile"))) {
				// Get Excel Data
				Xls_Reader xr = new Xls_Reader("binaries/" + File + ".xlsx");
				System.out.println("File:" + File);
				// Xls_Reader xr=new Xls_Reader("binaries/FCFile.xlsx");
				int rcnt = xr.getRowCount("Input");
				System.out.println("rcnt:" + rcnt);

				//if (j > 2) {
					// SeleniumFunction.click(quickQuote.MenuBarLink());
					SeleniumFunction.clickJS(driver, quickQuote.manageOrdersLink());
				//}
				for (int i = 2; i <= rcnt; i++) {
					String NoCarriers=null;
					// for(int j=1; j<=ccnt;j++){
					// String cellDataNew=xr.getCellData("Input",j, i).trim();
					// System.out.print(cellDataNew+"\n");

					String shipmentType = xr.getCellData("Input", "shipmentType", i).trim();
					String serviceLevel = xr.getCellData("Input", "serviceLevel", i).trim();
					String orderReferenceID = xr.getCellData("Input", "orderReferenceID", i).trim();
					String pickUpZip = xr.getCellData("Input", "pickUpZip", i).trim();
					String PickZip = pickUpZip.substring(0, 5); // return value 90001
					String pickUpType = xr.getCellData("Input", "pickUpType", i).trim();
					String dropOffZip = xr.getCellData("Input", "dropOffZip", i).trim();
					String dropOffType = xr.getCellData("Input", "dropOffType", i).trim();
					String packageType = xr.getCellData("Input", "packageType", i).trim();					
					// Objective1
/*					String Estes = xr.getCellData("Input", "Estes", i).trim();
					String fedex = xr.getCellData("Input", "FedexFreight", i).trim();
					String yrc = xr.getCellData("Input", "YRC", i).trim();
					String abf = xr.getCellData("Input", "ABF", i).trim();
					String wat = xr.getCellData("Input", "Watkins", i).trim();
					String del = xr.getCellData("Input", "Deliveright", i).trim();*/
					
					String Estes = xr.getCellData("Input", 9, 1).trim();
					String fedex = xr.getCellData("Input", 10, 1).trim();
					String yrc = xr.getCellData("Input", 12, 1).trim();
					String abf = xr.getCellData("Input", 8, 1).trim();
					String wat = xr.getCellData("Input", 13, 1).trim();
					String del = xr.getCellData("Input", 11, 1).trim();
				
					
					System.out.println(pickUpZip);
					System.out.println("i" + i);
					// click on quickquote
					if (i > 2) {
						SeleniumFunction.clickJS(driver, quickQuote.manageOrdersLink());
					}

					if (shipmentType.equalsIgnoreCase("LTL")) {
						SeleniumFunction.click(quickQuote.LTLShipment());
					} else {
						SeleniumFunction.click(quickQuote.ParcelShipment());
					}

					SeleniumFunction.click(quickQuote.OrderDate());

					int orderdte = QuickQuote.orderDate();

					String orderdate = Integer.toString(orderdte);
					WaitTool.sleep(5);
					// SeleniumFunction.click(quickQuote.ClickDate(orderdate));
					SeleniumFunction.click(quickQuote.OrderDate1());

					SeleniumFunction.sendKeys(quickQuote.OrderReferenceID(), orderReferenceID);
					SeleniumFunction.clickAction(driver, quickQuote.ServiceLevel());
					WaitTool.sleep(5);
					if (serviceLevel.contains("White Glove-Light Assembly")) {
						SeleniumFunction.click(quickQuote.ServiceLevelWG());
					} else if (serviceLevel.contains("Back Of Truck")) {
						SeleniumFunction.click(quickQuote.ServiceLevelBOT());
					} else if (serviceLevel.contains("Curbside")) {
						SeleniumFunction.click(quickQuote.ServiceLevelCUR());
					} else if (serviceLevel.contains("Threshold")) {
						SeleniumFunction.click(quickQuote.ServiceLevelTHR());
					} else if (serviceLevel.contains("Room of Choice")) {
						SeleniumFunction.click(quickQuote.ServiceLevelROC());
					} else if (serviceLevel.contains("White Glove-Packaging Removal")) {
						SeleniumFunction.click(quickQuote.ServiceLevelWGPR());
					}


/*					SeleniumFunction.sendKeys(quickQuote.PickUpZip(), pickUpZip.substring(0, pickUpZip.length() - 2));
					SeleniumFunction.sendKeys(quickQuote.DropOffZip(),
							dropOffZip.substring(0, dropOffZip.length() - 2));*/
					SeleniumFunction.sendKeys(quickQuote.PickUpZip(),pickUpZip);
					SeleniumFunction.sendKeys(quickQuote.DropOffZip(),dropOffZip);				
					jse.executeScript("window.scrollBy(0,150)", "");
					if (pickUpType.contains("Commercial")) {
						SeleniumFunction.click(quickQuote.PickUpZipLocationTypeCom());
					} else {
						SeleniumFunction.click(quickQuote.PickUpZipLocationTypeRes());
					}

					if (dropOffType.contains("Commercial")) {
						SeleniumFunction.click(quickQuote.DropOffZipLocationTypeCom());
					} else {
						SeleniumFunction.click(quickQuote.DropOffZipLocationTypeRes());

					}
					
					jse.executeScript("window.scrollBy(0,250)", "");

					SeleniumFunction.click(quickQuote.PackageType());
					Keyboard keyboard=((HasInputDevices) driver).getKeyboard();
				    keyboard.pressKey(Keys.BACK_SPACE);
					WaitTool.sleep(5);
					//quickQuote.PackageTypeOptions(packageType);
					//System.out.println("package selected :"+packageType);
					SeleniumFunction.sendKeys(quickQuote.PackageValue(),packageType);
					WaitTool.sleep(5);
					SeleniumFunction.KeyBoradEnter(driver);
					WaitTool.sleep(5);
					// ScreenShot.takeScreenShot(driver, "Data-Provided"+i);
					
					jse.executeScript("window.scrollBy(0,550)", "");

					SeleniumFunction.click(quickQuote.SaveButton());
					WaitTool.sleep(30);
					ScreenShot.takeScreenShot(driver, "shipment info");
					System.out.println("Value of I - "+i);
					System.out.println("packageType - "+packageType);
					
					jse.executeScript("window.scrollBy(2500,0)", "");
					jse.executeScript("scroll(2500, 0);");
					ScreenShot.takeScreenShot(driver, "Quick quote page");
					
					//GeT OrderId from url
					System.out.println("url - "+driver.getCurrentUrl());
					String URL[] = driver.getCurrentUrl().split("orderId=");
					System.out.println("ORDERID - "+URL[1]);
					res.setCellData("Testfile", "OrderID", i, URL[1]);
					
					// Run Objective1
					if (File.equals("Testfile")) {
						SeleniumFunction.click(quickQuote.resultCarrriesCat());
						WaitTool.sleep(2);
						if (serviceLevel.equals("White Glove-Packaging Removal")) {
							if(driver.findElements(By.xpath(" //div[@data-value='355']")).size() > 0) {
								System.out.println("White Glove-Packaging Removal is present");
								NoCarriers="Carriers";
								SeleniumFunction.click(quickQuote.dropdownCatWHG());
								}else{
								System.out.println("White Glove-Packaging Removal is not present");
								res.setCellData("Testfile", Estes, i, "No Rates");
								res.setCellData("Testfile", yrc, i, "No Rates");
								res.setCellData("Testfile", abf, i, "No Rates");
								res.setCellData("Testfile", wat, i, "No Rates");
								res.setCellData("Testfile", fedex, i, "No Rates");
								res.setCellData("Testfile", del, i, "No Rates");
								NoCarriers="NoCarriers";
								}
							
							WaitTool.sleep(2);
						} else if (serviceLevel.equals("White Glove-Light Assembly")) {
							if(driver.findElements(By.xpath(" //div[@data-value='357']")).size() > 0) {
								System.out.println("White Glove-Light Assembly is present");
								NoCarriers="Carriers";
								SeleniumFunction.click(quickQuote.dropdownCatWHGLight());
								}else{
								System.out.println("White Glove-Light Assembly is not present");
								res.setCellData("Testfile", Estes, i, "No Rates");
								res.setCellData("Testfile", yrc, i, "No Rates");
								res.setCellData("Testfile", abf, i, "No Rates");
								res.setCellData("Testfile", wat, i, "No Rates");
								res.setCellData("Testfile", fedex, i, "No Rates");
								res.setCellData("Testfile", del, i, "No Rates");
								NoCarriers="NoCarriers";
								}
							
							WaitTool.sleep(2);
						}else if (serviceLevel.equals("Back Of Truck")) {
							NoCarriers="Carriers";
						SeleniumFunction.click(quickQuote.dropdownCatBOT());
						WaitTool.sleep(2);
					    }else if (serviceLevel.equals("Curbside")) {
					    	NoCarriers="Carriers";
						SeleniumFunction.click(quickQuote.dropdownCatCurb());
						WaitTool.sleep(2);
					    }else if (serviceLevel.equals("Threshold")) {
					    	NoCarriers="Carriers";
						SeleniumFunction.click(quickQuote.dropdownCatThr());
					    }else if (serviceLevel.equals("Room of Choice")) {
					    	NoCarriers="Carriers";
						SeleniumFunction.click(quickQuote.dropdownCatROC());						
						
					    }
						WaitTool.sleep(2);					    					
						//Boolean isPresent=driver.findElements(By.xpath("//div[@class='collapse-trigger']")).size() > 0;
						
						//if( driver.findElement(By.xpath("//div[@class='collapse-trigger']")).isDisplayed()){
						if(driver.findElements(By.xpath("//div[@class='collapse-trigger']")).size() > 0) {
							System.out.println("Element is Visible");
							jse.executeScript("window.scrollBy(0,550)", "");
							SeleniumFunction.click(quickQuote.PullDown());
							}else{
							System.out.println("Element is InVisible");
							}
						
						WaitTool.sleep(2);
						jse.executeScript("window.scrollBy(0,150)", "");
						System.out.println("Value of NoCarriers: "+NoCarriers);
						if(NoCarriers.contains("NoCarriers"))
						{	
							System.out.print("No Rates for selected carriers");
						}
						else {
							System.out.println("Value of NoCarriers: "+NoCarriers);
						// Estes
						String Estesrate = quickQuote.CheckServicename(Estes,File);
						System.out.print(Estesrate);
						if (!Estesrate.equals("0")) {
							System.out.print("Estesrate" + Estesrate);
							String rate=Estesrate;
							//String rate = Estesrate.substring(1, Estesrate.length());
							System.out.print("rate: " + rate);
								System.out.print("pass");
								res.setCellData("Testfile", Estes, i, rate);

						} else {
							//Check Input file also have No Rates for selected carrier
							System.out.print("norates");
							if(xr.getCellData("Input",Estes, i).trim().equals("No Rates")) 
							{
								System.out.print("norates");
								res.setCellData("Testfile", Estes, i, "No Rates");	
							}else {
								System.out.print("fail no carrier");
								res.setCellData("Testfile", Estes, i, "Carrier should display rates");
								res.ColorColumn("Testfile", Estes, i);
							}						
						}
						// yrc
						String yrcname = quickQuote.CheckServicename(yrc,File);
						System.out.print(yrcname);
						System.out.print("col:"+yrc);
						if (!yrcname.equals("0")) {
							System.out.print("yrcname" + yrcname);
							String rate=yrcname;
							//String rate = yrcname.substring(1, yrcname.length());
							System.out.print("rate: " + rate);
								System.out.print("pass");
								res.setCellData("Testfile", yrc, i, rate);

						} else {
							//Check Input file also have No Rates for selected carrier
							System.out.print("norates");
							if(xr.getCellData("Input",yrc, i).trim().equals("No Rates")) 
							{
								System.out.print("norates");
								res.setCellData("Testfile", yrc, i, "No Rates");	
							}else {
								System.out.print("fail no carrier");
								res.setCellData("Testfile", yrc, i, "Carrier should display rates");
								res.ColorColumn("Testfile", yrc, i);
							}	
							
							
						}
						
						

						// DEL
						String delname = quickQuote.CheckServicename(del,File);
						System.out.print(delname);
						if (!delname.equals("0")) {
							System.out.print("delname" + delname);
							String rate=delname;
							//String rate = delname.substring(1, delname.length());
							System.out.print("rate: " + rate);
								System.out.print("pass");
								res.setCellData("Testfile", del, i, rate);

						} else {
							//Check Input file also have No Rates for selected carrier
							System.out.print("norates");
							if(xr.getCellData("Input",del, i).trim().equals("No Rates")) 
							{
								System.out.print("norates");
								res.setCellData("Testfile", del, i, "No Rates");	
							}else {
								System.out.print("fail no carrier");
								res.setCellData("Testfile", del, i, "Carrier should display rates");
								res.ColorColumn("Testfile", del, i);
							}
			
						}
						
						// ABF
						String abfname = quickQuote.CheckServicename(abf,File);
						System.out.print(abfname);
						if (!abfname.equals("0")) {
							System.out.print("abfname" + abfname);
							String rate=abfname;
							//String rate = abfname.substring(1, abfname.length());
							System.out.print("rate: " + rate);
								System.out.print("pass");
								res.setCellData("Testfile", abf, i, rate);

						} else {
							//Check Input file also have No Rates for selected carrier
							System.out.print("norates");
							if(xr.getCellData("Input",abf, i).trim().equals("No Rates")) 
							{
								System.out.print("norates");
								res.setCellData("Testfile", abf, i, "No Rates");	
							}else {
								System.out.print("fail no carrier");
								res.setCellData("Testfile", abf, i, "Carrier should display rates");
								res.ColorColumn("Testfile", abf, i);
							}	
									
						}
						// WAT
						String watname = quickQuote.CheckServicename(wat,File);
						System.out.print(watname);
						if (!watname.equals("0")) {
							System.out.print("watname" + watname);
							String rate=watname;
							//String rate = watname.substring(1, watname.length());
							System.out.print("rate: " + rate);
								System.out.print("pass");
								res.setCellData("Testfile", wat, i, rate);

						} else {
							//Check Input file also have No Rates for selected carrier
							System.out.print("norates");
							if(xr.getCellData("Input",wat, i).trim().equals("No Rates")) 
							{
								System.out.print("norates");
								res.setCellData("Testfile", wat, i, "No Rates");	
							}else {
								System.out.print("fail no carrier");
								res.setCellData("Testfile", wat, i, "Carrier should display rates");
								res.ColorColumn("Testfile", wat, i);
							}	
						
											
						}							
						// fedex
						String fedexname = quickQuote.CheckServicename(fedex,File);
						System.out.print(fedexname);
						if (!fedexname.equals("0")) {
							System.out.print("fedexname" + fedexname);
							String rate=fedexname;
							//String rate = fedexname.substring(1, fedexname.length());
							System.out.print("rate: " + rate);
								System.out.print("pass");
								res.setCellData("Testfile", fedex, i, rate);

						} else {
							//Check Input file also have No Rates for selected carrier
							System.out.print("norates");
							if(xr.getCellData("Input",fedex, i).trim().equals("No Rates")) 
							{
								System.out.print("norates");
								res.setCellData("Testfile", fedex, i, "No Rates");	
							}else {
								System.out.print("fail no carrier");
								res.setCellData("Testfile", fedex, i, "Carrier should display rates");
								res.ColorColumn("Testfile", fedex, i);
							}	
										
						}	

				}
					}

				}
			}
		}
		//driver.close();

	}

}
