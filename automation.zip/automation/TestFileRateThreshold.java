package automation;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.HasInputDevices;
import org.openqa.selenium.interactions.Keyboard;
import org.testng.annotations.Test;

public class TestFileRateThreshold extends InitializeTest {

	@Test
	public void TestRateVerifyCarrierName() throws Exception {

		driver.manage().window().maximize();
		HomePage homePage = new HomePage(driver);
		WaitTool.sleep(5);
		//SeleniumFunction.clickJS(driver, homePage.signInLinkProd());
		SeleniumFunction.click(homePage.signInLinkProd());
		WaitTool.sleep(5);
		SeleniumFunction.click(homePage.signInLink());
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		SignInPage signInPage = new SignInPage(driver);
		QuickQuote quickQuote = new QuickQuote(driver);
		WaitTool.sleep(5);
		ScreenShot.takeScreenShot(driver, "Login Page");
		/*SeleniumFunction.sendKeys(signInPage.usernameTextField(), "24aug@mailinator.com");
		SeleniumFunction.sendKeys(signInPage.passowrdTextField(), "@Test123");	*/	
		SeleniumFunction.sendKeys(signInPage.usernameTextField(), "qatest@cymax.com");
		SeleniumFunction.sendKeys(signInPage.passowrdTextField(), "Welcome@2");	
		SeleniumFunction.clickJS(driver, signInPage.loginButton());
		WaitTool.sleep(5);
		// RunTest
		Xls_Reader res = new Xls_Reader("binaries/ResultsEnhancement.xlsx");
		Xls_Reader xr1 = new Xls_Reader("binaries/TestRun.xlsx");
		int rcnt1 = xr1.getRowCount("Input");
		System.out.println("rcntTESTRUN:" + rcnt1);
		for (int j = 2; j <= rcnt1; j++) {
			String File = xr1.getCellData("Input", "File", j).trim();
			String Status = xr1.getCellData("Input", "Status", j).trim();
			if (Status.equals("Y") && (File.equals("TestfileThreshold"))) {
				// Get Excel Data
				Xls_Reader xr = new Xls_Reader("binaries/" + File + ".xlsx");
				System.out.println("File:" + File);
				// Xls_Reader xr=new Xls_Reader("binaries/FCFile.xlsx");
				int rcnt = xr.getRowCount("Input");
				System.out.println("rcnt:" + rcnt);

				//if (j > 2) {
					// SeleniumFunction.click(quickQuote.MenuBarLink());
					SeleniumFunction.clickJS(driver, quickQuote.manageOrdersLink());
				//}
				for (int i = 2; i <= rcnt; i++) {
					String NoCarriers=null;
					// for(int j=1; j<=ccnt;j++){
					// String cellDataNew=xr.getCellData("Input",j, i).trim();
					// System.out.print(cellDataNew+"\n");

					String shipmentType = xr.getCellData("Input", "shipmentType", i).trim();
					String serviceLevel = xr.getCellData("Input", "serviceLevel", i).trim();
					String orderReferenceID = xr.getCellData("Input", "orderReferenceID", i).trim();
					String pickUpZip = xr.getCellData("Input", "pickUpZip", i).trim();
					String PickZip = pickUpZip.substring(0, 5); // return value 90001
					String pickUpType = xr.getCellData("Input", "pickUpType", i).trim();
					String dropOffZip = xr.getCellData("Input", "dropOffZip", i).trim();
					String dropOffType = xr.getCellData("Input", "dropOffType", i).trim();
					String packageType = xr.getCellData("Input", "packageType", i).trim();					
					// Objective1
/*					String Estes = xr.getCellData("Input", "Estes", i).trim();
					String fedex = xr.getCellData("Input", "FedexFreight", i).trim();
					String yrc = xr.getCellData("Input", "YRC", i).trim();
					String abf = xr.getCellData("Input", "ABF", i).trim();
					String wat = xr.getCellData("Input", "Watkins", i).trim();
					String del = xr.getCellData("Input", "Deliveright", i).trim();*/
					
					String abf = xr.getCellData("Input", 8, 1).trim();
					String Estes = xr.getCellData("Input", 10, 1).trim();
					String fedex = xr.getCellData("Input", 12, 1).trim();
					String del = xr.getCellData("Input", 14, 1).trim();
					String yrc = xr.getCellData("Input", 16, 1).trim();
					String wat = xr.getCellData("Input", 18, 1).trim();
					
					
				
					
					System.out.println(pickUpZip);
					System.out.println("i" + i);
					// click on quickquote
					if (i > 2) {
						SeleniumFunction.clickJS(driver, quickQuote.manageOrdersLink());
					}

	/*				if (shipmentType.equalsIgnoreCase("LTL")) {
						SeleniumFunction.click(quickQuote.LTLShipment());
					} else {
						SeleniumFunction.click(quickQuote.ParcelShipment());
					}*/

					

					//int orderdte = QuickQuote.orderDate();

					//String orderdate = Integer.toString(orderdte);
					
					
					SeleniumFunction.click(quickQuote.OrderDate());
					//SeleniumFunction.sendKeys(quickQuote.OrderDate(),"01-16-2018");
					WaitTool.sleep(5);
					SeleniumFunction.click(quickQuote.OrderDate1());

					SeleniumFunction.sendKeys(quickQuote.OrderReferenceID(), orderReferenceID);
					SeleniumFunction.clickAction(driver, quickQuote.ServiceLevel());
					WaitTool.sleep(5);
					if (serviceLevel.contains("White Glove-Light Assembly")) {
						SeleniumFunction.clickJS(driver, quickQuote.ServiceLevelWG());
						//SeleniumFunction.click(quickQuote.ServiceLevelWG());
					} else if (serviceLevel.contains("Back Of Truck")) {
						SeleniumFunction.clickJS(driver, quickQuote.ServiceLevelBOT());
						//SeleniumFunction.click(quickQuote.ServiceLevelBOT());
					} else if (serviceLevel.contains("Curbside")) {
						SeleniumFunction.clickJS(driver, quickQuote.ServiceLevelCUR());
						//SeleniumFunction.click(quickQuote.ServiceLevelCUR());
					} else if (serviceLevel.contains("Threshold")) {
						SeleniumFunction.clickJS(driver, quickQuote.ServiceLevelTHR());
						//SeleniumFunction.click(quickQuote.ServiceLevelTHR());
					} else if (serviceLevel.contains("Room of Choice")) {
						SeleniumFunction.clickJS(driver, quickQuote.ServiceLevelROC());
						//SeleniumFunction.click(quickQuote.ServiceLevelROC());
					} else if (serviceLevel.contains("White Glove-Packaging Removal")) {
						SeleniumFunction.clickJS(driver, quickQuote.ServiceLevelWGPR());
						//SeleniumFunction.click(quickQuote.ServiceLevelWGPR());
					}


/*					SeleniumFunction.sendKeys(quickQuote.PickUpZip(), pickUpZip.substring(0, pickUpZip.length() - 2));
					SeleniumFunction.sendKeys(quickQuote.DropOffZip(),
							dropOffZip.substring(0, dropOffZip.length() - 2));*/
					SeleniumFunction.sendKeys(quickQuote.PickUpZip(),pickUpZip);
					SeleniumFunction.sendKeys(quickQuote.DropOffZip(),dropOffZip);				
					jse.executeScript("window.scrollBy(0,150)", "");
					if (pickUpType.contains("Commercial")) {
						System.out.println("compick");
						SeleniumFunction.click(quickQuote.PickUpZipLocationTypeCom());
					} else {
						System.out.println("respick");
						SeleniumFunction.click(quickQuote.PickUpZipLocationTypeRes());
					}

					if (dropOffType.contains("Commercial")) {
						System.out.println("comdrop");
						SeleniumFunction.click(quickQuote.DropOffZipLocationTypeCom());
					} else {
						System.out.println("resdrop");
						SeleniumFunction.click(quickQuote.DropOffZipLocationTypeRes());

					}
					WaitTool.sleep(2);
					jse.executeScript("window.scrollBy(0,250)", "");

					SeleniumFunction.click(quickQuote.PackageType());
					Keyboard keyboard=((HasInputDevices) driver).getKeyboard();
				    keyboard.pressKey(Keys.BACK_SPACE);
					WaitTool.sleep(5);
					//quickQuote.PackageTypeOptions(packageType);
					//System.out.println("package selected :"+packageType);
					SeleniumFunction.sendKeys(quickQuote.PackageValue(),packageType);
					WaitTool.sleep(5);
					SeleniumFunction.KeyBoradEnter(driver);
					WaitTool.sleep(5);
					// ScreenShot.takeScreenShot(driver, "Data-Provided"+i);
					
					jse.executeScript("window.scrollBy(0,550)", "");

					//Added by parshant
					/*SeleniumFunction.sendKeys(quickQuote.Quantity(), "1");
					SeleniumFunction.sendKeys(quickQuote.Weight(), "1");
					SeleniumFunction.sendKeys(quickQuote.DimensionL(), "1");
					SeleniumFunction.sendKeys(quickQuote.DimensionW(), "1");
					SeleniumFunction.sendKeys(quickQuote.DimensionW(), "1");
					SeleniumFunction.selectByvalue(quickQuote.Category(), "Appliances");
					SeleniumFunction.sendKeys(quickQuote.DeclaredValue(), "1");*/
					
					
					SeleniumFunction.click(quickQuote.SaveButton());
					WaitTool.sleep(25);
					ScreenShot.takeScreenShot(driver, "shipment info");
					System.out.println("Value of I - "+i);
					System.out.println("packageType - "+packageType);
					
					//jse.executeScript("window.scrollBy(2500,0)", "");
					//jse.executeScript("scroll(2500, 0);");
					jse.executeScript("window.scrollBy(0,1100)", "");
					ScreenShot.takeScreenShot(driver, "Quick quote page");
					WaitTool.sleep(5);
					//GeT OrderId from url
					System.out.println("url - "+driver.getCurrentUrl());
					String URL[] = driver.getCurrentUrl().split("orderId=");
					System.out.println("ORDERID - "+URL[1]);
					res.setCellData("Testfile", "OrderID", i, URL[1]);
					
					// Run Objective1
					if (File.equals("TestfileThreshold")) {
	
						/*SeleniumFunction.click(quickQuote.resultCarrriesCat());
						WaitTool.sleep(2);
						if (serviceLevel.equals("White Glove-Packaging Removal")) {
							if(driver.findElements(By.xpath(" //div[@data-value='355']")).size() > 0) {
								System.out.println("White Glove-Packaging Removal is present");
								NoCarriers="Carriers";
								SeleniumFunction.click(quickQuote.dropdownCatWHG());
								}else{
								System.out.println("White Glove-Packaging Removal is not present");
								res.setCellData("TestfileThreshold", Estes, i, "No Rates");
								res.setCellData("TestfileThreshold", yrc, i, "No Rates");
								res.setCellData("TestfileThreshold", abf, i, "No Rates");
								res.setCellData("TestfileThreshold", wat, i, "No Rates");
								res.setCellData("TestfileThreshold", fedex, i, "No Rates");
								res.setCellData("TestfileThreshold", del, i, "No Rates");
								
								res.setCellData("Testfile", Estes, i, "No Rates");
								res.setCellData("Testfile", yrc, i, "No Rates");
								res.setCellData("Testfile", abf, i, "No Rates");
								res.setCellData("Testfile", wat, i, "No Rates");
								res.setCellData("Testfile", fedex, i, "No Rates");
								res.setCellData("Testfile", del, i, "No Rates");
								NoCarriers="NoCarriers";
								}
							
							WaitTool.sleep(2);
						} else if (serviceLevel.equals("White Glove-Light Assembly")) {
							if(driver.findElements(By.xpath(" //div[@data-value='357']")).size() > 0) {
								System.out.println("White Glove-Light Assembly is present");
								NoCarriers="Carriers";
								SeleniumFunction.click(quickQuote.dropdownCatWHGLight());
								}else{
								System.out.println("White Glove-Light Assembly is not present");
								res.setCellData("TestfileThreshold", Estes, i, "No Rates");
								res.setCellData("TestfileThreshold", yrc, i, "No Rates");
								res.setCellData("TestfileThreshold", abf, i, "No Rates");
								res.setCellData("TestfileThreshold", wat, i, "No Rates");
								res.setCellData("TestfileThreshold", fedex, i, "No Rates");
								res.setCellData("TestfileThreshold", del, i, "No Rates");
								
								res.setCellData("Testfile", Estes, i, "No Rates");
								res.setCellData("Testfile", yrc, i, "No Rates");
								res.setCellData("Testfile", abf, i, "No Rates");
								res.setCellData("Testfile", wat, i, "No Rates");
								res.setCellData("Testfile", fedex, i, "No Rates");
								res.setCellData("Testfile", del, i, "No Rates");
								NoCarriers="NoCarriers";
								}
							
							WaitTool.sleep(2);
						}else if (serviceLevel.equals("Back Of Truck")) {
							NoCarriers="Carriers";
						SeleniumFunction.click(quickQuote.dropdownCatBOT());
						WaitTool.sleep(2);
					    }else if (serviceLevel.equals("Curbside")) {
					    	NoCarriers="Carriers";
						SeleniumFunction.click(quickQuote.dropdownCatCurb());
						WaitTool.sleep(2);
					    }else if (serviceLevel.equals("Threshold")) {
					    	NoCarriers="Carriers";
						SeleniumFunction.click(quickQuote.dropdownCatThr());
					    }else if (serviceLevel.equals("Room of Choice")) {
					    	NoCarriers="Carriers";
						SeleniumFunction.click(quickQuote.dropdownCatROC());						
						
					    }
						WaitTool.sleep(5);					    					
						//Boolean isPresent=driver.findElements(By.xpath("//div[@class='collapse-trigger']")).size() > 0;

						//if( driver.findElement(By.xpath("//div[@class='collapse-trigger']")).isDisplayed()){
						if(driver.findElements(By.xpath("//div[@class='collapse-trigger']")).size() > 0) {
							System.out.println("Element is Visible");
							jse.executeScript("window.scrollBy(0,550)", "");
							SeleniumFunction.click(quickQuote.PullDown());
							}else{
							System.out.println("Element is InVisible");
							}
						
						WaitTool.sleep(2);
						jse.executeScript("window.scrollBy(0,150)", "");
						WaitTool.sleep(5);
						System.out.println("Value of NoCarriers: "+NoCarriers);*/
						
						//if(NoCarriers.contains("NoCarriers"))
						//{	
						//	System.out.print("No Rates for selected carriers");
						//}
						//else {
						//	System.out.println("Value of NoCarriers: "+NoCarriers);
							
						// Estes
						String Estesrate = quickQuote.CheckServicename(Estes,File);
						String Estesratevalue = quickQuote.CheckServicename(Estes,File);// rates value
						System.out.print(Estesrate);
						if (!Estesrate.equals("0")) {
							//check rates values
							res.setCellData("Testfile", Estes, i, Estesratevalue);								
					/*		//select carrier
							if(driver.findElements(By.xpath("//a[@class='more-btn cursor-pointer collapsed']")).size() != 0){
								System.out.println("more option");
								SeleniumFunction.click(quickQuote.morecarrier());
								}else{
								System.out.println("nomore option");
								}	
							SeleniumFunction.click(quickQuote.selectcarrier(Estes));*/
							
							//check Threshold values
							System.out.print("Estesrate" + Estesrate);
							String rate=Estesrate;
							System.out.print("rate: " + rate);                          
							String Rate1 = xr.getCellData("Input", Estes, i).trim().replaceAll("[^\\d.]", "");//remove any special charater(,) like 1,000
							float Rate = Float.parseFloat(Rate1);
							float RateThres = Float.parseFloat(xr.getCellData("Input", "Estes Threshold", i).trim());
							System.out.print("Rate-" + Rate);
							System.out.print("RateThres-" + RateThres);
							rate = rate.replaceAll("[^\\d.]", "");//remove any special charater(,) like 1,000 
							float ratevalue = (Rate * (RateThres / 100)) + Rate;
							float rate1 = Float.parseFloat(rate);
							System.out.print("ratevalue-" + ratevalue);
							System.out.print("rate1-" + rate1);
							if (rate1 <= ratevalue) {
								System.out.print("pass");
								// xr.setCellData("Input", Estes1, i, Rate + "-Pass");
								res.setCellData("TestfileThreshold", Estes, i, "Rates are within Threshold");

							} else {
								System.out.print("fail");
								// xr.setCellData("Input", Estes1, i, Rate + "-fail");
								res.setCellData("TestfileThreshold", Estes, i, "Rates are higher");
								res.ColorColumn("TestfileThreshold", Estes, i);
							}
								//System.out.print("pass");
								//res.setCellData("Testfile", Estes, i, rate);

						} else {
							//Check Input file also have No Rates for selected carrier
							System.out.print("norates");
							if(xr.getCellData("Input",Estes, i).trim().equals("No Rates")) 
							{
								System.out.print("norates");
								res.setCellData("TestfileThreshold", Estes, i, "No Rates");	
								res.setCellData("Testfile", Estes, i, "No Rates");	
							}else {
								System.out.print("fail no carrier");
								res.setCellData("TestfileThreshold", Estes, i, "Carrier should display rates");
								res.ColorColumn("TestfileThreshold", Estes, i);
								res.setCellData("Testfile", Estes, i, "Carrier should display rates");
								res.ColorColumn("Testfile", Estes, i);
							}						
						}
						// yrc
						String yrcrate = quickQuote.CheckServicename(yrc,File);
						String yrcratevalue = quickQuote.CheckServicename(yrc,File);
						System.out.print(yrcrate);
						System.out.print("col:"+yrc);
						if (!yrcrate.equals("0")) {
							//check rates
							res.setCellData("Testfile", yrc, i, yrcratevalue);
							//check threshold rates
							System.out.print("yrcrate" + yrcrate);
							String ratee = yrcrate;
							System.out.print("ratee-" + ratee);
							String Rate1 = xr.getCellData("Input", yrc, i).trim().replaceAll("[^\\d.]", "");//remove any special charater(,) like 1,000
							float Rate = Float.parseFloat(Rate1);
							float RateThres = Float.parseFloat(xr.getCellData("Input", "YRC Threshold", i).trim());
							ratee = ratee.replaceAll("[^\\d.]", "");//remove any special charater(,) like 1,000 
							float ratevalue = (Rate * (RateThres / 100)) + Rate;
							float rate1 = Float.parseFloat(ratee);
							System.out.print("ratevalue-" + ratevalue);
							System.out.print("rate1-" + rate1);
							if (rate1 <= ratevalue) {
								System.out.print("pass");
								res.setCellData("TestfileThreshold", yrc, i, "Rates are within Threshold");
							} else {
								System.out.print("fail");
								res.setCellData("TestfileThreshold", yrc, i, "Rates are higher");
								res.ColorColumn("TestfileThreshold", yrc, i);
							}
							System.out.print("CARRIER is valid for " + yrc);
							} else {
							//Check Input file also have No Rates for selected carrier
							System.out.print("norates");
							if(xr.getCellData("Input",yrc, i).trim().equals("No Rates")) 
							{
								System.out.print("norates");
								res.setCellData("TestfileThreshold", yrc, i, "No Rates");	
								res.setCellData("Testfile", yrc, i, "No Rates");
							}else {
								System.out.print("fail no carrier");
								res.setCellData("TestfileThreshold", yrc, i, "Carrier should display rates");
								res.ColorColumn("TestfileThreshold", yrc, i);
								res.setCellData("Testfile", yrc, i, "Carrier should display rates");
								res.ColorColumn("Testfile", yrc, i);
							}	
							
							
						}
					
						// DEL
						String delrate = quickQuote.CheckServicename(del,File);
						String delratevalue = quickQuote.CheckServicename(del,File);
						System.out.print(delrate);
						if (!delrate.equals("0")) {
							//check rates
							res.setCellData("Testfile", del, i, delratevalue);
							//check threshold rates							
							System.out.print("delrate" + delrate);
							String ratee = delrate;
							System.out.print("ratee-" + ratee);
							
							String Rate1 = xr.getCellData("Input", del, i).trim().replaceAll("[^\\d.]", "");//remove any special charater(,) like 1,000
							float Rate = Float.parseFloat(Rate1.trim());
							float RateThres = Float
									.parseFloat(xr.getCellData("Input", "Deliveright Threshold", i).trim());
							
							ratee = ratee.replaceAll("[^\\d.]", "");//remove any special charater(,) like 1,000 
							float ratevalue = (Rate * (RateThres / 100)) + Rate;
							float rate1 = Float.parseFloat(ratee);
							System.out.print("ratevalue-" + ratevalue);
							System.out.print("rate1-" + rate1);
							if (rate1 <= ratevalue) {
								System.out.print("pass");
								res.setCellData("TestfileThreshold", del, i, "Rates are within Threshold");
							} else {
								System.out.print("fail");
								res.setCellData("TestfileThreshold", del, i, "Rates are higher");
								res.ColorColumn("TestfileThreshold", del, i);
							}
							System.out.print("CARRIER is  valid for " + del);
							// xr.setCellData("Input", wat, i, "Pass");
						} else {
							//Check Input file also have No Rates for selected carrier
							System.out.print("norates");
							if(xr.getCellData("Input",del, i).trim().equals("No Rates")) 
							{
								System.out.print("norates");
								res.setCellData("TestfileThreshold", del, i, "No Rates");	
								res.setCellData("Testfile", del, i, "No Rates");
							}else {
								System.out.print("fail no carrier");
								res.setCellData("TestfileThreshold", del, i, "Carrier should display rates");
								res.ColorColumn("TestfileThreshold", del, i);
								res.setCellData("Testfile", del, i, "Carrier should display rates");
								res.ColorColumn("Testfile", del, i);
							}
			
						}
						
						// ABF
						String abfrate = quickQuote.CheckServicename(abf,File);
						String abfratevalue = quickQuote.CheckServicename(abf,File);
						System.out.print(abfrate);
						if (!abfrate.equals("0")) {
							//check rates
							res.setCellData("Testfile", abf, i, abfratevalue);
							//check threshold rates		
							System.out.print("abfrate" + abfrate);
							String ratee = abfrate;
							//String ratee = abfrate.substring(1, abfrate.length());
							System.out.print("ratee-" + ratee);
							String Rate1 = xr.getCellData("Input", abf, i).trim().replaceAll("[^\\d.]", "");//remove any special charater(,) like 1,000
							float Rate = Float.parseFloat(Rate1);
							//float Rate = Float.parseFloat(xr.getCellData("Input", abf, i).trim());
							float RateThres = Float.parseFloat(xr.getCellData("Input", "ABF Threshold", i).trim());
							System.out.print("rATEEXCEL-" + Rate);
							System.out.print("RateThresEXCEL-" + RateThres);
							
							float ratevalue = (Rate * (RateThres / 100)) + Rate;
							System.out.print("ratevalue-" + ratevalue);	
							ratee = ratee.replaceAll("[^\\d.]", "");//remove any special charater(,) like 1,000 
							float rate1 = Float.parseFloat(ratee);
							/*int rate1 = Integer.parseInt(ratee);*/
							System.out.print("rate1-" + rate1);
							
							if (rate1 <= ratevalue) {
								res.setCellData("TestfileThreshold", abf, i, "Rates are within Threshold");
							} else {
								System.out.print("fail");
								res.setCellData("TestfileThreshold", abf, i, "Rates are higher");
								res.ColorColumn("ThreTestfileThresholdshold", abf, i);
							}
							System.out.print("CARRIER is valid for " + abf);
						} else {
							//Check Input file also have No Rates for selected carrier
							System.out.print("norates");
							if(xr.getCellData("Input",abf, i).trim().equals("No Rates")) 
							{
								System.out.print("norates");
								res.setCellData("TestfileThreshold", abf, i, "No Rates");
								res.setCellData("Testfile", abf, i, "No Rates");
							}else {
								System.out.print("fail no carrier");
								res.setCellData("TestfileThreshold", abf, i, "Carrier should display rates");
								res.ColorColumn("TestfileThreshold", abf, i);
								res.setCellData("Testfile", abf, i, "Carrier should display rates");
								res.ColorColumn("Testfile", abf, i);
							}	
									
						}
						// WAT
						String WATrate = quickQuote.CheckServicename(wat,File);
						String watratevalue = quickQuote.CheckServicename(wat,File);
						System.out.print(WATrate);
						if (!WATrate.equals("0")) {
							//check rates
							res.setCellData("Testfile", wat, i, watratevalue);
							//check threshold rates	
							System.out.print("WATrate" + WATrate);
							String ratee = WATrate;
							//String ratee = WATrate.substring(1, WATrate.length());
							System.out.print("ratee-" + ratee);
							String Rate1 = xr.getCellData("Input", wat, i).trim().replaceAll("[^\\d.]", "");//remove any special charater(,) like 1,000
							float Rate = Float.parseFloat(Rate1);
							//float Rate = Float.parseFloat(xr.getCellData("Input", wat, i).trim());
							float RateThres = Float.parseFloat(xr.getCellData("Input", "Watkins Threshold", i).trim());
							System.out.print("Rate-" + Rate);
							System.out.print("RateThres-" + RateThres);
							float ratevalue = (Rate * (RateThres / 100)) + Rate;
							float rate1 = Float.parseFloat(ratee);
							System.out.print("ratevalue-" + ratevalue);
							System.out.print("rate1-" + rate1);
							if (rate1 <= ratevalue) {
								System.out.print("pass");
								res.setCellData("TestfileThreshold", wat, i, "Rates are within Threshold");
							} else {
								System.out.print("fail");
								res.setCellData("TestfileThreshold", wat, i, "Rates are higher");
								res.ColorColumn("TestfileThreshold", wat, i);
							}
							System.out.print("CARRIER is valid for " + wat);

						} else {
							//Check Input file also have No Rates for selected carrier
							System.out.print("norates");
							if(xr.getCellData("Input",wat, i).trim().equals("No Rates")) 
							{
								System.out.print("norates");
								res.setCellData("TestfileThreshold", wat, i, "No Rates");	
								res.setCellData("Testfile", wat, i, "No Rates");
							}else {
								System.out.print("fail no carrier");
								res.setCellData("TestfileThreshold", wat, i, "Carrier should display rates");
								res.ColorColumn("TestfileThreshold", wat, i);
								res.setCellData("Testfile", wat, i, "Carrier should display rates");
								res.ColorColumn("Testfile", wat, i);
							}	
						
											
						}							
						// fedex
						String fedexrate = quickQuote.CheckServicename(fedex,File);
						String fedexratevalue = quickQuote.CheckServicename(fedex,File);
						System.out.print(fedexrate);
						if (!fedexrate.equals("0")) {
							//check rates
							res.setCellData("Testfile", fedex, i, fedexratevalue);
							//check threshold rates	
							System.out.print("fedexrate" + fedexrate);
							String ratee = fedexrate;
							//String ratee = WATrate.substring(1, WATrate.length());
							System.out.print("ratee-" + ratee);
							String Rate1 = xr.getCellData("Input", fedex, i).trim().replaceAll("[^\\d.]", "");//remove any special charater(,) like 1,000
							float Rate = Float.parseFloat(Rate1);
							//float Rate = Float.parseFloat(xr.getCellData("Input", fedex, i).trim());
							float RateThres = Float
									.parseFloat(xr.getCellData("Input", "FedEx Threshold", i).trim());

							float ratevalue = (Rate * (RateThres / 100)) + Rate;
							float rate1 = Float.parseFloat(ratee);
							System.out.print("ratevalue-" + ratevalue);
							System.out.print("rate1-" + rate1);
							if (rate1 <= ratevalue) {
								System.out.print("pass");
								res.setCellData("TestfileThreshold", fedex, i, "Rates are within Threshold");
							} else {
								System.out.print("fail");
								res.setCellData("TestfileThreshold", fedex, i, "Rates are higher");
								res.ColorColumn("TestfileThreshold", fedex, i);
							}
							System.out.print("CARRIER is valid for " + fedex);

						} else {
							//Check Input file also have No Rates for selected carrier
							System.out.print("norates");
							if(xr.getCellData("Input",fedex, i).trim().equals("No Rates")) 
							{
								System.out.print("norates");
								res.setCellData("TestfileThreshold", fedex, i, "No Rates");	
								res.setCellData("Testfile", fedex, i, "No Rates");	
							}else {
								System.out.print("fail no carrier");
								res.setCellData("TestfileThreshold", fedex, i, "Carrier should display rates");
								res.ColorColumn("TestfileThreshold", fedex, i);
								res.setCellData("Testfile", fedex, i, "Carrier should display rates");
								res.ColorColumn("Testfile", fedex, i);
							}	
										
						}	

			//	}
					}

				}
				System.out.print("outloop oredr id");
			}
			System.out.print("outif");
		}
		//driver.close();
		System.out.print("outloop");

	}

}
