package automation;


import java.util.List;

import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.TestNG;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.collections.Lists;

import com.gargoylesoftware.htmlunit.util.StringUtils;


@Test 
public class TestGetQuote {
	public static void main(String args[]){
		
		try {
			DOMConfigurator.configure("log4j.xml");
			TestNG testng = new TestNG();
			List<String> suites = Lists.newArrayList();
			suites.add("testng.xml");// path to xml..
			testng.setTestSuites(suites);
			testng.run();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
		
		
		/*
		System.setProperty("webdriver.chrome.driver", "binaries/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		driver.get("http://qa.freightclub.com/");
		driver.manage().window().maximize();
		
		HomePage homePage = new HomePage(driver);
		SeleniumFunction.clickJS(driver, homePage.signInLink());
		SignInPage signInPage = new SignInPage(driver);
		QuickQuote quickQuote = new QuickQuote(driver);
		SeleniumFunction.sendKeys(signInPage.usernameTextField(), "qatest@cymax.com");
		SeleniumFunction.sendKeys(signInPage.passowrdTextField(), "Welcome@2");
		SeleniumFunction.clickJS(driver, signInPage.loginButton());
		WaitTool.sleep(10);
		
        //RunTest
		Xls_Reader xr1=new Xls_Reader("binaries/TestRun.xlsx");
		
		int rcnt1=xr1.getRowCount("Input");
		System.out.println("rcntTESTRUN:"+rcnt1);
		for(int j=2;j<=rcnt1;j++)
		{
			String File=xr1.getCellData("Input","File", j).trim();
			String Status=xr1.getCellData("Input","Status", j).trim();
		if(Status.equals("Y"))
		{
		//Get Excel Data
		 Xls_Reader xr=new Xls_Reader("binaries/"+File+".xlsx");
		 System.out.println("File:"+File);
		//Xls_Reader xr=new Xls_Reader("binaries/FCFile.xlsx");
		int rcnt=xr.getRowCount("Input");
		System.out.println("rcnt:"+rcnt);
		
		if (j>2)
		{
			//SeleniumFunction.click(quickQuote.MenuBarLink());
			SeleniumFunction.clickJS(driver, quickQuote.manageOrdersLink());
		}
		for(int i=2;i<=rcnt;i++)
		{
			
//			for(int j=1; j<=ccnt;j++){
//				String cellDataNew=xr.getCellData("Input",j, i).trim();
//				System.out.print(cellDataNew+"\n");
			
			String shipmentType=xr.getCellData("Input","shipmentType", i).trim();
			String serviceLevel=xr.getCellData("Input","serviceLevel", i).trim();
			String orderReferenceID=xr.getCellData("Input","orderReferenceID", i).trim();
			String pickUpZip=xr.getCellData("Input","pickUpZip", i).trim();
			String PickZip = pickUpZip.substring (0,5); //return value 90001	
			String pickUpType=xr.getCellData("Input","pickUpType", i).trim();
			String dropOffZip=xr.getCellData("Input","dropOffZip", i).trim();
			String dropOffType=xr.getCellData("Input","dropOffType", i).trim();			
			String packageType=xr.getCellData("Input","packageType", i).trim();
			String Weight=xr.getCellData("Input","Weight", i).trim();
			String DimensionL=xr.getCellData("Input","DimensionL", i).trim();
			String DimensionW=xr.getCellData("Input","DimensionW", i).trim();
			String DimensionH=xr.getCellData("Input","DimensionH", i).trim();
			String category1=xr.getCellData("Input","category", i).trim();			
			String DeclaredValue=xr.getCellData("Input","DeclaredValue", i).trim();
			String Cartons=xr.getCellData("Input","Cartons", i).trim();
			String Carriers=xr.getCellData("Input", "Carriers", i).trim();
			//Objective1
			String Estes=xr.getCellData("Input",15,1);
			String Seko=xr.getCellData("Input",16,1);
			String yrc=xr.getCellData("Input",17,1);
			String abf=xr.getCellData("Input",18,1);
			String pilot=xr.getCellData("Input",19,1);
			String wat=xr.getCellData("Input",20,1);
			String ait=xr.getCellData("Input",21,1);
			String ceva=xr.getCellData("Input",22,1);
			String del=xr.getCellData("Input",23,1);
			String zen=xr.getCellData("Input",24,1);
			//Objective2
			String Estes1=xr.getCellData("Input",15,1);
			String Seko1=xr.getCellData("Input",17,1);
			String yrc1=xr.getCellData("Input",19,1);
			String abf1=xr.getCellData("Input",21,1);
			String pilot1=xr.getCellData("Input",23,1);
			String wat1=xr.getCellData("Input",25,1);
			String ait1=xr.getCellData("Input",27,1);
			String ceva1=xr.getCellData("Input",29,1);
			String del1=xr.getCellData("Input",31,1);
			String zen1=xr.getCellData("Input",33,1);
			
			String EstesThres=xr.getCellData("Input",16,1);
			String SekoThres=xr.getCellData("Input",18,1);
			String yrcThres=xr.getCellData("Input",20,1);
			String abfThres=xr.getCellData("Input",22,1);
			String pilotThres=xr.getCellData("Input",24,1);
			String watThres=xr.getCellData("Input",26,1);
			String aitThres=xr.getCellData("Input",28,1);
			String cevaThres=xr.getCellData("Input",30,1);
			String delThres=xr.getCellData("Input",32,1);
			String zenThres=xr.getCellData("Input",34,1);
			
			System.out.println(pickUpZip);			
			System.out.println("i"+i);
			//click on quickquote
			if (i>2)
			{
				SeleniumFunction.click(quickQuote.MenuBarLink());
				SeleniumFunction.clickJS(driver, quickQuote.manageOrdersLink());
			}
			
			if (shipmentType.equalsIgnoreCase("LTL"))
			{
			SeleniumFunction.click(quickQuote.LTLShipment());
			}
			else{
			SeleniumFunction.click(quickQuote.ParcelShipment());
			}
			
			
			SeleniumFunction.click(quickQuote.OrderDate());
		
			int orderdte= QuickQuote.orderDate();
			
			String orderdate=Integer.toString(orderdte);
			WaitTool.sleep(5);
			//SeleniumFunction.click(quickQuote.ClickDate(orderdate));
			SeleniumFunction.click(quickQuote.OrderDate1());
			
			SeleniumFunction.sendKeys(quickQuote.OrderReferenceID(), orderReferenceID);
			SeleniumFunction.clickAction(driver,quickQuote.ServiceLevel());
			
		
			if(serviceLevel.contains("White Glove - Light Assembly"))
			{
			SeleniumFunction.click(quickQuote.ServiceLevelWG());
			}
			else if(serviceLevel.contains("Back Of Truck"))
			{
				SeleniumFunction.click(quickQuote.ServiceLevelBOT());
			}	
			else if(serviceLevel.contains("Curbside"))
			{
				SeleniumFunction.click(quickQuote.ServiceLevelCUR());
			}	
			else if(serviceLevel.contains("Threshold"))
			{
				SeleniumFunction.click(quickQuote.ServiceLevelTHR());
			}	
			else if(serviceLevel.contains("Room of Choice"))
			{
				SeleniumFunction.click(quickQuote.ServiceLevelROC());
			}
			else if(serviceLevel.contains("White Glove - Packaging Removal"))
			{
				SeleniumFunction.click(quickQuote.ServiceLevelWGPR());
			}
			
						
			//SeleniumFunction.select(quickQuote.ServiceLevelOptions(), "Back Of Truck (No Liftgate) - One man delivery - Customer to remove shipment from truck");
	        		
			//int zip=Integer.parseInt(pickUpZip);
			
			SeleniumFunction.sendKeys(quickQuote.PickUpZip(),pickUpZip.substring(0,pickUpZip.length()-2));
			SeleniumFunction.sendKeys(quickQuote.DropOffZip(), dropOffZip.substring(0,dropOffZip.length()-2));
			
			if(pickUpType=="Commercial")
			{
				SeleniumFunction.click(quickQuote.PickUpZipLocationTypeCom());
			}
			else
			{
				SeleniumFunction.click(quickQuote.PickUpZipLocationTypeRes());
			}
			
			if(dropOffType=="Commercial")
			{
				SeleniumFunction.click(quickQuote.DropOffZipLocationTypeCom());
			}
			else
			{SeleniumFunction.click(quickQuote.DropOffZipLocationTypeRes());
			
			}
			
			if(category1.equalsIgnoreCase("Other"))
			{
			SeleniumFunction.selectByvalue(quickQuote.Category(), "347");
			}
			else
			{
				SeleniumFunction.selectByvalue(quickQuote.Category(), "346");
			}
		
		SeleniumFunction.click(quickQuote.PackageType());
			
			
		quickQuote.PackageTypeOptions(packageType);
		System.out.println("package selected");
		SeleniumFunction.click(quickQuote.Weight());
		SeleniumFunction.sendKeys(quickQuote.Weight(), Weight);
	    SeleniumFunction.sendKeys(quickQuote.DimensionL(), DimensionL);
		
		SeleniumFunction.sendKeys(quickQuote.DimensionW(),DimensionW);
			
		SeleniumFunction.sendKeys(quickQuote.DimensionH(), DimensionH);
		SeleniumFunction.sendKeys(quickQuote.DeclaredValue(), DeclaredValue);
		if(!packageType.equals("My Own Package")){
			SeleniumFunction.sendKeys(quickQuote.Cartons(), Cartons);	
		}

	    WaitTool.sleep(5);
	//	ScreenShot.takeScreenShot(driver, "Data-Provided"+i);
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("window.scrollBy(0,250)", "");
		
		SeleniumFunction.click(quickQuote.SaveButton());
		WaitTool.sleep(20);
        ScreenShot.takeScreenShot(driver, "Carriers");
		String carrier  = Carriers.split("\\.")[0];
	    quickQuote.ValidateCarriers(carrier);
		jse.executeScript("window.scrollBy(2500,0)", "");
		jse.executeScript("scroll(2500, 0);");
		
		//Run Objective1
		if(File.equals("FCFile"))
		{
		//Estes
		System.out.print("estes pickUpZip-"+PickZip);
		if(PickZip.contains("35004")||PickZip.contains("23233"))
			{
			SeleniumFunction.click(quickQuote.resultCarrriesLevel());
			WaitTool.sleep(5);
			SeleniumFunction.click(quickQuote.dropdownCarrierEST());
			WaitTool.sleep(5);
			String Estesname=quickQuote.Checkcarriername(Estes);
			
			if (Estesname.equals("1"))
			{			
				xr.setCellData("Input", Estes, i, "Pass");
			}else
			{
				xr.setCellData("Input", Estes, i, "Fail");
			}
		}
		//xr.setCellData("Input", "WhiteGlove", i, cnt1);
		//Seko
		driver.navigate().refresh();
		WaitTool.sleep(5);
		SeleniumFunction.click(quickQuote.resultCarrriesLevel());
		WaitTool.sleep(5);
		SeleniumFunction.click(quickQuote.dropdownCarrierSEKO());
		WaitTool.sleep(5);
		String SEKOName=quickQuote.Checkcarriername(Seko);
		
		if (SEKOName.equals("1"))
		{			
			xr.setCellData("Input", Seko, i, "Pass");
		}else
		{
			xr.setCellData("Input", Seko, i, "Fail");
		}
		//yrc
		driver.navigate().refresh();
		WaitTool.sleep(5);
		SeleniumFunction.click(quickQuote.resultCarrriesLevel());
		WaitTool.sleep(5);
		SeleniumFunction.click(quickQuote.dropdownCarrierYRC());
		WaitTool.sleep(5);
		String yrcName=quickQuote.Checkcarriername(yrc);
		
		if (yrcName.equals("1"))
		{			
			xr.setCellData("Input", yrc, i, "Pass");
		}else
		{
			xr.setCellData("Input", yrc, i, "Fail");
		}
		//ABF
		driver.navigate().refresh();
		WaitTool.sleep(5);
		SeleniumFunction.click(quickQuote.resultCarrriesLevel());
		WaitTool.sleep(5);
		SeleniumFunction.click(quickQuote.dropdownCarrierABF());
		WaitTool.sleep(5);
		String ABFName=quickQuote.Checkcarriername(abf);
		
		if (ABFName.equals("1"))
		{			
			xr.setCellData("Input", abf, i, "Pass");
		}else
		{
			xr.setCellData("Input", abf, i, "Fail");
		}
		//pil
		driver.navigate().refresh();
		WaitTool.sleep(5);
		SeleniumFunction.click(quickQuote.resultCarrriesLevel());
		WaitTool.sleep(5);
		SeleniumFunction.click(quickQuote.dropdownCarrierPIL());
		WaitTool.sleep(5);
		String pilotName=quickQuote.Checkcarriername(pilot);
		
		if (pilotName.equals("1"))
		{			
			xr.setCellData("Input", pilot, i, "Pass");
		}else
		{
			xr.setCellData("Input", pilot, i, "Fail");
		}
		//AIT
		driver.navigate().refresh();
		WaitTool.sleep(5);
		SeleniumFunction.click(quickQuote.resultCarrriesLevel());
		WaitTool.sleep(5);
		SeleniumFunction.click(quickQuote.dropdownCarrierAIT());
		WaitTool.sleep(5);
		String aitName=quickQuote.Checkcarriername(ait);
		
		if (aitName.equals("1"))
		{			
			xr.setCellData("Input", ait, i, "Pass");
		}else
		{
			xr.setCellData("Input", ait, i, "Fail");
		}
		//ceva
		driver.navigate().refresh();
		WaitTool.sleep(5);
		SeleniumFunction.click(quickQuote.resultCarrriesLevel());
		WaitTool.sleep(5);
		SeleniumFunction.click(quickQuote.dropdownCarrierCEVA());
		WaitTool.sleep(5);
		String cevaName=quickQuote.Checkcarriername(ceva);
		
		if (cevaName.equals("1"))
		{			
			xr.setCellData("Input", ceva, i, "Pass");
		}else
		{
			xr.setCellData("Input", ceva, i, "Fail");
		}
		//DEL
		driver.navigate().refresh();
		WaitTool.sleep(5);
		SeleniumFunction.click(quickQuote.resultCarrriesLevel());
		WaitTool.sleep(5);
		SeleniumFunction.click(quickQuote.dropdownCarrierDEL());
		WaitTool.sleep(5);
		String delName=quickQuote.Checkcarriername(del);
		
		if (delName.equals("1"))
		{			
			xr.setCellData("Input", del, i, "Pass");
		}else
		{
			xr.setCellData("Input", del, i, "Fail");
		}		
		//Zenith
		System.out.print("pickUpZip-"+PickZip);
		if(PickZip.contains("90001")||PickZip.contains("23233"))
			{
			driver.navigate().refresh();
			WaitTool.sleep(5);			
			SeleniumFunction.click(quickQuote.resultCarrriesLevel());
			WaitTool.sleep(5);
			SeleniumFunction.click(quickQuote.dropdownCarrierZen());
			WaitTool.sleep(5);
			String zenname=quickQuote.Checkcarriername(zen);
			
			if (zenname.equals("1"))
			{			
				xr.setCellData("Input", zen, i, "Pass");
			}else
			{
				xr.setCellData("Input", zen, i, "Fail");
			}			
		}
		//Wet
		System.out.print("packageType-"+packageType);
		if(packageType.contains("My Own Package"))
			{
			driver.navigate().refresh();
			WaitTool.sleep(5);			
			SeleniumFunction.click(quickQuote.resultCarrriesLevel());
			WaitTool.sleep(5);
			SeleniumFunction.click(quickQuote.dropdownCarrierWAT());
			WaitTool.sleep(5);
			String watname=quickQuote.Checkcarriername(wat);
			
			if (watname.equals("1"))
			{			
				xr.setCellData("Input", wat, i, "Pass");
			}else
			{
				xr.setCellData("Input", wat, i, "Fail");
			}			
		    }		
		}
		//Run Objective2
		if(File.equals("Threshold"))
		{
			
			SeleniumFunction.click(quickQuote.resultCarrriesCat());
			WaitTool.sleep(2);
			if(serviceLevel.equals("White Glove - Packaging Removal"))
			{				
				SeleniumFunction.click(quickQuote.dropdownCatWHG());
				WaitTool.sleep(2);
			}else if(serviceLevel.equals("White Glove - Light Assembly")){
				SeleniumFunction.click(quickQuote.dropdownCatWHGLight());
				WaitTool.sleep(2);
			}
			SeleniumFunction.click(quickQuote.PullDown());
			WaitTool.sleep(2);
			jse.executeScript("window.scrollBy(0,250)", "");
			//Estes
			String Estesrate=quickQuote.CheckServicename(Estes1);
			System.out.print(Estesrate);
			if (!Estesrate.equals("0"))
			{	
				System.out.print("Estesrate"+Estesrate);
				String ratee = Estesrate.substring (1,Estesrate.length());				
				System.out.print("ratee-"+ratee);	
				float Rate = Float.parseFloat(xr.getCellData("Input","Estes", i).trim());		
				float RateThres = Float.parseFloat(xr.getCellData("Input","Estes Threshold", i).trim());
				
				float ratevalue = (Rate*(RateThres/100))+Rate;
				float rate1 = Float.parseFloat(ratee);
				System.out.print("ratevalue-"+ratevalue);
				System.out.print("rate1-"+rate1);
				if(rate1<=ratevalue)
				{
					System.out.print("pass");
					xr.setCellData("Input", Estes1, i, Rate+"-Pass");
				}else{
					System.out.print("fail");
					xr.setCellData("Input", Estes1, i, Rate+"-fail");
				}
				System.out.print("CARRIER is valid for "+Estes1);
				
			}else
			{
				System.out.print("CARRIER is not valid for "+Estes1);
				xr.setCellData("Input", Estes1, i, "NA");
				//xr.setCellData("Input", wat, i, "Fail");
			}
			//xr.setCellData("Input", "WhiteGlove", i, cnt1);
			//Seko
			String Sekorate=quickQuote.CheckServicename(Seko1);
			System.out.print(Sekorate);
			if (!Sekorate.equals("0"))
			{	
				System.out.print("Sekorate"+Sekorate);
				String ratee = Sekorate.substring (1,Sekorate.length());				
				System.out.print("ratee-"+ratee);	
				float Rate = Float.parseFloat(xr.getCellData("Input","Seko", i).trim());		
				float RateThres = Float.parseFloat(xr.getCellData("Input","Seko Threshold", i).trim());
				
				float ratevalue = (Rate*(RateThres/100))+Rate;
				float rate1 = Float.parseFloat(ratee);
				System.out.print("ratevalue-"+ratevalue);
				System.out.print("rate1-"+rate1);
				if(rate1<=ratevalue)
				{
					System.out.print("pass");
					xr.setCellData("Input", Seko1, i, Rate+"-pass");
				}else{
					System.out.print("fail");
					xr.setCellData("Input", Seko1, i, Rate+"-fail");
				}
				System.out.print("CARRIER is  valid for "+Seko1);
				//xr.setCellData("Input", wat, i, "Pass");
			}else
			{
				System.out.print("CARRIER is not valid for "+Seko1);
				xr.setCellData("Input", Seko1, i, "NA");
			}
			//yrc
			String yrcrate=quickQuote.CheckServicename(yrc1);
			System.out.print(yrcrate);
			if (!yrcrate.equals("0"))
			{	
				System.out.print("yrcrate"+yrcrate);
				String ratee = yrcrate.substring (1,yrcrate.length());				
				System.out.print("ratee-"+ratee);	
				float Rate = Float.parseFloat(xr.getCellData("Input","YRC", i).trim());		
				float RateThres = Float.parseFloat(xr.getCellData("Input","YRC Threshold", i).trim());
				
				float ratevalue = (Rate*(RateThres/100))+Rate;
				float rate1 = Float.parseFloat(ratee);
				System.out.print("ratevalue-"+ratevalue);
				System.out.print("rate1-"+rate1);
				if(rate1<=ratevalue)
				{
					System.out.print("pass");
					xr.setCellData("Input", yrc1, i, Rate+"-pass");
				}else{
					System.out.print("fail");
					xr.setCellData("Input", yrc1, i, Rate+"-fail");
				}
				System.out.print("CARRIER is valid for "+yrc1);
				//xr.setCellData("Input", wat, i, "Pass");
			}else
			{
				System.out.print("CARRIER is not valid for "+yrc1);
				xr.setCellData("Input", yrc1, i, "NA");
			}
			//ABF
			String abfrate=quickQuote.CheckServicename(abf1);
			System.out.print(abfrate);
			if (!abfrate.equals("0"))
			{	
				System.out.print("abfrate"+abfrate);
				String ratee = abfrate.substring (1,abfrate.length());				
				System.out.print("ratee-"+ratee);	
				float Rate = Float.parseFloat(xr.getCellData("Input","ABF", i).trim());		
				float RateThres = Float.parseFloat(xr.getCellData("Input","ABF Threshold", i).trim());
				
				float ratevalue = (Rate*(RateThres/100))+Rate;
				float rate1 = Float.parseFloat(ratee);
				System.out.print("ratevalue-"+ratevalue);
				System.out.print("rate1-"+rate1);
				if(rate1<=ratevalue)
				{
					xr.setCellData("Input", abf1, i, Rate+"-pass");
				}else{
					System.out.print("fail");
					xr.setCellData("Input", abf1, i, Rate+"-fail");
				}
				System.out.print("CARRIER is valid for "+abf1);
				//xr.setCellData("Input", wat, i, "Pass");
			}else
			{
				System.out.print("CARRIER is not valid for "+abf1);
				xr.setCellData("Input", abf1, i, "NA");
			}
			//pilot
			String pilotrate=quickQuote.CheckServicename(pilot1);
			System.out.print(pilotrate);
			if (!pilotrate.equals("0"))
			{	
				System.out.print("rate"+pilotrate);
				String ratee = pilotrate.substring (1,pilotrate.length());				
				System.out.print("ratee-"+ratee);	
				float Rate = Float.parseFloat(xr.getCellData("Input","Pilot", i).trim());		
				float RateThres = Float.parseFloat(xr.getCellData("Input","Pilot Threshold", i).trim());
				
				float ratevalue = (Rate*(RateThres/100))+Rate;
				float rate1 = Float.parseFloat(ratee);
				System.out.print("ratevalue-"+ratevalue);
				System.out.print("rate1-"+rate1);
				if(rate1<=ratevalue)
				{
					xr.setCellData("Input", pilot1, i, Rate+"-pass");
				}else{
					System.out.print("fail");
					xr.setCellData("Input", pilot1, i, Rate+"-fail");
				}
				System.out.print("CARRIER is valid for "+pilot1);
				//xr.setCellData("Input", wat, i, "Pass");
			}else
			{
				System.out.print("CARRIER is not valid for "+pilot1);
				xr.setCellData("Input", pilot1, i, "NA");
			}
			//Wat			
			String WATrate=quickQuote.CheckServicename(wat1);
			System.out.print(WATrate);
			if (!WATrate.equals("0"))
			{	
				System.out.print("rate"+WATrate);
				String ratee = WATrate.substring (1,WATrate.length());				
				System.out.print("ratee-"+ratee);	
				float Rate = Float.parseFloat(xr.getCellData("Input","Watkins & Shepard", i).trim());		
				float RateThres = Float.parseFloat(xr.getCellData("Input","Watkins & Shepard Threshold", i).trim());
				
				float ratevalue = (Rate*(RateThres/100))+Rate;
				float rate1 = Float.parseFloat(ratee);
				System.out.print("ratevalue-"+ratevalue);
				System.out.print("rate1-"+rate1);
				if(rate1<=ratevalue)
				{
					System.out.print("pass");
					xr.setCellData("Input", wat1, i, Rate+"-pass");
				}else{
					System.out.print("fail");
					xr.setCellData("Input", wat1, i, Rate+"-fail");
				}
				System.out.print("CARRIER is valid for "+wat1);
				
			}else
			{
				System.out.print("CARRIER is not valid for "+wat1);
				xr.setCellData("Input", wat1, i, "NA");
			}
			//ait			
			String aitrate=quickQuote.CheckServicename(ait1);
			System.out.print(aitrate);
			if (!aitrate.equals("0"))
			{	
				System.out.print("rate"+aitrate);
				String ratee = aitrate.substring (1,aitrate.length());				
				System.out.print("ratee-"+ratee);	
				float Rate = Float.parseFloat(xr.getCellData("Input","AIT", i).trim());		
				float RateThres = Float.parseFloat(xr.getCellData("Input","AIT Threshold", i).trim());
				
				float ratevalue = (Rate*(RateThres/100))+Rate;
				float rate1 = Float.parseFloat(ratee);
				System.out.print("ratevalue-"+ratevalue);
				System.out.print("rate1-"+rate1);
				if(rate1<=ratevalue)
				{
					System.out.print("pass");
					xr.setCellData("Input", ait1, i, Rate+"-pass");
				}else{
					System.out.print("fail");
					xr.setCellData("Input", ait1, i, Rate+"-fail");
				}
				System.out.print("CARRIER is valid for "+ait1);
				//xr.setCellData("Input", wat, i, "Pass");
			}else
			{
				System.out.print("CARRIER is not valid for "+ait1);
				xr.setCellData("Input", ait1, i, "NA");
			}	
			//ceva			
			String cevarate=quickQuote.CheckServicename(ceva1);
			System.out.print(cevarate);
			if (!cevarate.equals("0"))
			{	
				System.out.print("rate"+cevarate);
				String ratee = cevarate.substring (1,cevarate.length());				
				System.out.print("ratee-"+ratee);	
				float Rate = Float.parseFloat(xr.getCellData("Input","Ceva", i).trim());		
				float RateThres = Float.parseFloat(xr.getCellData("Input","Ceva Threshold", i).trim());
				
				float ratevalue = (Rate*(RateThres/100))+Rate;
				float rate1 = Float.parseFloat(ratee);
				System.out.print("ratevalue-"+ratevalue);
				System.out.print("rate1-"+rate1);
				if(rate1<=ratevalue)
				{
					System.out.print("pass");
					xr.setCellData("Input", ceva1, i, Rate+"-pass");
				}else{
					System.out.print("fail");
					xr.setCellData("Input", ceva1, i, Rate+"-fail");
				}
				System.out.print("CARRIER is  valid for "+ceva1);
				//xr.setCellData("Input", wat, i, "Pass");
			}else
			{
				System.out.print("CARRIER is not valid for "+ceva1);
				xr.setCellData("Input", ceva1, i, "NA");
			}
			//del			
			
			WaitTool.sleep(5);
			String delrate=quickQuote.CheckServicename(del1);
			System.out.print(delrate);
			if (!delrate.equals("0"))
			{	
				System.out.print("rate"+delrate);
				String ratee = delrate.substring (1,delrate.length());				
				System.out.print("ratee-"+ratee);	
				float Rate = Float.parseFloat(xr.getCellData("Input","Deliveright", i).trim());		
				float RateThres = Float.parseFloat(xr.getCellData("Input","Deliveright Threshold", i).trim());
				
				float ratevalue = (Rate*(RateThres/100))+Rate;
				float rate1 = Float.parseFloat(ratee);
				System.out.print("ratevalue-"+ratevalue);
				System.out.print("rate1-"+rate1);
				if(rate1<=ratevalue)
				{
					System.out.print("pass");
					xr.setCellData("Input", del1, i, Rate+"-pass");
				}else{
					System.out.print("fail");
					xr.setCellData("Input", del1, i, Rate+"-fail");
				}
				System.out.print("CARRIER is  valid for "+del1);
				//xr.setCellData("Input", wat, i, "Pass");
			}else
			{
				System.out.print("CARRIER is not valid for "+del1);
				xr.setCellData("Input", del1, i, "NA");
			}		
			//zenith			
			
			WaitTool.sleep(5);
			String zenrate=quickQuote.CheckServicename(zen1);
			System.out.print(zenrate);
			if (!zenrate.equals("0"))
			{	
				System.out.print("rate"+zenrate);
				String ratee = zenrate.substring (1,zenrate.length());				
				System.out.print("ratee-"+ratee);	
				float Rate = Float.parseFloat(xr.getCellData("Input","Zenith", i).trim());		
				float RateThres = Float.parseFloat(xr.getCellData("Input","Zenith Threshold", i).trim());
				
				float ratevalue = (Rate*(RateThres/100))+Rate;
				float rate1 = Float.parseFloat(ratee);
				System.out.print("ratevalue-"+ratevalue);
				System.out.print("rate1-"+rate1);
				if(rate1<=ratevalue)
				{
					System.out.print("pass");
					xr.setCellData("Input", zen1, i, Rate+"-pass");
				}else{
					System.out.print("fail");
					xr.setCellData("Input", zen1, i, Rate+"-fail");
				}
				System.out.print("CARRIER is valid for "+zen1);
				//xr.setCellData("Input", wat, i, "Pass");
			}else
			{
				System.out.print("CARRIER is not valid for "+zen1);
				xr.setCellData("Input", zen1, i, "NA");
			}			
	    }	
		

		SeleniumFunction.click(quickQuote.resultCarrriesCat());
		WaitTool.sleep(2);
		SeleniumFunction.click(quickQuote.dropdownCat());
		
		//List <WebElement> carriers1= driver.findElements(By.xpath("//div[@class='selection-side-text']/h4")); 
		//List <WebElement> carriers= driver.findElements(By.xpath("//div/span[2]/small"));
		List <WebElement> carriers1= driver.findElements(By.xpath("//div[@class='col-xs-12 ratequote']")); 
		int carriercnt= carriers1.size();
		
		for(int a=1;a<=carriercnt;a++){
			System.out.print("START");
			String[] b={"ABF Freight","Estes Express Lines"};
			System.out.print("END");
			for(int p=1;p<=carriercnt;p++){
				
				System.out.print(carriers1.get(p).getText().trim());
				System.out.print(p);
				if(carriers1.get(p).getText().trim().equals(p)){
					xr.setCellData("Input", carriers1.get(p).getText(), i, "YES");
				}
			}
//			for (String c : b) {
//				System.out.print(carriers1.get(a).getText().trim());
//				System.out.print(c);
//				if(carriers1.get(a).getText().trim().equals(c)){
//					xr.setCellData("Input", c, i, "YES");
//				}
			}
			
			}
	    }
    }
	driver.close();	
	
	*/
	
}

	//TestNG test = new TestNG();
   // test.setTestClasses(new Class[] { AddContactHappyPath.class });
    //test.run();
		
	
