package automation;

import org.testng.annotations.Test;

public class TestManageProduct extends InitializeTest {
	@Test
	public void testManageProducts () throws Exception {
		driver.manage().window().maximize();
		HomePage homePage = new HomePage(driver);
		SeleniumFunction.clickJS(driver, homePage.signInLinkProd());
		SeleniumFunction.clickJS(driver, homePage.signInLink());
		
		SignInPage signInPage = new SignInPage(driver);
		QuickQuote quickQuote = new QuickQuote(driver);
		ScreenShot.takeScreenShot(driver, "Login Page");
		SeleniumFunction.sendKeys(signInPage.usernameTextField(), "24aug@mailinator.com");
		SeleniumFunction.sendKeys(signInPage.passowrdTextField(), "@Test123");		
		SeleniumFunction.clickJS(driver, signInPage.loginButton());

		
/*		quickQuote.manageProductLink();
		//ScreenShot.takeScreenShot(driver, "ManageProductsPage");
		SeleniumFunction.clickJS(driver, quickQuote.manageProductLink());
		quickQuote.uploadFileProductChrome();
		SeleniumFunction.clickAction(driver, quickQuote.uploadButton());
		quickQuote.OKButton();
		quickQuote.sucessMsgManageProducts();
		SeleniumFunction.clickJS(driver, quickQuote.OKButton());
		ScreenShot.takeScreenShot(driver, "ManageProductsUploaded");*/
	}
}
