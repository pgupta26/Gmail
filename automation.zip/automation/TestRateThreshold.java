package automation;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.TestNG;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestRateThreshold extends InitializeTest {
	@Test
	public void TestRateVerifyThresholdValue() throws Exception {

		// System.setProperty("webdriver.chrome.driver", "binaries/chromedriver.exe");
		// WebDriver driver = new ChromeDriver();

		// driver.get("http://qa.freightclub.com/");
		// Reporter.log("URL is Launched!");
		// driver.manage().window().maximize();
		// HomePage homePage = new HomePage(driver);
		// SeleniumFunction.clickJS(driver, homePage.signInLink());
		// SignInPage signInPage = new SignInPage(driver);
		QuickQuote quickQuote = new QuickQuote(driver);
		// SeleniumFunction.sendKeys(signInPage.usernameTextField(),
		// "qatest@cymax.com");
		// SeleniumFunction.sendKeys(signInPage.passowrdTextField(), "Welcome@2");
		// SeleniumFunction.clickJS(driver, signInPage.loginButton());
		// WaitTool.sleep(10);
		// RunTest

		Xls_Reader res = new Xls_Reader("binaries/Results.xlsx");
		Xls_Reader xr1 = new Xls_Reader("binaries/TestRun.xlsx");
		int rcnt1 = xr1.getRowCount("Input");
		System.out.println("rcntTESTRUN:" + rcnt1);
		for (int j = 2; j <= rcnt1; j++) {
			String File = xr1.getCellData("Input", "File", j).trim();
			String Status = xr1.getCellData("Input", "Status", j).trim();
			if (Status.equals("Y") && (File.equals("Threshold"))) {
				// Get Excel Data
				Xls_Reader xr = new Xls_Reader("binaries/" + File + ".xlsx");
				System.out.println("File:" + File);
				// Xls_Reader xr=new Xls_Reader("binaries/FCFile.xlsx");
				int rcnt = xr.getRowCount("Input");
				System.out.println("rcnt:" + rcnt);

				if (j > 2) {
					// SeleniumFunction.click(quickQuote.MenuBarLink());
					SeleniumFunction.clickJS(driver, quickQuote.manageOrdersLink());
				}
				for (int i = 2; i <= rcnt; i++) {

					// for(int j=1; j<=ccnt;j++){
					// String cellDataNew=xr.getCellData("Input",j, i).trim();
					// System.out.print(cellDataNew+"\n");

					String shipmentType = xr.getCellData("Input", "shipmentType", i).trim();
					String serviceLevel = xr.getCellData("Input", "serviceLevel", i).trim();
					String orderReferenceID = xr.getCellData("Input", "orderReferenceID", i).trim();
					String pickUpZip = xr.getCellData("Input", "pickUpZip", i).trim();
					String PickZip = pickUpZip.substring(0, 5); // return value 90001
					String pickUpType = xr.getCellData("Input", "pickUpType", i).trim();
					String dropOffZip = xr.getCellData("Input", "dropOffZip", i).trim();
					String dropOffType = xr.getCellData("Input", "dropOffType", i).trim();
					String packageType = xr.getCellData("Input", "packageType", i).trim();
					String Weight = xr.getCellData("Input", "Weight", i).trim();
					String DimensionL = xr.getCellData("Input", "DimensionL", i).trim();
					String DimensionW = xr.getCellData("Input", "DimensionW", i).trim();
					String DimensionH = xr.getCellData("Input", "DimensionH", i).trim();
					String category1 = xr.getCellData("Input", "category", i).trim();
					String DeclaredValue = xr.getCellData("Input", "DeclaredValue", i).trim();
					String Cartons = xr.getCellData("Input", "Cartons", i).trim();
					String Carriers = xr.getCellData("Input", "Carriers", i).trim();
					// Objective1
					/*
					 * String Estes = xr.getCellData("Input", 15, 1); String Seko =
					 * xr.getCellData("Input", 16, 1); String yrc = xr.getCellData("Input", 17, 1);
					 * String abf = xr.getCellData("Input", 18, 1); String pilot =
					 * xr.getCellData("Input", 19, 1); String wat = xr.getCellData("Input", 20, 1);
					 * String ait = xr.getCellData("Input", 21, 1); String ceva =
					 * xr.getCellData("Input", 22, 1); String del = xr.getCellData("Input", 23, 1);
					 * String zen = xr.getCellData("Input", 24, 1);
					 */
					// Objective2
					String Estes1 = xr.getCellData("Input", 15, 1);
					String Seko1 = xr.getCellData("Input", 17, 1);
					String yrc1 = xr.getCellData("Input", 19, 1);
					String abf1 = xr.getCellData("Input", 21, 1);
					String pilot1 = xr.getCellData("Input", 23, 1);
					String wat1 = xr.getCellData("Input", 25, 1);
					String ait1 = xr.getCellData("Input", 27, 1);
					String ceva1 = xr.getCellData("Input", 29, 1);
					String del1 = xr.getCellData("Input", 31, 1);
					//String zen1 = xr.getCellData("Input", 33, 1);

					/*
					 * String EstesThres = xr.getCellData("Input", 16, 1); String SekoThres =
					 * xr.getCellData("Input", 18, 1); String yrcThres = xr.getCellData("Input", 20,
					 * 1); String abfThres = xr.getCellData("Input", 22, 1); String pilotThres =
					 * xr.getCellData("Input", 24, 1); String watThres = xr.getCellData("Input", 26,
					 * 1); String aitThres = xr.getCellData("Input", 28, 1); String cevaThres =
					 * xr.getCellData("Input", 30, 1); String delThres = xr.getCellData("Input", 32,
					 * 1); String zenThres = xr.getCellData("Input", 34, 1);
					 */

					System.out.println(pickUpZip);
					System.out.println("i" + i);
					// click on quickquote
					if (i > 2) {
						// SeleniumFunction.click(quickQuote.MenuBarLink());
						System.out.println("quateee");
						SeleniumFunction.clickJS(driver, quickQuote.manageOrdersLink());
					}

					if (shipmentType.equalsIgnoreCase("LTL")) {
						SeleniumFunction.click(quickQuote.LTLShipment());
					} else {
						SeleniumFunction.click(quickQuote.ParcelShipment());
					}

					SeleniumFunction.click(quickQuote.OrderDate());

					int orderdte = QuickQuote.orderDate();

					String orderdate = Integer.toString(orderdte);
					WaitTool.sleep(5);
					// SeleniumFunction.click(quickQuote.ClickDate(orderdate));
					SeleniumFunction.click(quickQuote.OrderDate1());

					SeleniumFunction.sendKeys(quickQuote.OrderReferenceID(), orderReferenceID);
					SeleniumFunction.clickAction(driver, quickQuote.ServiceLevel());

					if (serviceLevel.contains("White Glove - Light Assembly")) {
						SeleniumFunction.click(quickQuote.ServiceLevelWG());
					} else if (serviceLevel.contains("Back Of Truck")) {
						SeleniumFunction.click(quickQuote.ServiceLevelBOT());
					} else if (serviceLevel.contains("Curbside")) {
						SeleniumFunction.click(quickQuote.ServiceLevelCUR());
					} else if (serviceLevel.contains("Threshold")) {
						SeleniumFunction.click(quickQuote.ServiceLevelTHR());
					} else if (serviceLevel.contains("Room of Choice")) {
						SeleniumFunction.click(quickQuote.ServiceLevelROC());
					} else if (serviceLevel.contains("White Glove - Packaging Removal")) {
						SeleniumFunction.click(quickQuote.ServiceLevelWGPR());
					}

					// SeleniumFunction.select(quickQuote.ServiceLevelOptions(), "Back Of Truck (No
					// Liftgate) - One man delivery - Customer to remove shipment from truck");

					// int zip=Integer.parseInt(pickUpZip);

					SeleniumFunction.sendKeys(quickQuote.PickUpZip(), pickUpZip.substring(0, pickUpZip.length() - 2));
					SeleniumFunction.sendKeys(quickQuote.DropOffZip(),
							dropOffZip.substring(0, dropOffZip.length() - 2));

					if (pickUpType == "Commercial") {
						SeleniumFunction.click(quickQuote.PickUpZipLocationTypeCom());
					} else {
						SeleniumFunction.click(quickQuote.PickUpZipLocationTypeRes());
					}

					if (dropOffType == "Commercial") {
						SeleniumFunction.click(quickQuote.DropOffZipLocationTypeCom());
					} else {
						SeleniumFunction.click(quickQuote.DropOffZipLocationTypeRes());

					}

					if (category1.equalsIgnoreCase("Other")) {
						SeleniumFunction.selectByvalue(quickQuote.Category(), "347");
					} else {
						SeleniumFunction.selectByvalue(quickQuote.Category(), "346");
					}

					SeleniumFunction.click(quickQuote.PackageType());

					WaitTool.sleep(5);
					quickQuote.PackageTypeOptions(packageType);
					System.out.println("package selected");
					SeleniumFunction.click(quickQuote.Weight());
					System.out.println("Weight" + Weight);
					SeleniumFunction.sendKeys(quickQuote.Weight(), Weight);
					SeleniumFunction.sendKeys(quickQuote.DimensionL(), DimensionL);

					SeleniumFunction.sendKeys(quickQuote.DimensionW(), DimensionW);

					SeleniumFunction.sendKeys(quickQuote.DimensionH(), DimensionH);
					SeleniumFunction.sendKeys(quickQuote.DeclaredValue(), DeclaredValue);
					if (!packageType.equals("My Own Package")) {
						SeleniumFunction.sendKeys(quickQuote.Cartons(), Cartons);
					}

					WaitTool.sleep(5);
					// ScreenShot.takeScreenShot(driver, "Data-Provided"+i);
					JavascriptExecutor jse = (JavascriptExecutor) driver;
					jse.executeScript("window.scrollBy(0,250)", "");
					ScreenShot.takeScreenShot(driver, "Shipment info");
					SeleniumFunction.click(quickQuote.SaveButton());
					WaitTool.sleep(20);
					/*
					 * ScreenShot.takeScreenShot(driver, "Carriers"); String carrier =
					 * Carriers.split("\\.")[0]; quickQuote.ValidateCarriers(carrier);
					 */
					jse.executeScript("window.scrollBy(2500,0)", "");
					jse.executeScript("scroll(2500, 0);");
					ScreenShot.takeScreenShot(driver, "Quick quote page");
					// Run Objective1
					if (File.equals("FCFile")) {
						/*
						 * // Estes System.out.print("estes pickUpZip-" + PickZip); if
						 * (PickZip.contains("35004") || PickZip.contains("23233")) {
						 * SeleniumFunction.click(quickQuote.resultCarrriesLevel()); WaitTool.sleep(5);
						 * SeleniumFunction.click(quickQuote.dropdownCarrierEST()); WaitTool.sleep(5);
						 * String Estesname = quickQuote.Checkcarriername(Estes);
						 * 
						 * if (Estesname.equals("1")) { xr.setCellData("Input", Estes, i, "Pass"); }
						 * else { xr.setCellData("Input", Estes, i, "Fail"); } } //
						 * xr.setCellData("Input", "WhiteGlove", i, cnt1); // Seko
						 * driver.navigate().refresh(); WaitTool.sleep(5);
						 * SeleniumFunction.click(quickQuote.resultCarrriesLevel()); WaitTool.sleep(5);
						 * SeleniumFunction.click(quickQuote.dropdownCarrierSEKO()); WaitTool.sleep(5);
						 * String SEKOName = quickQuote.Checkcarriername(Seko);
						 * 
						 * if (SEKOName.equals("1")) { xr.setCellData("Input", Seko, i, "Pass"); } else
						 * { xr.setCellData("Input", Seko, i, "Fail"); } // yrc
						 * driver.navigate().refresh(); WaitTool.sleep(5);
						 * SeleniumFunction.click(quickQuote.resultCarrriesLevel()); WaitTool.sleep(5);
						 * SeleniumFunction.click(quickQuote.dropdownCarrierYRC()); WaitTool.sleep(5);
						 * String yrcName = quickQuote.Checkcarriername(yrc);
						 * 
						 * if (yrcName.equals("1")) { xr.setCellData("Input", yrc, i, "Pass"); } else {
						 * xr.setCellData("Input", yrc, i, "Fail"); } // ABF
						 * driver.navigate().refresh(); WaitTool.sleep(5);
						 * SeleniumFunction.click(quickQuote.resultCarrriesLevel()); WaitTool.sleep(5);
						 * SeleniumFunction.click(quickQuote.dropdownCarrierABF()); WaitTool.sleep(5);
						 * String ABFName = quickQuote.Checkcarriername(abf);
						 * 
						 * if (ABFName.equals("1")) { xr.setCellData("Input", abf, i, "Pass"); } else {
						 * xr.setCellData("Input", abf, i, "Fail"); } // pil
						 * driver.navigate().refresh(); WaitTool.sleep(5);
						 * SeleniumFunction.click(quickQuote.resultCarrriesLevel()); WaitTool.sleep(5);
						 * SeleniumFunction.click(quickQuote.dropdownCarrierPIL()); WaitTool.sleep(5);
						 * String pilotName = quickQuote.Checkcarriername(pilot);
						 * 
						 * if (pilotName.equals("1")) { xr.setCellData("Input", pilot, i, "Pass"); }
						 * else { xr.setCellData("Input", pilot, i, "Fail"); } // AIT
						 * driver.navigate().refresh(); WaitTool.sleep(5);
						 * SeleniumFunction.click(quickQuote.resultCarrriesLevel()); WaitTool.sleep(5);
						 * SeleniumFunction.click(quickQuote.dropdownCarrierAIT()); WaitTool.sleep(5);
						 * String aitName = quickQuote.Checkcarriername(ait);
						 * 
						 * if (aitName.equals("1")) { xr.setCellData("Input", ait, i, "Pass"); } else {
						 * xr.setCellData("Input", ait, i, "Fail"); } // ceva
						 * driver.navigate().refresh(); WaitTool.sleep(5);
						 * SeleniumFunction.click(quickQuote.resultCarrriesLevel()); WaitTool.sleep(5);
						 * SeleniumFunction.click(quickQuote.dropdownCarrierCEVA()); WaitTool.sleep(5);
						 * String cevaName = quickQuote.Checkcarriername(ceva);
						 * 
						 * if (cevaName.equals("1")) { xr.setCellData("Input", ceva, i, "Pass"); } else
						 * { xr.setCellData("Input", ceva, i, "Fail"); } // DEL
						 * driver.navigate().refresh(); WaitTool.sleep(5);
						 * SeleniumFunction.click(quickQuote.resultCarrriesLevel()); WaitTool.sleep(5);
						 * SeleniumFunction.click(quickQuote.dropdownCarrierDEL()); WaitTool.sleep(5);
						 * String delName = quickQuote.Checkcarriername(del);
						 * 
						 * if (delName.equals("1")) { xr.setCellData("Input", del, i, "Pass"); } else {
						 * xr.setCellData("Input", del, i, "Fail"); } // Zenith
						 * System.out.print("pickUpZip-" + PickZip); if (PickZip.contains("90001") ||
						 * PickZip.contains("23233")) { driver.navigate().refresh(); WaitTool.sleep(5);
						 * SeleniumFunction.click(quickQuote.resultCarrriesLevel()); WaitTool.sleep(5);
						 * SeleniumFunction.click(quickQuote.dropdownCarrierZen()); WaitTool.sleep(5);
						 * String zenname = quickQuote.Checkcarriername(zen);
						 * 
						 * if (zenname.equals("1")) { xr.setCellData("Input", zen, i, "Pass"); } else {
						 * xr.setCellData("Input", zen, i, "Fail"); } } // Wet
						 * System.out.print("packageType-" + packageType); if
						 * (packageType.contains("My Own Package")) { driver.navigate().refresh();
						 * WaitTool.sleep(5); SeleniumFunction.click(quickQuote.resultCarrriesLevel());
						 * WaitTool.sleep(5); SeleniumFunction.click(quickQuote.dropdownCarrierWAT());
						 * WaitTool.sleep(5); String watname = quickQuote.Checkcarriername(wat);
						 * 
						 * if (watname.equals("1")) { xr.setCellData("Input", wat, i, "Pass"); } else {
						 * xr.setCellData("Input", wat, i, "Fail"); } }
						 */}
					// Run Objective2
					if (File.equals("Threshold")) {

						SeleniumFunction.click(quickQuote.resultCarrriesCat());
						WaitTool.sleep(2);
						if (serviceLevel.equals("White Glove - Packaging Removal")) {
							SeleniumFunction.click(quickQuote.dropdownCatWHG());
							WaitTool.sleep(2);
						} else if (serviceLevel.equals("White Glove - Light Assembly")) {
							SeleniumFunction.click(quickQuote.dropdownCatWHGLight());
							WaitTool.sleep(2);
						}
						SeleniumFunction.click(quickQuote.PullDown());
						WaitTool.sleep(2);
						jse.executeScript("window.scrollBy(0,250)", "");
						// Estes
						String Estesrate = quickQuote.CheckServicename(Estes1,File);
						System.out.print(Estesrate);
						if (!Estesrate.equals("0")) {
							System.out.print("Estesrate" + Estesrate);
							String ratee = Estesrate;
							//String ratee = Estesrate.substring(1, Estesrate.length());
							System.out.print("ratee-" + ratee);
							float Rate = Float.parseFloat(xr.getCellData("Input", "Estes", i).trim());
							float RateThres = Float.parseFloat(xr.getCellData("Input", "Estes Threshold", i).trim());
							ratee = ratee.replaceAll("[^\\d.]", "");//remove any special charater(,) like 1,000 
							float ratevalue = (Rate * (RateThres / 100)) + Rate;
							float rate1 = Float.parseFloat(ratee);
							System.out.print("ratevalue-" + ratevalue);
							System.out.print("rate1-" + rate1);
							if (rate1 <= ratevalue) {
								System.out.print("pass");
								// xr.setCellData("Input", Estes1, i, Rate + "-Pass");
								res.setCellData("Threshold", Estes1, i, "Rates are within Threshold");

							} else {
								System.out.print("fail");
								// xr.setCellData("Input", Estes1, i, Rate + "-fail");
								res.setCellData("Threshold", Estes1, i, "Rates are higher");
								res.ColorColumn("Threshold", Estes1, i);
							}
							System.out.print("CARRIER is valid for " + Estes1);

						} else {
							System.out.print("CARRIER is not valid for " + Estes1);
							res.setCellData("Threshold", Estes1, i, "NA");
							// xr.setCellData("Input", wat, i, "Fail");
						}

						// xr.setCellData("Input", "WhiteGlove", i, cnt1);
						// Seko
						String Sekorate = quickQuote.CheckServicename(Seko1,File);
						System.out.print(Sekorate);
						if (!Sekorate.equals("0")) {
							System.out.print("Sekorate" + Sekorate);
							String ratee = Sekorate;
							//String ratee = Sekorate.substring(1, Sekorate.length());
							System.out.print("ratee-" + ratee);
							float Rate = Float.parseFloat(xr.getCellData("Input", "Seko", i).trim());
							float RateThres = Float.parseFloat(xr.getCellData("Input", "Seko Threshold", i).trim());
							ratee = ratee.replaceAll("[^\\d.]", "");//remove any special charater(,) like 1,000 
							float ratevalue = (Rate * (RateThres / 100)) + Rate;
							float rate1 = Float.parseFloat(ratee);
							System.out.print("ratevalue-" + ratevalue);
							System.out.print("rate1-" + rate1);
							if (rate1 <= ratevalue) {
								System.out.print("pass");
								// xr.setCellData("Input", Seko1, i, Rate + "-pass");
								res.setCellData("Threshold", Seko1, i, "Rates are within Threshold");
							} else {
								System.out.print("fail");
								// xr.setCellData("Input", Seko1, i, Rate + "-fail");

								res.setCellData("Threshold", Seko1, i, "Rates are higher");
								res.ColorColumn("Threshold", Seko1, i);
							}
							System.out.print("CARRIER is  valid for " + Seko1);
							// xr.setCellData("Input", wat, i, "Pass");
						} else {
							System.out.print("CARRIER is not valid for " + Seko1);
							res.setCellData("Threshold", Seko1, i, "NA");
						}

						// yrc
						String yrcrate = quickQuote.CheckServicename(yrc1,File);
						System.out.print(yrcrate);
						if (!yrcrate.equals("0")) {
							System.out.print("yrcrate" + yrcrate);
							String ratee = yrcrate;
							//String ratee = yrcrate.substring(1, yrcrate.length());
							System.out.print("ratee-" + ratee);
							float Rate = Float.parseFloat(xr.getCellData("Input", "YRC", i).trim());
							float RateThres = Float.parseFloat(xr.getCellData("Input", "YRC Threshold", i).trim());
							ratee = ratee.replaceAll("[^\\d.]", "");//remove any special charater(,) like 1,000 
							float ratevalue = (Rate * (RateThres / 100)) + Rate;
							float rate1 = Float.parseFloat(ratee);
							System.out.print("ratevalue-" + ratevalue);
							System.out.print("rate1-" + rate1);
							if (rate1 <= ratevalue) {
								System.out.print("pass");
								res.setCellData("Threshold", yrc1, i, "Rates are within Threshold");
							} else {
								System.out.print("fail");
								res.setCellData("Threshold", yrc1, i, "Rates are higher");
								res.ColorColumn("Threshold", yrc1, i);
							}
							System.out.print("CARRIER is valid for " + yrc1);
						} else {
							System.out.print("CARRIER is not valid for " + yrc1);
							res.setCellData("Threshold", yrc1, i, "NA");
						}

						// ABF
						String abfrate = quickQuote.CheckServicename(abf1,File);
						System.out.print(abfrate);
						if (!abfrate.equals("0")) {
							System.out.print("abfrate" + abfrate);
							String ratee = abfrate;
							//String ratee = abfrate.substring(1, abfrate.length());
							System.out.print("ratee-" + ratee);
							float Rate = Float.parseFloat(xr.getCellData("Input", "ABF", i).trim());
							float RateThres = Float.parseFloat(xr.getCellData("Input", "ABF Threshold", i).trim());
							System.out.print("rATEEXCEL-" + Rate);
							System.out.print("RateThresEXCEL-" + RateThres);
							
							float ratevalue = (Rate * (RateThres / 100)) + Rate;
							System.out.print("ratevalue-" + ratevalue);	
							ratee = ratee.replaceAll("[^\\d.]", "");//remove any special charater(,) like 1,000 
							float rate1 = Float.parseFloat(ratee);
							/*int rate1 = Integer.parseInt(ratee);*/
							System.out.print("rate1-" + rate1);
							
							if (rate1 <= ratevalue) {
								res.setCellData("Threshold", abf1, i, "Rates are within Threshold");
							} else {
								System.out.print("fail");
								res.setCellData("Threshold", abf1, i, "Rates are higher");
								res.ColorColumn("Threshold", abf1, i);
							}
							System.out.print("CARRIER is valid for " + abf1);
						} else {
							System.out.print("CARRIER is not valid for " + abf1);
							res.setCellData("Threshold", abf1, i, "NA");
						}

						// pilot
						String pilotrate = quickQuote.CheckServicename(pilot1,File);
						System.out.print(pilotrate);
						if (!pilotrate.equals("0")) {
							System.out.print("rate" + pilotrate);
							String ratee = pilotrate;
							//String ratee = pilotrate.substring(1, pilotrate.length());
							System.out.print("ratee-" + ratee);
							float Rate = Float.parseFloat(xr.getCellData("Input", "Pilot", i).trim());
							float RateThres = Float.parseFloat(xr.getCellData("Input", "Pilot Threshold", i).trim());

							float ratevalue = (Rate * (RateThres / 100)) + Rate;
							ratee = ratee.replaceAll("[^\\d.]", "");//remove any special charater(,) like 1,000 
							float rate1 = Float.parseFloat(ratee);
							System.out.print("ratevalue-" + ratevalue);
							System.out.print("rate1-" + rate1);
							if (rate1 <= ratevalue) {
								res.setCellData("Threshold", pilot1, i, "Rates are within Threshold");
							} else {
								System.out.print("fail");
								res.setCellData("Threshold", pilot1, i, "Rates are higher");
								res.ColorColumn("Threshold", pilot1, i);
							}
							System.out.print("CARRIER is valid for " + pilot1);
							// xr.setCellData("Input", wat, i, "Pass");
						} else {
							System.out.print("CARRIER is not valid for " + pilot1);
							res.setCellData("Threshold", pilot1, i, "NA");
						}

						// Wat
						String WATrate = quickQuote.CheckServicename(wat1,File);
						System.out.print(WATrate);
						if (!WATrate.equals("0")) {
							System.out.print("rate" + WATrate);
							String ratee = WATrate;
							//String ratee = WATrate.substring(1, WATrate.length());
							System.out.print("ratee-" + ratee);
							float Rate = Float.parseFloat(xr.getCellData("Input", "Watkins & Shepard", i).trim());
							float RateThres = Float
									.parseFloat(xr.getCellData("Input", "Watkins & Shepard Threshold", i).trim());

							float ratevalue = (Rate * (RateThres / 100)) + Rate;
							float rate1 = Float.parseFloat(ratee);
							System.out.print("ratevalue-" + ratevalue);
							System.out.print("rate1-" + rate1);
							if (rate1 <= ratevalue) {
								System.out.print("pass");
								res.setCellData("Threshold", wat1, i, "Rates are within Threshold");
							} else {
								System.out.print("fail");
								res.setCellData("Threshold", wat1, i, "Rates are higher");
								res.ColorColumn("Threshold", wat1, i);
							}
							System.out.print("CARRIER is valid for " + wat1);

						} else {
							System.out.print("CARRIER is not valid for " + wat1);
							res.setCellData("Threshold", wat1, i, "NA");
						}

						// ait
						String aitrate = quickQuote.CheckServicename(ait1,File);
						System.out.print(aitrate);
						if (!aitrate.equals("0")) {
							System.out.print("rate" + aitrate);
							String ratee = aitrate;
							//String ratee = aitrate.substring(1, aitrate.length());
							System.out.print("ratee-" + ratee);
							float Rate = Float.parseFloat(xr.getCellData("Input", "AIT", i).trim());
							float RateThres = Float.parseFloat(xr.getCellData("Input", "AIT Threshold", i).trim());
							ratee = ratee.replaceAll("[^\\d.]", "");//remove any special charater(,) like 1,000 
							float ratevalue = (Rate * (RateThres / 100)) + Rate;
							float rate1 = Float.parseFloat(ratee);
							System.out.print("ratevalue-" + ratevalue);
							System.out.print("rate1-" + rate1);
							if (rate1 <= ratevalue) {
								System.out.print("pass");
								res.setCellData("Threshold", ait1, i, "Rates are within Threshold");
							} else {
								System.out.print("fail");
								res.setCellData("Threshold", ait1, i, "Rates are higher");
								res.ColorColumn("Threshold", ait1, i);
							}
							System.out.print("CARRIER is valid for " + ait1);
							// xr.setCellData("Input", wat, i, "Pass");
						} else {
							System.out.print("CARRIER is not valid for " + ait1);
							res.setCellData("Threshold", ait1, i, "NA");
						}

						// ceva
						String cevarate = quickQuote.CheckServicename(ceva1,File);
						System.out.print(cevarate);
						if (!cevarate.equals("0")) {
							System.out.print("rate" + cevarate);
							String ratee = cevarate;
							//String ratee = cevarate.substring(1, cevarate.length());
							System.out.print("ratee-" + ratee);
							float Rate = Float.parseFloat(xr.getCellData("Input", "Ceva", i).trim());
							float RateThres = Float.parseFloat(xr.getCellData("Input", "Ceva Threshold", i).trim());
							ratee = ratee.replaceAll("[^\\d.]", "");//remove any special charater(,) like 1,000 
							float ratevalue = (Rate * (RateThres / 100)) + Rate;
							float rate1 = Float.parseFloat(ratee);
							System.out.print("ratevalue-" + ratevalue);
							System.out.print("rate1-" + rate1);
							if (rate1 <= ratevalue) {
								System.out.print("pass");
								res.setCellData("Threshold", ceva1, i, "Rates are within Threshold");
							} else {
								System.out.print("fail");
								res.setCellData("Threshold", ceva1, i, "Rates are higher");
								res.ColorColumn("Threshold", ceva1, i);
							}
							System.out.print("CARRIER is  valid for " + ceva1);
							// xr.setCellData("Input", wat, i, "Pass");
						} else {
							System.out.print("CARRIER is not valid for " + ceva1);
							res.setCellData("Threshold", ceva1, i, "NA");
						}

						// del

						WaitTool.sleep(5);
						String delrate = quickQuote.CheckServicename(del1,File);
						System.out.print(delrate);
						if (!delrate.equals("0")) {
							System.out.print("rate" + delrate);
							String ratee = delrate;
							//String ratee = delrate.substring(1, delrate.length());
							System.out.print("ratee-" + ratee);
							float Rate = Float.parseFloat(xr.getCellData("Input", "Deliveright", i).trim());
							float RateThres = Float
									.parseFloat(xr.getCellData("Input", "Deliveright Threshold", i).trim());
							ratee = ratee.replaceAll("[^\\d.]", "");//remove any special charater(,) like 1,000 
							float ratevalue = (Rate * (RateThres / 100)) + Rate;
							float rate1 = Float.parseFloat(ratee);
							System.out.print("ratevalue-" + ratevalue);
							System.out.print("rate1-" + rate1);
							if (rate1 <= ratevalue) {
								System.out.print("pass");
								res.setCellData("Threshold", del1, i, "Rates are within Threshold");
							} else {
								System.out.print("fail");
								res.setCellData("Threshold", del1, i, "Rates are higher");
								res.ColorColumn("Threshold", del1, i);
							}
							System.out.print("CARRIER is  valid for " + del1);
							// xr.setCellData("Input", wat, i, "Pass");
						} else {
							System.out.print("CARRIER is not valid for " + del1);
							res.setCellData("Threshold", del1, i, "NA");
						}

						// zenith

/*						WaitTool.sleep(5);
						String zenrate = quickQuote.CheckServicename(zen1);
						System.out.print(zenrate);
						if (!zenrate.equals("0")) {
							System.out.print("rate" + zenrate);
							String ratee = zenrate.substring(1, zenrate.length());
							System.out.print("ratee-" + ratee);
							float Rate = Float.parseFloat(xr.getCellData("Input", "Zenith", i).trim());
							float RateThres = Float.parseFloat(xr.getCellData("Input", "Zenith Threshold", i).trim());
                            ratee = ratee.replaceAll("[^\\d.]", "");//remove any special charater(,) like 1,000 
							float ratevalue = (Rate * (RateThres / 100)) + Rate;
							float rate1 = Float.parseFloat(ratee);
							System.out.print("ratevalue-" + ratevalue);
							System.out.print("rate1-" + rate1);
							if (rate1 <= ratevalue) {
								System.out.print("pass");
								res.setCellData("Threshold", zen1, i, "Rates are within Threshold");
							} else {
								System.out.print("fail");
								res.setCellData("Threshold", zen1, i, "Rates are higher");
								res.ColorColumn("Threshold", zen1, i);
							}
							System.out.print("CARRIER is valid for " + zen1);
							// xr.setCellData("Input", wat, i, "Pass");
						} else {
							System.out.print("CARRIER is not valid for " + zen1);
							res.setCellData("Threshold", zen1, i, "NA");
						}*/
						ScreenShot.takeScreenShot(driver, "Carriers");
					}

				}
			}
		}
		driver.close();

	}
}
