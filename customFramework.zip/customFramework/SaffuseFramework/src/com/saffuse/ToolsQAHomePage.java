package com.saffuse;

public class ToolsQAHomePage {
	
	SaffuseFrameworkAPI oASelFW ;
	
	public ToolsQAHomePage(SaffuseFrameworkAPI oASelFW){
		this.oASelFW=oASelFW;
	}
	
	public void clickNavigationLinks(String linkName) throws InterruptedException{
		oASelFW.method("click","link="+linkName,linkName);
	}
	
	public void assertTitle(String expectedTitle) throws InterruptedException{
		oASelFW.method("assertTitle",expectedTitle);
	}
	
	public void assertElement(String linkName){
		oASelFW.method("assertElementPresent","link="+linkName);
	}
	
	public void assertElement1(String linkName){
		oASelFW.method("assertElementPresent","link="+linkName,"");
	}
	
	public void assertText(){
		oASelFW.method("assertText","","");
	}
}
