package com.qualitesoft.freightclub.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.qualitesoft.core.Log;
import com.qualitesoft.core.SeleniumFunction;
import com.qualitesoft.core.WaitTool;

public class ProfileManagementPage {
	
	WebDriver driver;

	public ProfileManagementPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public WebElement manageProfileLink() {

		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//a[@href='/Admin/Index']"), 30);
	}
	
	public WebElement companyNameLink() {

		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//h5[contains(.,'Brand ID: 10011')]"), 30);
	}
	public WebElement profileListfilter() {

		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//input[@placeholder='Filter profiles']"), 30);
	}	
	public WebElement paymentTermTextbox() {

		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//input[@id='InvoicingCycleDays']"), 30);
	}
	
	public WebElement lockoutCheckbox() {

		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//input[@id='LockOutEnabled']"), 30);
	}
	
	public WebElement saveProfileButton() {

		//return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//input[@type='submit']"), 30);
		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//button[@class='btn btn-primary pull-right']"), 30);
	}
	
	public WebElement quickQuoteBookOrderError() {

		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath(".//*[@class='pull-right text-danger']/strong"), 30);
	}
	public WebElement paymentType() {

		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//div[@class='col-xs-12 col-lg-9']/div[8]/div[@class='col-xs-12 col-lg-6']//select[@class='form-control']"), 30);
	}
	public WebElement selectParcel() {

		return WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//*[@id=\"profileManagement\"]/div[2]/div/div/div/div[2]/div[19]/div/div[3]/input[2]"), 30);
	}	
	 public void paymentTypeOptions(String packageType) {

			try {
			if(packageType.equalsIgnoreCase("CreditCard")){
				SeleniumFunction.click(driver.findElement
						(By.xpath("//div[@class='col-xs-12 col-lg-9']/div[8]/div[@class='col-xs-12 col-lg-6']//select[@class='form-control']/option[@value='96']")));
			}
			else if(packageType.equalsIgnoreCase("OnAccount")){
				SeleniumFunction.click(driver.findElement
						(By.xpath("//div[@class='col-xs-12 col-lg-9']/div[8]/div[@class='col-xs-12 col-lg-6']//select[@class='form-control']/option[@value='95']")));
			}				
			}
			
			catch (Exception e) {
				Log.error("Not able to select package: " + e.getMessage());
				try {
					throw e;
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}	
	public void quickQuoteBookOrderValidation() {

		quickQuoteBookOrderError();
		if (quickQuoteBookOrderError() != null) {
			if (driver.findElement(By.xpath(".//*[@class='pull-right text-danger']/strong"))
					.getText() != "duplicate") {
				Log.error(driver.findElement(By.xpath(".//*[@class='pull-right text-danger']/strong")).getText());				
			}
		}
	}	

}
