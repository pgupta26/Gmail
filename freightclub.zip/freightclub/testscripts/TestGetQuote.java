package com.qualitesoft.freightclub.testscripts;
import com.qualitesoft.core.Xls_Reader;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Test;
import com.qualitesoft.freightclub.pageobjects.QuickQuote;
import com.qualitesoft.core.InitializeTest;
import com.qualitesoft.core.JavaFunction;
import com.qualitesoft.core.ScreenShot;
import com.qualitesoft.core.SeleniumFunction;
import com.qualitesoft.core.WaitTool;


public class TestGetQuote extends InitializeTest{ 
	@Test
	public void testGetQuote() {
		System.out.println("start:");
		//WebDriver driver=new ChromeDriver();
		//HomePage homePage = new HomePage(driver);
		//SeleniumFunction.clickJS(driver, homePage.signInLink());
		//SignInPage signInPage = new SignInPage(driver);
		
		//SeleniumFunction.sendKeys(signInPage.usernameTextField(), "qatest@cymax.com");
		//SeleniumFunction.sendKeys(signInPage.passowrdTextField(), "Welcome@2");
		//SeleniumFunction.clickJS(driver, signInPage.loginButton());
		
	     //Xls_Reader xr=new Xls_Reader("E:\\qs_automation\\binaries\\FCfiles\\FCFile.xlsx");

		Xls_Reader xr=new Xls_Reader("binaries/FCfiles/FCFile.xlsx");
		 System.out.println("xr:" + xr);
		int rcnt=xr.getRowCount("Input");
		System.out.println("rcntTESTRUN:" + rcnt);
		for(int i=2;i<=rcnt;i++)
		{
			String shipmentType=xr.getCellData("Input","shipmentType", i).trim();
			String serviceLevel=xr.getCellData("Input","serviceLevel", i).trim();
			String orderReferenceID=xr.getCellData("Input","orderReferenceID", i).trim();
			String pickUpZip=xr.getCellData("Input","pickUpZip", i).trim();
			String pickUpType=xr.getCellData("Input","pickUpType", i).trim();
			String dropOffZip=xr.getCellData("Input","dropOffZip", i).trim();
			String dropOffType=xr.getCellData("Input","dropOffType", i).trim();			
			String packageType = xr.getCellData("Input", "packageType", i).trim();
			String Weight=xr.getCellData("Input","Weight", i).trim();
			String DimensionL=xr.getCellData("Input","DimensionL", i).trim();
			String DimensionW=xr.getCellData("Input","DimensionW", i).trim();
			String DimensionH=xr.getCellData("Input","DimensionH", i).trim();
			String category1=xr.getCellData("Input","category", i).trim();			
			String DeclaredValue=xr.getCellData("Input","DeclaredValue", i).trim();
			String Cartons=xr.getCellData("Input","Cartons", i).trim();
				
			QuickQuote quickQuote = new QuickQuote(driver);
			//if(i>2)
			//{
				SeleniumFunction.clickJS(driver, quickQuote.manageOrdersLink());	
			//}
			
			
			if (shipmentType.equalsIgnoreCase("LTL"))
			{
			//SeleniumFunction.click(quickQuote.LTLShipment());
			}
			else{
			SeleniumFunction.click(quickQuote.ParcelShipment());
			}
			

			SeleniumFunction.click(quickQuote.OrderDate());


			WaitTool.sleep(5);
			// SeleniumFunction.click(quickQuote.ClickDate(orderdate));
			SeleniumFunction.click(quickQuote.OrderDate1());
			
			SeleniumFunction.sendKeys(quickQuote.OrderReferenceID(), orderReferenceID);
			
			SeleniumFunction.clickAction(driver, quickQuote.ServiceLevel());
			if(!shipmentType.equals("Parcel"))
			{					
				if (serviceLevel.contains("White Glove - Light Assembly")) {
					SeleniumFunction.click(quickQuote.ServiceLevelWG());
				} else if (serviceLevel.contains("Back Of Truck")) {
					SeleniumFunction.click(quickQuote.ServiceLevelBOT());
				} else if (serviceLevel.contains("Curbside")) {
					SeleniumFunction.click(quickQuote.ServiceLevelCUR());
				} else if (serviceLevel.contains("Threshold")) {
					SeleniumFunction.click(quickQuote.ServiceLevelTHR());
				} else if (serviceLevel.contains("Room of Choice")) {
					SeleniumFunction.click(quickQuote.ServiceLevelROC());
				} else if (serviceLevel.contains("White Glove - Packaging Removal")) {
					SeleniumFunction.click(quickQuote.ServiceLevelWGPR());
				}
				
			}else {
				SeleniumFunction.click(quickQuote.ServiceLevelGRND());
			}

	      //SeleniumFunction.select(quickQuote.ServiceLevelOptions(), "Back Of Truck (No Liftgate) - One man delivery - Customer to remove shipment from truck");
	        		
			
			SeleniumFunction.sendKeys(quickQuote.PickUpZip(), pickUpZip.substring(0, pickUpZip.length() - 2));
			SeleniumFunction.sendKeys(quickQuote.DropOffZip(),
					dropOffZip.substring(0, dropOffZip.length() - 2));
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("window.scrollBy(0,250)", "");
          System.out.println("pickUpType-"+pickUpType);
			if (pickUpType.equalsIgnoreCase("Commercial")){
				SeleniumFunction.click(quickQuote.PickUpZipLocationTypeCom());
			} else {
				SeleniumFunction.click(quickQuote.PickUpZipLocationTypeRes());
			}
			System.out.println("dropOffType-"+dropOffType);
			if (dropOffType.equalsIgnoreCase("Commercial")) {
				SeleniumFunction.click(quickQuote.DropOffZipLocationTypeCom());
			} else {
				SeleniumFunction.click(quickQuote.DropOffZipLocationTypeRes());

			}
			
			if(category1.equalsIgnoreCase("Other"))
			{
			SeleniumFunction.selectByvalue(quickQuote.Category(), "347");
			}
			else
			{
				SeleniumFunction.selectByvalue(quickQuote.Category(), "346");
			}
			WaitTool.sleep(2);
			//Add popup on cateory 
			SeleniumFunction.click(quickQuote.popupCateogory());
			WaitTool.sleep(2);
			jse.executeScript("window.scrollBy(0,350)", "");
			
          	if (shipmentType.equalsIgnoreCase("LTL"))
				{
	           SeleniumFunction.click(quickQuote.PackageType());			
				}
				else{
				SeleniumFunction.click(quickQuote.PackageTypeParcel());

				}
        	WaitTool.sleep(5);
			System.out.println("package selected: "+packageType);
			quickQuote.PackageTypeOptions(packageType);
			System.out.println("package selected"+packageType);
			SeleniumFunction.click(quickQuote.Weight());
			System.out.println("Weight" + Weight);
			SeleniumFunction.sendKeys(quickQuote.Weight(), Weight);
			SeleniumFunction.sendKeys(quickQuote.DimensionL(), DimensionL);

			SeleniumFunction.sendKeys(quickQuote.DimensionW(), DimensionW);

			SeleniumFunction.sendKeys(quickQuote.DimensionH(), DimensionH);
			SeleniumFunction.sendKeys(quickQuote.DeclaredValue(), DeclaredValue);
/*			if (!packageType.equals("My Own Package")) {
				SeleniumFunction.sendKeys(quickQuote.Cartons(), Cartons);
			}*/
			if (shipmentType.equals("Parcel")) {
				//SeleniumFunction.sendKeys(quickQuote.Cartons(), Cartons);
			} else if(packageType.equals("Boxed")) {
				//SeleniumFunction.sendKeys(quickQuote.Cartons(), Cartons);
			}else 
			{
				SeleniumFunction.sendKeys(quickQuote.Cartons(), Cartons);
			}
			
			/*SeleniumFunction.click(quickQuote.Accessorials());
			SeleniumFunction.click(quickQuote.selectAccessorials());*/
			WaitTool.sleep(7);
			// ScreenShot.takeScreenShot(driver, "Data-Provided"+i);
			//JavascriptExecutor jse = (JavascriptExecutor) driver;
			ScreenShot.takeScreenShot(driver, "Shipmentinfo "+shipmentType+" "+packageType);
			jse.executeScript("window.scrollBy(0,250)", "");
			SeleniumFunction.click(quickQuote.SaveButton());
			WaitTool.sleep(10);
			jse.executeScript("window.scrollBy(0,-250)", "");
			//quickQuote.ValidateCarriers("9");
			
			
			//select carrier
			jse.executeScript("window.scrollBy(0,250)", "");
			WaitTool.sleep(20);
			//SeleniumFunction.click(quickQuote.SelectCarrierCheckBox());
			ScreenShot.takeScreenShot(driver, "Rates wih Carriers "+shipmentType+" "+packageType);
			WaitTool.sleep(5);
			SeleniumFunction.click(quickQuote.NextButton());
			WaitTool.sleep(10);
			
			
			//Fill shipment info
			if (shipmentType.equals("Parcel")) {
				SeleniumFunction.sendKeys(quickQuote.PalletDescParcel(), "TestPalletDesc");
			}else {
				SeleniumFunction.sendKeys(quickQuote.PalletDesc(), "TestPalletDesc");
			}
			jse.executeScript("window.scrollBy(0,-350)", "");
			WaitTool.sleep(3);
			//SeleniumFunction.sendKeys(quickQuote.PalletDesc(), "TestPalletDesc");
			SeleniumFunction.sendKeys(quickQuote.SpecialHandling(), "TestSpecialHandling");
			jse.executeScript("window.scrollBy(0,250)", "");
			//SeleniumFunction.sendKeys(quickQuote.LocationName(), "TestUser");
			SeleniumFunction.sendKeys(quickQuote.LocationName(), JavaFunction.randomText("Username ",5));
			SeleniumFunction.sendKeys(quickQuote.Address1(), "Address1");
			SeleniumFunction.sendKeys(quickQuote.Address2(), "Address2");
			jse.executeScript("window.scrollBy(0,250)", "");
			SeleniumFunction.sendKeys(quickQuote.FirstName(), "UserFirstName");
			SeleniumFunction.sendKeys(quickQuote.LastName(), "UserLastName");
			SeleniumFunction.sendKeys(quickQuote.Phone1(), "12345678900");
			SeleniumFunction.sendKeys(quickQuote.Email(), "a@a.com");	
			jse.executeScript("window.scrollBy(0,350)", "");
			//SeleniumFunction.sendKeys(quickQuote.DropLocationName(), "DropTestUser");
			SeleniumFunction.sendKeys(quickQuote.DropLocationName(), JavaFunction.randomText("Dropname ",5));
			SeleniumFunction.sendKeys(quickQuote.DropAddress1(), "DropAddress1");
			SeleniumFunction.sendKeys(quickQuote.DropAddress2(), "DropAddress2");
			SeleniumFunction.sendKeys(quickQuote.DropFirstName(), "DropUserFirstName");
			SeleniumFunction.sendKeys(quickQuote.DropLastName(), "DropUserLastName");
			SeleniumFunction.sendKeys(quickQuote.DropPhone1(), "12345678900");
			SeleniumFunction.sendKeys(quickQuote.DropEmail(), "Drop@a.com");
			ScreenShot.takeScreenShot(driver, "Filled Shipment info "+shipmentType+" "+packageType);
			SeleniumFunction.click(quickQuote.ReviewOrder());
			WaitTool.sleep(5);
			SeleniumFunction.click(quickQuote.ReviewOrder());
			WaitTool.sleep(15);
			quickQuote.Okbutton();
			ScreenShot.takeScreenShot(driver, "Order Confirmation "+shipmentType+" "+packageType);
			SeleniumFunction.click(quickQuote.Okbutton());
			
			
			//If select paymenttype creditcard use below code
			//ShipmentReview
			//ScreenShot.takeScreenShot(driver, "Shipment Review");
			//SeleniumFunction.click(quickQuote.ReviewOrder());
			//WaitTool.sleep(5);
			
			//Payment
	/*		SeleniumFunction.sendKeys(quickQuote.CreditCardNumber(), "4111111111111111");
			SeleniumFunction.sendKeys(quickQuote.CardName(), "test");
			SeleniumFunction.sendKeys(quickQuote.CVV(), "123");
			SeleniumFunction.select(quickQuote.Month(), "1");
			SeleniumFunction.select(quickQuote.Year(), "2018");
			jse.executeScript("window.scrollBy(0,250)", "");
			SeleniumFunction.sendKeys(quickQuote.BillFirstName(), "Testfirst");
			SeleniumFunction.sendKeys(quickQuote.BillLastName(), "Testlast");
			SeleniumFunction.sendKeys(quickQuote.BillCompanytName(), "abc");			
			SeleniumFunction.sendKeys(quickQuote.BillPhone(), "1234567890");
			SeleniumFunction.sendKeys(quickQuote.BillAddress1(), "Add1");
			SeleniumFunction.sendKeys(quickQuote.BillAddress2(), "Add2");
			SeleniumFunction.sendKeys(quickQuote.Billzip(), "90001");
			SeleniumFunction.sendKeys(quickQuote.Billcity(), "TestCity");
			SeleniumFunction.select(quickQuote.Billcountry(), "United States");
			SeleniumFunction.select(quickQuote.Billstate(), "Alabama");
			ScreenShot.takeScreenShot(driver, "Payment Page");
			SeleniumFunction.click(quickQuote.BookandPay());
			WaitTool.sleep(5);*/
			
			  //order id
			//ScreenShot.takeScreenShot(driver, "Payment Confirmation");
		   // WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//table[@class='table table-condensed']/tbody/tr[2]/td[2]"), 60);
		   // crorderId=SeleniumFunction.getText(driver.findElement(By.xpath("//table[@class='table table-condensed']/tbody/tr[2]/td[2]")));
		    //System.out.println("crorderId:" + crorderId);
		    //set order id in excel
		   // xr.setCellData("Input","OrderId", i,crorderId);
		    //WaitTool.sleep(5);
		   // SeleniumFunction.click(quickQuote.Okbutton());
		    
            //Payment type OnAccount use below code
		    WaitTool.waitForElementPresentAndDisplay(driver, By.xpath("//div[@class='ag-body']//div[3]//div[1]//div[1]//div[1]/div[2]"), 60);
		    WaitTool.sleep(5);
		    crorderId=SeleniumFunction.getText(driver.findElement(By.xpath("//div[@class='ag-body']//div[3]//div[1]//div[1]//div[1]/div[2]")));
		    System.out.println("crorderId:" + crorderId.trim());
		    //set order id in excel
		    xr.setCellData("Input","OrderId", i,crorderId.trim());
		    WaitTool.sleep(5);
		    	    
		    
			}			
		
	}
}