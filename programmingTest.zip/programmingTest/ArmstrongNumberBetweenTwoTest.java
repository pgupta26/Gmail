/**
 * 
 */
package test.java.programmingTest;

import java.util.Scanner;

/**
 * @author e5399484
 *
 */
public class ArmstrongNumberBetweenTwoTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1, num2;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter First Number: ");
		num1=sc.nextInt();
		
		System.out.println("Enter Second Number: ");
		num2=sc.nextInt();
		
		int counter=num1;
		while(counter<=num2) {
			int num=counter;
			int temp=num;
			int sum=0;
			while(num > 0) {
				
				String str=String.valueOf(counter);
				int len=str.length();
				
				int remainder;
				
				remainder=num %10;
				num=num / 10;
				
				int powerOfNumber=1;
				for(int i=1;i<=len;i++) {
					powerOfNumber=powerOfNumber*remainder;
				}
				sum=sum+powerOfNumber;
			}
			
			if(sum==temp){
				System.out.println("Armstrong numbers between "+num1+" and "+num2+ " is: "+sum);
			}
			counter++;
		}
	}
}
