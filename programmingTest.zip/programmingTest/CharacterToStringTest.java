/**
 * 
 */
package test.java.programmingTest;

import java.util.Arrays;

/**
 * @author e5399484
 *
 */
public class CharacterToStringTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("----Character to String Conversion----");
		char ch='d';
		System.out.println("Character to String value: "+String.valueOf(ch));
		
		char[] chArray={'a', 'e', 'i', 'o', 'u'};
		System.out.println("Character Array to String value: "+new String(chArray));
		
		System.out.println("----String to Character Conversion----");
		String str="java";
		char[] ch1=str.toCharArray();
		System.out.println("String to Character Conversion: "+Arrays.toString(ch1));
		
		
	}

}
