/**
 * 
 */
package test.java.programmingTest;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * @author e5399484
 *
 */
public class FactorsTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Please Enter Number: ");
		num=sc.nextInt();
		
		int counter=1;
		
		List<Integer> factorsList=new ArrayList<Integer>();
		
		
		while(counter < num) {
			if(num % counter==0){
				factorsList.add(counter);
			}
			counter++;
		}
		
		System.out.println("Factors of a numare "+num+ "is: "+factorsList);
	}

}
