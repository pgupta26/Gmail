/**
 * 
 */
package test.java.programmingTest;

/**
 * @author e5399484
 *
 */
public class FindLargestTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]={89,78,34};
		int max=arr[0];
		
		for(int counter=0;counter<arr.length;counter++){
			if(arr[counter]>max){
				max=arr[counter];
			}
		}
		System.out.println("Largest number: "+max);
	}

}
