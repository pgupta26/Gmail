/**
 * 
 */
package test.java.programmingTest;

/**
 * @author e5399484
 *
 */
public class FrequenceOfCharacterTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="ParshPar";
		char ch='P';
		char[] charArray=str.toCharArray();
		
		int sum=0;
		for(int i=0;i<charArray.length-1;i++) {
			if(charArray[i]==ch) {
				++sum;
			}
		}
		
		System.out.println("Frequency of Character "+ch+" is: "+sum);
		
		//Count of each character in a String
		
	}
}
