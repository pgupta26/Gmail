/**
 * 
 */
package test.java.programmingTest;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

/**
 * @author e5399484
 *
 */
public class SortMapTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		Map<Integer,Integer> hm=new HashMap<Integer,Integer>();
		hm.put(3, 103);
		hm.put(1, 101);
		hm.put(2, 102);
		
		List<Integer> ls=new ArrayList<Integer>(hm.values());
		Collections.sort(ls);
		
		Map<Integer,Integer> newHM=new HashMap<Integer,Integer>();
		
		for(int counter=0;counter<ls.size();counter++){
			for(Entry<Integer,Integer> temp:hm.entrySet()){
				if(temp.getValue().equals(ls.get(counter))){
					newHM.put(temp.getKey(), temp.getValue());
				}
			}
		}
		System.out.println(newHM);
		
	}

}
