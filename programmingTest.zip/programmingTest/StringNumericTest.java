/**
 * 
 */
package test.java.programmingTest;

/**
 * @author e5399484
 *
 */
public class StringNumericTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="dfsdf";
		boolean numeric=true;
		try{
			int num=Integer.parseInt(str);
		}catch(NumberFormatException ex){
			numeric=false;
		}
		
		if(numeric){
			System.out.println("String is Numeric.");
		}else{
			System.out.println("String is not Numeric.");
		}
	}

}
