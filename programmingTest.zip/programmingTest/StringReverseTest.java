/**
 * 
 */
package test.java.programmingTest;

import java.util.Scanner;

/**
 * @author e5399484
 *
 */
public class StringReverseTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Using character array
		String str;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Please Enter Any String: ");
		str=sc.next();
		
		char[] charStr=str.toCharArray();
		
		for(int counter=charStr.length-1;counter>=0;counter--){
			System.out.println(charStr[counter]);
		}
		sc.close();
		
		//Using String builder
		
		//Using list

	}

}
