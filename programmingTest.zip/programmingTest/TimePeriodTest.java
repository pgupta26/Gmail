/**
 * 
 */
package test.java.programmingTest;

/**
 * @author e5399484
 *
 */
public class TimePeriodTest {
	
	int hour,minute,second;
	 
	TimePeriodTest(int h, int m, int s) {
		this.hour=h;
		this.minute=m;
		this.second=s;
	}
	
	public TimePeriodTest calculateDifference(TimePeriodTest start, TimePeriodTest stop){
		TimePeriodTest diff = new TimePeriodTest(0, 0, 0);

        if(stop.second > start.second){
            --start.minute;
            start.second += 60;
        }

        diff.second = start.second - stop.second;
        if(stop.minute > start.minute){
            --start.hour;
            start.minute += 60;
        }

        diff.minute = start.minute - stop.minute;
        diff.hour = start.hour - stop.hour;

        return(diff);
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TimePeriodTest start=new TimePeriodTest(12, 34, 30);
		TimePeriodTest stop=new TimePeriodTest(8, 12, 55);
		TimePeriodTest diff=new TimePeriodTest(0, 0, 0);
		diff=diff.calculateDifference(start, stop);
				
        System.out.printf("%d:%d:%d\n", diff.hour, diff.minute, diff.second);
    
	}

}
