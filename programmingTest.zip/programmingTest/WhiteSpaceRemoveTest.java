/**
 * 
 */
package test.java.programmingTest;

/**
 * @author e5399484
 *
 */
public class WhiteSpaceRemoveTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="T    his is b  ett     er.";
		
		//In replace function, we can not use regular expression.
		System.out.println("String after whitespace: "+str.replace(" ", ""));
		
		//In replace all function, we can use regular expression.
		System.out.println("String after whitespace: "+str.replaceAll("\\s", ""));
	}

}
