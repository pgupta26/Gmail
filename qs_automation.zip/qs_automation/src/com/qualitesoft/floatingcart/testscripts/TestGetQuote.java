package com.qualitesoft.floatingcart.testscripts;

import com.qualitesoft.floatingcart.pageobjects.FloatingQuickQuote;

import java.util.Iterator;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Test;
import com.qualitesoft.core.InitializeTest;
import com.qualitesoft.core.JavaFunction;
import com.qualitesoft.core.ScreenShot;
import com.qualitesoft.core.SeleniumFunction;
import com.qualitesoft.core.WaitTool;


public class TestGetQuote extends InitializeTest{ 
	@Test
	public void testGetQuote() {

		    JavascriptExecutor jse = (JavascriptExecutor) driver;	
		    FloatingQuickQuote quickQuote = new FloatingQuickQuote(driver);
/*		    //Manage Order
		    SeleniumFunction.click(quickQuote.manageOrdersLink());
		    ScreenShot.takeScreenShot(driver, "Manage Order");
		    WaitTool.sleep(5);
		    SeleniumFunction.click(quickQuote.ViewDetail());
		    ScreenShot.takeScreenShot(driver, "View Detail Popup");
		    if(driver.findElements(By.xpath("//div[@class='modal-footer']/button[@class='btn btn-success']") ).size() != 0)
				//if(driver.findElements(By.xpath("//div[@class='introjs-tooltip']") ).exists) 
				{
			    jse.executeScript("window.scrollBy(0,550)", "");
			    SeleniumFunction.click(quickQuote.Okbutton());
				}
		    WaitTool.sleep(40);
		    */
		    
		    //second time place an order
		    if(loginuser.equals("Mstore2")) {
			    SeleniumFunction.clickJS(driver, quickQuote.quickquoteLink());
			    SeleniumFunction.click(quickQuote.LTLShipment());
			}
			
			SeleniumFunction.click(quickQuote.OrderDate());
			WaitTool.sleep(5);
			// SeleniumFunction.click(quickQuote.ClickDate(orderdate));
			SeleniumFunction.click(quickQuote.OrderDate1());
			SeleniumFunction.sendKeys(quickQuote.OrderReferenceID(), "OrderId1");
			WaitTool.sleep(5);
				
			if(loginuser.equals("Mstoreuser")||loginuser.equals("Mstore2")) {
				jse.executeScript("window.scrollBy(0,-350)", "");
				WaitTool.sleep(5);
				SeleniumFunction.click(quickQuote.LTLShipment());
				SeleniumFunction.click(quickQuote.DropOffZipLocationTypeRes());
				jse.executeScript("window.scrollBy(0,-150)", "");
				//SeleniumFunction.click(quickQuote.ServiceLevel());
				
			    SeleniumFunction.click(quickQuote.ServiceLevelfloating());
			  SeleniumFunction.click(quickQuote.ServiceLevelCUR());
		      
				
			}else {
				//jse.executeScript("window.scrollBy(0,-350)", "");
				//SeleniumFunction.click(quickQuote.LTLShipment());
				//jse.executeScript("window.scrollBy(0,150)", "");
		        SeleniumFunction.click(quickQuote.DropOffZipLocationTypeResfloating());
		        jse.executeScript("window.scrollBy(0,-150)", "");
		        SeleniumFunction.click(quickQuote.ServiceLevelfloating());
		        SeleniumFunction.click(quickQuote.ServiceLevelCURFloating());
				SeleniumFunction.sendKeys(quickQuote.QuickEmail(),emailAddressRandom());
				SeleniumFunction.selectByvalue(quickQuote.AccountType(), "11");//SELECT Manufacturer type	
			}
			jse.executeScript("window.scrollBy(0,350)", "");
			SeleniumFunction.click(quickQuote.PickUpZipLocationTypeCom());	
			SeleniumFunction.sendKeys(quickQuote.PickUpZip(), "90001");
			SeleniumFunction.sendKeys(quickQuote.DropOffZip(),"90002");	
			jse.executeScript("window.scrollBy(0,350)", "");
			SeleniumFunction.click(quickQuote.PackageType());
			quickQuote.PackageTypeOptions("Custom Pallet (enter dimensions)");
			
			jse.executeScript("window.scrollBy(0,250)", "");
			SeleniumFunction.click(quickQuote.CategoryButton());
			jse.executeScript("window.scrollBy(0,250)", "");
			WaitTool.sleep(5);
			SeleniumFunction.click(quickQuote.Categoryother());//SELECT CATEGORY OTHER
			
			//Add popup on cateory 
			if(loginuser.equals("new")) {
				SeleniumFunction.click(quickQuote.notloggedpopupCateogory());	
			}else {
				SeleniumFunction.click(quickQuote.popupCateogory());
			}			
			WaitTool.sleep(2);
			jse.executeScript("window.scrollBy(0,350)", "");
			//SeleniumFunction.selectByvalue(quickQuote.Category(), "347");//SELECT CATEGORY OTHER
			WaitTool.sleep(5);
			SeleniumFunction.click(quickQuote.Weight());
			SeleniumFunction.sendKeys(quickQuote.Weight(), "40");
			SeleniumFunction.sendKeys(quickQuote.DimensionL(), "40");

			SeleniumFunction.sendKeys(quickQuote.DimensionW(), "40");

			SeleniumFunction.sendKeys(quickQuote.DimensionH(), "40");
			SeleniumFunction.sendKeys(quickQuote.DeclaredValue(), "200");
			SeleniumFunction.sendKeys(quickQuote.Cartons(), "2");
			
			
			//SeleniumFunction.click(quickQuote.Accessorials());
			//SeleniumFunction.click(quickQuote.selectAccessorials());
			
			//SeleniumFunction.click(quickQuote.DonotStackCheckBox());
			WaitTool.sleep(7);
			// ScreenShot.takeScreenShot(driver, "Data-Provided"+i);
			ScreenShot.takeScreenShot(driver, "Shipmentinfo");
			jse.executeScript("window.scrollBy(0,250)", "");
			SeleniumFunction.click(quickQuote.SaveButton());
			WaitTool.sleep(10);
			//jse.executeScript("window.scrollBy(0,-250)", "");
			//quickQuote.ValidateCarriers("9");
			
			
			//select carrier
			jse.executeScript("window.scrollBy(0,250)", "");
			//WaitTool.sleep(20);
			//SeleniumFunction.click(quickQuote.SelectCarrierCheckBox());
			ScreenShot.takeScreenShot(driver, "Rates wih Carriers ");
			WaitTool.sleep(5);
			SeleniumFunction.click(quickQuote.NextButton());
			WaitTool.sleep(3);
			if(loginuser.equals("Mstoreuser")) {
				//SeleniumFunction.click(quickQuote.NextButton());
				WaitTool.sleep(15);
				jse.executeScript("window.scrollBy(0,250)", "");
				SeleniumFunction.click(quickQuote.NextButton2());
			}
			if(loginuser.equals("Mstore2")) {
				//SeleniumFunction.click(quickQuote.NextButton());
				WaitTool.sleep(15);
				jse.executeScript("window.scrollBy(0,250)", "");
				SeleniumFunction.click(quickQuote.NextButton2());
			}
			WaitTool.sleep(10);
			
	}
	private static String emailAddressRandom() {

		String emailAddress = JavaFunction.randomText("Selenium", 4) + "@email.com";
		return emailAddress;
	}
}