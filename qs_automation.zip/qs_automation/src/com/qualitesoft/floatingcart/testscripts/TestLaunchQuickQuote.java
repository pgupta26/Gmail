package com.qualitesoft.floatingcart.testscripts;

import org.apache.jasper.tagplugins.jstl.core.Url;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import com.qualitesoft.core.InitializeTest;
import com.qualitesoft.core.ScreenShot;
import com.qualitesoft.core.SeleniumFunction;
import com.qualitesoft.core.WaitTool;
import com.qualitesoft.floatingcart.pageobjects.FloatingLaunchQuickQuote;


public class TestLaunchQuickQuote extends InitializeTest {
	@Test
	public void testLaunchQuickQuote(){
		FloatingLaunchQuickQuote launch = new FloatingLaunchQuickQuote(driver);
		SeleniumFunction.clickJS(driver, launch.GetFreeQuoteLink());
		//Change the URL
		 //DesiredCapabilities cap = DesiredCapabilities.chrome();
		
		driver.get("https://qa.freightclub.com/Home/QuickQuote#/shipmentInformation");
		//driver.navigate().to("https://qa.freightclub.com/Home/QuickQuote#/shipmentInformation");
		// cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, false);
		WaitTool.sleep(5);
		ScreenShot.takeScreenShot(driver, "Quick Quote page");
	}
	
}

