package com.qualitesoft.floatingcart.testscripts;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Test;
import com.qualitesoft.core.InitializeTest;
import com.qualitesoft.core.JavaFunction;
import com.qualitesoft.core.ScreenShot;
import com.qualitesoft.core.SeleniumFunction;
import com.qualitesoft.core.WaitTool;
import com.qualitesoft.floatingcart.pageobjects.FloatingQuickQuote;

public class TestShipmentInfo extends InitializeTest {
	@Test
	public void testShipmentInfo(){
		FloatingQuickQuote quickQuote = new FloatingQuickQuote(driver);
		if(driver.findElements(By.xpath("//div[@class='introjs-tooltip']") ).size() != 0)
		//if(driver.findElements(By.xpath("//div[@class='introjs-tooltip']") ).exists) 
		{
			SeleniumFunction.click(quickQuote.toolTipskip());
		}
		WaitTool.sleep(5);
		JavascriptExecutor jse = (JavascriptExecutor) driver;	
		jse.executeScript("window.scrollBy(0,-250)", "");
		SeleniumFunction.sendKeys(quickQuote.PalletDesc(), "TestPalletDesc");
		SeleniumFunction.sendKeys(quickQuote.SpecialHandling(), "TestSpecialHandling");
		//SeleniumFunction.sendKeys(quickQuote.LocationName(), "TestUser");
		SeleniumFunction.sendKeys(quickQuote.LocationName(), JavaFunction.randomText("TestUsername ",5));
		SeleniumFunction.sendKeys(quickQuote.Address1(), "Address1");
		SeleniumFunction.sendKeys(quickQuote.Address2(), "Address2");
		SeleniumFunction.sendKeys(quickQuote.FirstName(), "UserFirstName");
		SeleniumFunction.sendKeys(quickQuote.LastName(), "UserLastName");
		SeleniumFunction.sendKeys(quickQuote.Phone1(), "12345678900");
		SeleniumFunction.sendKeys(quickQuote.Email(), "a@a.com");	
		
		jse.executeScript("window.scrollBy(0,250)", "");
		//SeleniumFunction.sendKeys(quickQuote.DropLocationName(), "DropTestUser");
		SeleniumFunction.sendKeys(quickQuote.DropLocationName(), JavaFunction.randomText("TestDropname ",5));
		SeleniumFunction.sendKeys(quickQuote.DropAddress1(), "DropAddress1");
		SeleniumFunction.sendKeys(quickQuote.DropAddress2(), "DropAddress2");
		SeleniumFunction.sendKeys(quickQuote.DropFirstName(), "DropUserFirstName");
		SeleniumFunction.sendKeys(quickQuote.DropLastName(), "DropUserLastName");
		SeleniumFunction.sendKeys(quickQuote.DropPhone1(), "12345678900");
		SeleniumFunction.sendKeys(quickQuote.DropEmail(), "Drop@a.com");
		ScreenShot.takeScreenShot(driver, "Filled Shipment info");
		SeleniumFunction.click(quickQuote.ReviewOrder());
		WaitTool.sleep(5);
		if(driver.findElements(By.xpath("//div[@class='introjs-tooltip']") ).size() != 0)
		//if(driver.findElements(By.xpath("//div[@class='introjs-tooltip']") ).exists) 
		{
			SeleniumFunction.click(quickQuote.toolTipskip());
		}
		//ShipmentReview
		ScreenShot.takeScreenShot(driver, "Shipment Review");
		SeleniumFunction.click(quickQuote.ReviewOrder());
		WaitTool.sleep(5);
		

	}
}
