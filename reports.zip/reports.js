$(document).ready(function() {
	$("form").submit(function(e) {
	    e.preventDefault();
	  });

	var jobName="";
	$("#search").click(function(event) {
		jobName=$('#jobName').val().toString();
		$("#test tr").remove();
		$('#test1 tbody > tr').remove();
		$.ajax({
			url: "getBuildHistory.jsp",
			type:"POST",
			data:{	
				jobName1:jobName,
				  },
			dataType: "json",
			success: function(json) {
				for(i=0;i<json.length;i++){
					var row = '<tr>';
		               row += '<td>'+json[i][0]+'</td>';
		               row += '<td>'+json[i][2]+'</td>';
		               if(json[i][1]=='SUCCESS'){
		            	   row += '<td><span class="label label-success">'+json[i][1]+'</span></td>';   
		               }else{
		            	   row += '<td><span class="label label-danger">'+json[i][1]+'</span></td>';
		               }
		               var url='https://www.google.com/';
		               row+='<td><input type="button" class="btn btn-primary btn-xs" value="View Results" onClick="return openReport('+json[i][0]+');" /></td>'
		               row += '</tr>';
		               $('#test').append(row);
				}

			},
			error: function(e) {
				alert(e + " SERVER ERROR , TRY AGAIN LATER");
			}
		})
	})
})