package com;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class GetAllBuilds {

	public static ArrayList<String> getAllBuildsNumber(String url,String jobName){

			ArrayList<String> buildNumbers=new ArrayList<String>();
			Client client = Client.create();
			WebResource webResource = client.resource(url+"/job/"+jobName+"/api/json?tree=builds[number]");
			ClientResponse response = webResource.get(ClientResponse.class);
			String jsonResponse = response.getEntity(String.class);
			System.out.println(jsonResponse);
			client.destroy();

			JSONObject json =new JSONObject(jsonResponse) ;  
			JSONArray value=json.getJSONArray("builds");
			for(int i=0;i<value.length();i++){
				buildNumbers.add(value.getJSONObject(i).get("number").toString());
			}
		return buildNumbers;
		
	}

	public static void main(String[] args) {
		
		try{
			ArrayList<String> buildNumbers=getAllBuildsNumber("http://192.168.43.214:9090","GoogleTest1");
		}catch(Exception ex){
			System.out.println("exception handlled");
		}
		
		
		
		/*// TODO Auto-generated method stub
		Client client = Client.create();
		//WebResource webResource = client.resource("http://192.168.43.214:9090/job/GoogleTest/api/json?tree=builds[number,status,timestamp,id,result]");
		WebResource webResource = client.resource("http://192.168.43.214:9090/job/GoogleTest/7/api/json");
		ClientResponse response = webResource.get(ClientResponse.class);
		String jsonResponse = response.getEntity(String.class);
		System.out.println(jsonResponse);
		client.destroy();
*/
		/*JSONObject json =new JSONObject(jsonResponse) ;  
		JSONArray value=json.getJSONArray("builds");
		for(int i=0;i<value.length();i++){
			System.out.println(value.getJSONObject(i).get("number"));
		}*/




	}

}
