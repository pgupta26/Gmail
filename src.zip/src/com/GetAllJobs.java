package com;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONObject;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class GetAllJobs {
	
	public static ArrayList<String> getAllJobsNames(){
		
		ArrayList<String> jobsName=new ArrayList<String>();
		
		Client client = Client.create();
		WebResource webResource = client.resource("http://192.168.43.214:9090/api/json?tree=jobs[name]");
		ClientResponse response = webResource.get(ClientResponse.class);
		String jsonResponse = response.getEntity(String.class);
		client.destroy();

		JSONObject json =new JSONObject(jsonResponse) ;  
		JSONArray value=json.getJSONArray("jobs");
		for(int i=0;i<value.length();i++){
			jobsName.add(value.getJSONObject(i).getString("name"));
		}
		return jobsName;
	}
	
	public static ArrayList<ArrayList<String>> getJobDetails(){
		
		//To get all jobs name
		ArrayList<String> jobNames=getAllJobsNames();
		
		
		ArrayList<String> jobDetail;
		ArrayList<ArrayList<String>> jobsDetails=new ArrayList<ArrayList<String>>();
		for(String jobName:jobNames){
			
			jobDetail=new ArrayList<String>();
			jobDetail.add(jobName);
			
			//get parameter value
			Client client = Client.create();
			WebResource webResource = client.resource("http://192.168.43.214:9090/job/"+jobName+"/lastBuild/api/json");
			ClientResponse response = webResource.get(ClientResponse.class);
			String jsonResponse = response.getEntity(String.class);
			client.destroy();

			JSONObject json =new JSONObject(jsonResponse) ; 
			JSONArray value=json.getJSONArray("actions");
			JSONObject value1=value.getJSONObject(0);
			JSONArray value2=value1.getJSONArray("parameters");
			for(int k=1;k<value2.length();k++){
				jobDetail.add(value2.getJSONObject(k).getString("value"));
			}

			jobDetail.add(json.get("building").toString());
			jobsDetails.add(jobDetail);
		}
		return jobsDetails;
	}
	public static void main(String[] args) {
		ArrayList<ArrayList<String>> jobDetails=getJobDetails();
		for(ArrayList<String> jobDetail:jobDetails){
			for(String jobDetail1:jobDetail){
				System.out.println(jobDetail1);
			}
		}
	}

}
