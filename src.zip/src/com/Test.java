package com;

import java.net.URI;
import java.util.Map;

import javax.ws.rs.core.MediaType;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.filter.ClientFilter;

import java.io.File;
import java.io.IOException;


public class Test {

	public static void main(String[] args) throws SAXException, IOException, ParserConfigurationException, XPathExpressionException {
		
		/*Client client = Client.create();
		client.addFilter(new com.sun.jersey.api.client.filter.HTTPBasicAuthFilter("admin", "a7a04b36a625fc7fa98b03f17f163ae6"));
		WebResource webResource = client.resource("http://10.74.230.170:8080/job/GoogleTest/api/json");
		ClientResponse response = webResource.post(ClientResponse.class);
		
		System.out.println(response.getStatus());
		String jsonResponse = response.getEntity(String.class);
		System.out.println(jsonResponse);
		client.destroy();*/
		String TOKEN="a7a04b36a625fc7fa98b03f17f163ae6";
		/*Client client = Client.create();
		client.addFilter(new com.sun.jersey.api.client.filter.HTTPBasicAuthFilter("admin", "admin123"));
		WebResource webResource = client.resource("http://10.74.230.170:8080/job/GoogleTest/lastBuild/stop?token="+TOKEN);
		ClientResponse response = webResource.post(ClientResponse.class);
				
		System.out.println(response.getStatus());

		String jsonResponse = response.getEntity(String.class);
		System.out.println(jsonResponse);
		client.destroy();*/
		/*String urlParams="JobName=GoogleTest&Users=1&RampUp=1&LoopCount=1";

		Client client = Client.create();
		client.addFilter(new com.sun.jersey.api.client.filter.HTTPBasicAuthFilter("admin","admin123"));
		WebResource webResource = client.resource("http://10.74.230.170:9090/job/GoogleTest/buildWithParameters?token="+TOKEN+"&"+urlParams);
		ClientResponse response = webResource.post(ClientResponse.class);
		
		System.out.println(response.getStatus());

		String jsonResponse = response.getEntity(String.class);
		System.out.println(jsonResponse);
		client.destroy();*/
		
		
		
		/*Client client = Client.create();
		client.addFilter(new com.sun.jersey.api.client.filter.HTTPBasicAuthFilter("admin","admin123"));
		WebResource webResource = client.resource("http://10.74.230.170:9090/job/Test/doDelete?token="+TOKEN);
		ClientResponse response = webResource.post(ClientResponse.class);
		System.out.println(response.getStatus());

		String jsonResponse = response.getEntity(String.class);
		System.out.println(jsonResponse);
		client.destroy();
*/		
		Client client = Client.create();
		//client.addFilter(new com.sun.jersey.api.client.filter.HTTPBasicAuthFilter("admin","admin123"));
		WebResource webResource = client.resource("http://192.168.43.214:8080/job/Test/api/json?tree=builds[number,status,timestamp,id,result]");
		ClientResponse response = webResource.get(ClientResponse.class);
		System.out.println(response.getStatus());
		
		String jsonResponse = response.getEntity(String.class);
		System.out.println(jsonResponse);
		client.destroy();
		
		
		/*JSONObject obj = new JSONObject("{interests : [{interestKey:Dogs}, {interestKey:Cats}]}");

		List<String> list = new ArrayList<String>();
		JSONArray array = obj.getJSONArray("interests");
		for(int i = 0 ; i < array.length() ; i++){
		    list.add(array.getJSONObject(i).getString("interestKey"));
		}
*/		
	}
	
}

